var navs = [{
	"title" : "后台首页",
	"icon" : "&#xe61c;",
	"href" : "page/main.html",
	"spread" : false,
	"children":[{
	"title" : "交易查询",
	"icon" : "&#xe61c;",
	"href" : "page/news/newsList.html",
	"spread" : false
}]
},{
	"title" : "交易查询",
	"icon" : "&#xe61c;",
	"href" : "page/news/newsList.html",
	"spread" : false
},{
	"title" : "系统推广",
	"icon" : "&#xe629;",
	"href" : "page/links/linksList.html",
	"spread" : false
},{
	"title" : "安全设置",
	"icon" : "&#xe631;",
	"href" : "page/systemParameter/systemParameter.html",
	"spread" : false
}]