layui.config({
	base : "js/"
}).use(['form','element','layer','jquery'],function(){
	var form = layui.form,
		layer = layui.layer,
		element = layui.element,
		$ = layui.jquery;

	$(".panel a").on("click",function(){
		window.parent.addTab($(this));
	})

	//动态获取文章总数和待审核文章数量,最新文章
	$.get("../json/newsList.json",
		function(data){
			var waitNews = [];
			$(".allNews span").text(data.length);  //文章总数
			for(var i=0;i<data.length;i++){
				var newsStr = data[i];
				if(newsStr["newsStatus"] == "待审核"){
					waitNews.push(newsStr);
				}
			}
			$(".waitNews span").text(waitNews.length);  //待审核文章
			//加载最新文章
			var hotNewsHtml = '';
			for(var i=0;i<5;i++){
				hotNewsHtml += '<tr>'
		    	+'<td align="left">'+data[i].newsName+'</td>'
		    	+'<td>'+data[i].newsTime+'</td>'
		    	+'</tr>';
			}
			$(".hot_news").html(hotNewsHtml);
		}
	)
	//在线人数
	$.ajax({
		url:'/api-admin/dashboard/get/online/number',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				$(".onLineNumber").text(res.data.onlineNumber);		
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	})
	//每个战场人数
	$.ajax({
		url:'/api-admin/dashboard/get/battle/number',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta=[];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template").html());	
						$('#tableList').html(template(dta));	
				}else{
					$("#tableList").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});
	
	//匹配小队实时信息
	$.ajax({
		url:'/api-admin/dashboard/get/matching/team',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta=[];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_match').html(template(dta));	
				}else{
						$("#tableList_match").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});
	
	//匹配小队累计信息
	$.ajax({
		url:'/api-admin/dashboard/get/matching/team',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
			var dta = [];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_team_sum').html(template(dta));	
				}else{
						$("#tableList_team_sum").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});
	
	//结算完成小队实时信息
	$.ajax({
		url:'/api-admin/dashboard/get/settlement/team',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_seleter_team').html(template(dta));	
				}else{
						$("#tableList_seleter_team").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});
	
	//结算完成小队累计信息
	$.ajax({
		url:'/api-admin/dashboard/get/settlement/team/sum',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta = [];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_settleFilish').html(template(dta));	
				}else{
						$("#tableList_settleFilish").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});
	//结算失败小队实时信息
	$.ajax({
		url:'/api-admin/dashboard/get/settlement/fail/team',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta = [];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_fail_team').html(template(dta));	
				}else{
						$("#tableList_fail_team").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});	
	//结算中小队实时信息
	$.ajax({
		url:'/api-admin/dashboard/get/settlementing/team',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta = [];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_settlementing_team').html(template(dta));	
				}else{
						$("#tableList_settlementing_team").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});	
	//结算失败小队累计信息
	$.ajax({
		url:'/api-admin/dashboard/get/settlement/fail/team/sum',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				var dta = [];
				dta = res.data;
				if(dta.length>0){
					var template = Handlebars.compile($("#table-template-team").html());	
						$('#tableList_settleFaild').html(template(dta));	
				}else{
						$("#tableList_settleFaild").html('<tr><td colspan="2">暂无数据</td><tr>');
				}
			}else{
				console.log(JSON.stringify(res.data));
			}
		}
	});
	
	//累计充值金额与累计充值人数
	$.ajax({
		url:'/api-admin/dashboard/get/pay',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			if(res.code == 0){
				// console.log(JSON.stringify(res.data));
				$(".payNumber").text(res.data.payNumber);
				$(".payMoney").text(res.data.payAmount);
			}else{
				console.log(JSON.stringify(res.data));
			}
		}

	});
	//参加匹配队伍数
	var dta_team =[];
	$.ajax({
		url:'/api-admin/dashboard/get/matching/team',
		type:'post',
		data:{},
		dataType:'json',
		traditional:true,
		async:true,
		timeout:2000,
		beforeSend:function(request){
			request.setRequestHeader('Authorization',layui.data('author').Authorization);
		},
		success:function(res){
			var dta_team = [];
			dta_team = res.data;
			if(dta_team.length>0){
				var template = Handlebars.compile($('#table-template-team').html());
				$('#tableList_team').html(template(dta_team));
			}else{
				console.log(dta_team);
				$('#tableList_team').html('<tr><td colspan="2" style="text-align:center;">暂无数据</td></tr>');
			}
		}
	});
	
	//图片总数
	$.get("../json/images.json",
		function(data){
			$(".imgAll span").text(data.length);
		}
	)

	//用户数
	$.get("../json/usersList.json",
		function(data){
			$(".userAll span").text(data.length);
		}
	)

	//新消息
	$.get("../json/message.json",
		function(data){
			$(".newMessage span").text(data.length);
		}
	)


	//数字格式化
	$(".panel span").each(function(){
		$(this).html($(this).text()>9999 ? ($(this).text()/10000).toFixed(2) + "<em>万</em>" : $(this).text());	
	})

	//系统基本参数
	if(window.sessionStorage.getItem("systemParameter")){
		var systemParameter = JSON.parse(window.sessionStorage.getItem("systemParameter"));
		fillParameter(systemParameter);
	}else{
		$.ajax({
			url : "../json/systemParameter.json",
			type : "get",
			dataType : "json",
			success : function(data){
				fillParameter(data);
			}
		})
	}

	//填充数据方法
 	function fillParameter(data){
 		//判断字段数据是否存在
 		function nullData(data){
 			if(data == '' || data == "undefined"){
 				return "未定义";
 			}else{
 				return data;
 			}
 		}
 		$(".version").text(nullData(data.version));      //当前版本
		$(".author").text(nullData(data.author));        //开发作者
		$(".homePage").text(nullData(data.homePage));    //网站首页
		$(".server").text(nullData(data.server));        //服务器环境
		$(".dataBase").text(nullData(data.dataBase));    //数据库版本
		$(".maxUpload").text(nullData(data.maxUpload));    //最大上传限制
		$(".userRights").text(nullData(data.userRights));//当前用户权限
 	}

})
