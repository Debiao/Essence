//var backUserServer = "https://pay.gaaa8.com/api-admin/";
// var backUserServer = "http://47.56.24.152:18030/";
 var backUserServer = "http://127.0.0.1:18030/";
var loginURL = "userWeb/login";


var modifyUser = backUserServer + "customerservice/modifyUser";
var findUser = backUserServer + "customerservice/findUser";
var manyFindUser = backUserServer + "customerservice/manyFindUser";
var deleteUser = backUserServer + "customerservice/deleteUser";
var createUser = backUserServer + "customerservice/createUser";

var manyBindApplication = backUserServer + "application/find/list";
var bindApplication = backUserServer + "application/bind";
var findBindApplication = backUserServer + "application/find/id";
var modifyBindApplication = backUserServer + "application/update";
var deleteBindApplication = backUserServer + "application/delete";
var findChannel = backUserServer + "application/find/channel";//查看渠道
var chooseChannel = backUserServer + "application/choose/channel";//设置渠道
var initChannel = backUserServer + "application/init/channel";//同步渠道
var initStandard = backUserServer + "application/init/standard";//重置订单数权重值
var setRateWeight = backUserServer + "application/set/rateWeight";//设置应用费率权重值

var createPayAccount = backUserServer + "payaccount/createPayAccount";
var deletePayAccount = backUserServer + "payaccount/deletePayAccount";
var findPayAccount = backUserServer + "payaccount/findPayAccount";
var findManyPayAccount = backUserServer + "payaccount/findManyPayAccount";
var modifyPayAccount = backUserServer + "payaccount/modifyPayAccount";

var deleteOrder = backUserServer + "order/deleteOrder";
var manyReadOrderInformation = backUserServer + "order/manyReadOrderInformation";
var modifyOrder = backUserServer + "order/modifyOrder";
var readOrderInformation = backUserServer + "order/readOrderInformation";
var getNewOrderCount = backUserServer + "order/getNewOrderCount";
var isTest = backUserServer + "order/isTest";//测试接口

var createPayChannel = backUserServer + "paychannel/create";
var findpayType = backUserServer + "paychannel/findpayType";
var payTypeid = backUserServer + "paychannel/payTypeid";
var removePayChannel = backUserServer + "paychannel/remove";
var getChannelList = backUserServer + "paychannel/findMany";
var getChannelById = backUserServer + "paychannel/find";
var modifyChannel = backUserServer + "paychannel/modify";
var findUseChannel = backUserServer + "paychannel/find/use";//获取使用中的第三方支付名称
var getUseNumber = backUserServer + "paychannel/get/use/number";//获取使用中的第三方支付的统计数量
var getChannelDetailed = backUserServer + "paychannel/get/detailed";//获取使用中的第三方支付的统计数量



function dateFormate(mss) {
    var date = new Date(mss);//毫秒级
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' ';
    var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
    var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
    var s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
    return Y + M + D + h + m + s;
}

// function payTypeParse(id) {
// 	var cnName;
// 	$.ajax({
// 	    type: 'POST',
// 	    url: payTypeid,
// 	    // headers: { "Authorization": token },
// 		data:{
// 			"id":id,
// 		},
// 		async:false,
// 	    success: function (res) {
// 			if (res.data != null) {
// 				cnName = res.data.cnName;
// 			} else{
// 				// cnName = "无";
// 				return
// 			}
// 	    }
// 	});
// 	// console.log(cnName);
// 	return cnName;
// }

function payTypeParse(id) {
    switch (id) {
        case 1:
            return '支付宝';
            break;
        case 2:
            return '微信';
            break;
        case 3:
            return '银行卡';
			break;
		case 4:
            return 'QQ';
			break;
		case 5:
            return '云闪付';
			break;
		case 6:
            return '支付宝定额';
			break;
		case 7:
            return '微信定额';
			break;
		case 8:
            return '支付宝定额';
			break;
		case 9:
            return '微信定额';
			break;
		case 10:
            return '支付宝测试';
			break;
		case 11:
            return '微信测试';
            break;
        case 12:
            return '话费充值';
            break;
        default:
            return '未知';
    }
}

function orderStatusParse(status) {
    switch (status) {
        case 0:
            return '创建';
            break;
        case 1:
            return '创建成功';
            break;
        case 2:
            return '用户已经确认';
            break;
        case 3:
            return '客服已经确认';
            break;
        default:
            return '未知';
    }
}

function rolenameParse(role) {
    switch (role) {
        case 'ROLE_SUPERADMIN':
            return '超级管理员';
            break;
        case 'ROLE_ADMIN':
            return '管理员';
            break;
        case 'ROLE_STAFF':
            return '客服';
            break;
        case 'ROLE_ACCOUNTANT':
            return '财务';
            break;
        default:
            return '未知';
    }
}

function statusParse(status) {
    switch (status) {
        case 0:
            return '未支付';
            break;
        case 1:
            return '支付成功';
            break;
		case 2:
		    return '支付失败';
		    break;	
        default:
            return '未知';
    }
}

//状态码
function statusCode(code) {
    switch (code) {
        case -1:
            return '失败';
            break;
        case 0:
            return '成功';
            break;
		case 1:
		    return '请求失败，请稍后重试';
		    break;
		case 401:
		    return '请重新登录';
		    break;
		case 402:
		    return '账号异常';
		    break;
		case 403:
		    return '权限不足';
		    break;
		case 404:
		    return '找不到对应的资源';
		    break;
		case 500:
		    return '内部服务器错误';
		    break;
		case 10001:
		    return '玩家不存在';
		    break;
		case 20001:
		    return '订单不存在';
		    break;
		case 20002:
		    return '订单状态错误';
		    break;
		case 30001:
		    return '登录失败%s';
		    break;
		case 40001:
		    return '数据异常，检查参数%s';
		    break;
		case 40002:
		    return '用户名重复';
		    break;
		case 50001:
		    return '密码状态不允许设置密码';
		    break;
		case 50050:
		    return '渠道不存在';
		    break;
		case 50051:
		    return '超过图片上传数量限制';
		    break;
		case 50052:
		    return '验证码错误，请重新输入';
		    break;
		case 50054:
		    return '验证码超时，请重新获取验证码';
		    break;
		case 50053:
		    return '代理数量超过，不可以添加';
		    break;
		case 50055:
		    return '未到时间,不能重新生成';
		    break;
		case 400001:
		    return '邮箱相同，请重新输入';
		    break;
        default:
            return '未知错误 请重试';
    }
}