var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size:10, sort: 'DESC', sortBy: 'id',page:0};  
     Handlebars.registerHelper('exchage',function(v1,opts){
        if(v1.length>0){
                var str="";
                for(var i=0;i<v1.length;i++){
                        if(v1[i]=="ROLE_USER"){
                            if(str==""){
                                str += "普通用户";
                            }else{
                                str += ",普通用户";
                            }
                        }else
                        if(v1[i]=="ROLE_ADMIN"){
                            if(str==""){
                                str += "管理员";
                            }else{
                                str += ",管理员";
                            }
                        }else
                        if(v1[i]=="ROLE_SUPERADMIN"){
                            if(str==""){
                                str += "超级管理员";
                            }else{
                                str += ",超级管理员";
                            }
                        }else
                        if(v1[i]=="ROLE_OPERATE"){
                            if(str==""){
                                str += "运维";
                            }else{
                                str += ",运维";
                            }
                        }else
                        if(v1[i]=="ROLE_STAFF"){
                            if(str==""){
                                str += "客服";
                            }else{
                                str += ",客服";
                            }
                        }

                } 
               return str; 
        }
        return "";
     });   
	cjhd.json('/api-admin/user/find/all/user', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
        }, { type: 'post' });
        if(dta.length>0){
          var template = Handlebars.compile($("#table-template").html());
              $("#tableList").html(template(dta));  
              $("#page-template").html('<div id="page"></div>');
              laypage.render({
                  elem:'page',
                  count:count,
                  limit:data.size,
                  layout:['prev','page','next','count'],
                  jump:function(obj,first){
                    data.page = obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/user/find/all/user',data,function(res){
                                data = res.data.data;
                                count = res.data.total;
                            },{type:'post'});
                             $("#tableList").empty();
                             var template = Handlebars.compile($("#table-template").html());
                             $("#tableList").html(template(dta));          
                        } 
                  }
              });
        }else{
            $("#tableList").html("<tr class='tbody'><td colspan='7'>暂无数据</td></tr>");
        }
     var typeData={ size:10, sort: 'DESC', sortBy: 'id',page:0};   
     form.on('submit(searchByType)',function(){
        $("#tableList").empty();
        $("#page-template").empty();
        var type=$('select[name="type"]').val();
        typeData.type = type;
        cjhd.json('/api-admin/user/find/all/user',typeData,function(res){
            dta = res.data.data;
            count = res.data.total;
        },{type:'post'});
        if(dta.length>0){
            var template = Handlebars.compile($("#table-template").html());
                $("#tableList").html(template(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:typeData.size,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        typeData.page = obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/user/find/all/user',typeData,function(res){
                                dta = res.data.data;
                                count = res.data.total;
                            },{type:'post'});
                            $("#tableList").empty();
                            var template = Handlebars.compile($("#table-template").html());
                                $("#tableList").html(template(dta));
                        }  
                    }
                });
        }else{
           $("#tableList").html("<tr class='tbody'><td colspan='7'>暂无数据</td></tr>"); 
        }
        return false;
     });   
	
    //充值
    form.on('submit(payMoney)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['400px','40%'],
                content:'page/manage/editManage.html' 
        });
        return false;
    });
   
	exports('manage', {});
	
});