var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		data = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false };
		Handlebars.registerHelper('if_eq', function(v1, v2, opts) {
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);
		});
		cjhd.json('/api-admin/attachment/find/all', data, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length>0){
			$("#tableList").empty();
			var myTemplate=Handlebars.compile($("#table-template").html());
				$("#tableList").html(myTemplate(dta));
				$("#page-template").html('<div id="page"></div>');
				//执行一个laypage实例
				laypage.render({
					elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
					, count: count //数据总数，从服务端得到
					, limit: 10
					, layout: ['prev', 'page', 'next', 'count']
					, jump: function (obj, first) {
						data.page = obj.curr - 1;
						//首次不执行
						if (!first) {
							console.log(data);
							cjhd.json('/api-admin/attachment/find/all', data, function (res) {
								dta = res.data.data;
								count = res.data.total;
								$('.news_content').html(tbody(dta));
							}, { type: 'post' });
							//
						}
					}
				});
			}else{
				$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
		}
	
	//全查询
	var allData={ size: 10, sort: 'DESC', sortBy: 'id',deleted:false };
	form.on('submit(searchAll)',function(){	
		$("#tableList").empty();
		$("#page-template").empty();
		cjhd.json('/api-admin/attachment/find/all',allData,function(res){
			dta=res.data.data;
			count=res.data.total;		
		},{type:'post'});
		if(dta.length>0){	
			var myTemplate=Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));
			$("#page-template").html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				count:count,
				limit:10,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					allData.page=obj.curr - 1;
					cjhd.json('/api-admin/attachment/find/all',allData,function(res){
						dta=res.data.data;
						count=res.data.total;
					},{type:'post'});
					$("#tableList").empty();
					var myTemplate=Handlebars.compile($("#table-template").html());
					$("#tableList").html(myTemplate(dta));
				}
			});
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
		}
		return false;	
	});
	//查看已删除
	var delData={page:0,size:10,sort:'DESC',sortBy:'id'}
	form.on('submit(searchByDelete)',function(){
		$("#tableList").empty();
		$("#page-template").empty();
		cjhd.json('/api-admin/attachment/find/deleted',delData,function(res){
			dta=res.data.data;
			count =res.data.count;
		},{type:'post'});
		if(dta.length==0){
			$("#tableList").html("<tr class='tbody'><td colspan='6'>暂无数据</td></tr>");
		}else{
			$('#tableList').empty();
			var myTemplate=Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));
			$("#page-template").html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				count:count,
				limit:10,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					delData.page=obj.curr - 1;
					if(!first){
						cjhd.json('/api-admin/attachment/find/deleted',delData,function(res){
							dta = res.data.data;
							count = res.data.total;
							$("#tableList").empty();
							var myTemplate=Handlebars.compile($("#table-template").html());
								$("#tableList").html(myTemplate(dta));
						},{type:'post'});
					}
				}
			});
		}
		return false;
	});
	//id查询
	form.on('submit(searchById)', function(){
		$("#tableList").empty();
		$("#page-template").empty();
		var id = $('input[name="id"]').val();
				cjhd.json('/api-admin/attachment/find/id', {id:id}, function (res) {
					dta = [res.data];
					form.render();
				}, { type: 'post' });
				if(dta[0]==""||dta.length==0){
					$("#tableList").html("<tr class='tbody'><td colspan='6'>暂无数据</td></tr>");
				}else{
					$('#tableList').empty();
					var myTemplate=Handlebars.compile($("#table-template").html());
					$("#tableList").html(myTemplate(dta));	
				}
		return false;	
	});
	//添加附件
	form.on('submit(add)',function(data){
		layer.open({
			type:2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '40%'],
			content: 'page/enclosure/addEnclosure.html' //iframe的url
		});
		return false;
	});
	//删除附件
	form.on('submit(deleteBlacklist)',function(data){
		var id=$(data.elem).parents('tr').find('.id').text();
		cjhd.json('/api-admin/attachment/remove', { id: id }, function (res) {
			if (res.code == 0) {
				layer.msg("删除成功");
				parent.location.reload();
			} else {
				layer.msg("服务器出错了");
			}
		}, { type: 'post' });
		return false;
	})
	
	exports('enclosure', {});
	
});