var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form','jquery','element','layer','laydate','laypage','util','cjhd'],function(exports){
	var form  = layui.form,
				$ = layui.jquery,
				element = layui.element,
				layer = layui.layer,
				laydate = layui.laydate,
				laypage = layui.laypage,
				util = layui.util,
				cjhd = layui.cjhd;
				Handlebars.registerHelper('tochange',function(v1,opts){
					return  parseInt(v1/1000/60/60);
				});
				//折线
				function yhqs_chart(type,labels,datasets,responsive,title,tooltips,hover,xAxes,yAxes){
				var	configs = {
						type:type,
					data:{
						labels:labels,
						datasets:datasets
					},
					options:{
						responsive: responsive,
						title:title,
						tooltips:tooltips,
						hover:hover,
						scales: {
							xAxes:xAxes,
							yAxes:yAxes
						}
					}
				}
				return configs;
				}	
				
			
				form.render('checkbox');
				var plateForm = layui.data('author').plateForm;	
				if(JSON.stringify(plateForm)=="{}"){					  
					var str = "";
					str += '<div class="filter_icon" id="android">';
					str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					str += '<div class="filter_icon" id="iOS">';
					str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					$('.filter_left').html(str);
				}else 
				if(plateForm.platfrom=='iOS'){
				
					var str = "";
					str += '<div class="filter_icon" id="iOS">';
					str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					$('.filter_left').html(str);

					var checkbox = $('input[name="checkbox"]');
					checkbox.each(function(i,v){
						if(v.value ==plateForm.platfrom){

						}else{
							$(this).prop('checked',false);
						}
					});
					
				}else 
				if(plateForm.platfrom=='android'){

					var str = "";
					str += '<div class="filter_icon" id="android">';
					str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					$('.filter_left').html(str);
					var checkbox = $('input[name="checkbox"]');
					checkbox.each(function(i,v){
						if(v.value ==plateForm.platfrom){

						}else{
							$(this).prop('checked',false);
						}
					});
					
					
				}
				//平台选定
				var checked = $('input[name="checkbox"]:checked');
								checked.each(function(i,v){
									$(this).click(function(){
										var check = $('input[name="checkbox"]:not(:checked)');
										
										var _this = this.checked;
										if(_this == false){
											var ve = this.value;
											var len = $(".filter_left").children(".filter_icon").size();
											var arr =[];
											for(var i=0;i<=len-1;i++){
												arr[i] = i;
											}
											$.each(arr,function(i){
												var checked1 = $('input[name="checkbox"]:checked');
												var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
												if(ve == idvalue){
													if(checked1.length<1){
														layer.msg("至少需选一种平台信息");
													}else{
														$("#"+idvalue).remove();
													}
													
												}
											});
										}else{	
											var vu = this.value;
											var len = $(".filter_left").children(".filter_icon").size();
											var arr =[];
											for(var i=0;i<=len-1;i++){
												arr[i] = i;
											}
											$.each(arr,function(i){
												var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
												if(idvalue == vu){
													
												}else{
													if(check.length<=1){
														check.each(function(){
															$(this).prop('checked','checked');
														});
													}
													if(vu=='iOS'){
														var str = '';
															str += '<div class="filter_icon" id="iOS">';
															str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
															str += '</div>';
															$(".filter_left").append(str);
													}else
													if(vu == 'android'){
														var str = '';
															str += '<div class="filter_icon" id="android">';
															str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
															str += '</div>';
															$(".filter_left").append(str);
													}
													
												}
												
											});
										}
										
										
									});
								});	
				var check  = $('input[name="checkbox"]:not(checked)');
					check.each(function(i,v){
						$(this).click(function(){
							var _this = this.checked;
							if(_this == true){
								var ve = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
									var arr =[];
									for(var i=0;i<=len-1;i++){
										arr[i] = i;
									}
									$.each(arr,function(i){
										var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
										// alert();
										if(ve == idvalue){
											
										}else{
											if(ve=='iOS'){
												var str = '';
													str += '<div class="filter_icon" id="iOS">';
													str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
													str += '</div>';
													$(".filter_left").append(str);
											}else
											if(ve == 'android'){
												var str = '';
													str += '<div class="filter_icon" id="android">';
													str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
													str += '</div>';
													$(".filter_left").append(str);
											}	
										}
									});
								}else{
										var vu = this.value;
											var len = $(".filter_left").children(".filter_icon").size();
											var arr =[];
											for(var i=0;i<=len-1;i++){
												arr[i] = i;
											}
											$.each(arr,function(i){
												var checke = $('input[name="checkbox"]:not(checked)');
												var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
												if(vu == idvalue){
													if(checke.length<1){
														layer.msg("至少需选一种平台信息");
													}else{
														$("#"+idvalue).remove();
													}
													
												}
											});
							}
						});
					});	
				//日期组件
				laydate.render({
					elem:'#date',
					type:'date',
					range: '~',
					value:util.toDateString(new Date(new Date()-1000*60*60*24*30),'yyyy-MM-dd')+' ~ '+util.toDateString(new Date(),'yyyy-MM-dd'),
					btn:'confirm',
					done:function(value){
						if(value!=""){
							var startTime = value.split(' ~ ')[0],
								endTime = value.split(' ~ ')[1],
								data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
								//新增用户
								$.ajax({
									type:'post',
									url:'/api-admin/datahome/get/count/new/user',
									data:data,
									dataType:'json',
									async:true,
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Athorization);
									},
									success:function(res){
										if(res.code == 0){
											$(".newlyAdd").text(res.data.dataCount);
										}else{
											$(".newlyAdd").text("");
										}
									}
								});
								//活跃用户
								$.ajax({
									type:'post',
									url:"/api-admin/datahome/get/count/active/user",
									data:data,
									dataType:'json',
									async:true,
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Athorization);
									},
									success:function(res){
										if(res.code == 0){
											$(".activeUsers").text(res.data.dataCount);
										}else{
											$(".activeUsers").text("");
										}
									}
								});
								//使用时长
								$.ajax({
									type:'post',
									url:'/api-admin/datahome/get/use/time',
									data:data,
									dataType:'json',
									async:true,
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Athorization);
									},
									success:function(res){
										if(res.code == 0){
											$(".dcsysc_qs").text(util.toDateString(res.data.dataCount,'HH:mm:ss'));
										}else{
											$(".dcsysc_qs").text(util.toDateString(""));
										}
									}
								});	
								//数据详情
								var qs_sjxq = [],count=0;
								var qs_sjxqData = {page:0,size:8,start:startTime,end:endTime,sort:'DESC',sortBy:'time',platfrom:plateForm.platfrom};
								cjhd.json('/api-admin/datahome/get/data/details',qs_sjxqData,function(res){
									if(res.code == 0){
										qs_sjxq = res.data.data;
										count = res.data.total;
									}
								},{type:'post'});
								if(qs_sjxq.length>0){
									var template = Handlebars.compile($("#table-template").html());
									$("#tableList").html(template(qs_sjxq));
									$("#page-template").html('<div id="page"></div>');
									laypage.render({
										elem:'page',
										count:count,
										limit:qs_sjxqData.size,
										layout:['prev','page','next','count'],
										jump:function(obj,first){
											qs_sjxqData.page = obj.curr - 1;
											if(!first){
												cjhd.json('/api-admin/datahome/get/data/details',qs_sjxqData,function(res){
													if(res.code == 0){
														qs_sjxq = res.data.data;
													}
												},{type:'post'});
												$("#tableList").html(template(qs_sjxq));
											}
										}
									});
								}else{
									$("#tableList").html('<tr><td colspan="6">暂无数据</td></tr>');
								}//详情
						}
					}
				});		
				// console.log(JSON.stringify(plateForm));	
				//用户趋势总数
				var times_qs_slot = $('#date').val(),
				// var times_qs_slot = util.toDateString(new Date(new Date()-1000*60*60*24*30),'yyyy-MM-dd') + ' ~ ' + util.toDateString(new Date(),'yyyy-MM-dd')
					time_sq_start = times_qs_slot.split(' ~ ')[0],
					time_sq_end = times_qs_slot.split(' ~ ')[1],
					qs_dataCount = {platfrom:plateForm.platfrom,start:time_sq_start,end:time_sq_end}; 
				// console.log(JSON.stringify(times_qs_slot));
				$.ajax({
						type:'post',
						url:'/api-admin/datahome/get/count/new/user',
						data:qs_dataCount,
						dataType:'json',
						async:true,
						beforeSend:function(request){
							request.setRequestHeader('Authorization',layui.data('author').Athorization);
						},
						success:function(res){
							if(res.code == 0){
								$(".newlyAdd").text(res.data.dataCount);
							}else{
								$(".newlyAdd").text("");
							}
						}
				});	
				//活跃用户
				$.ajax({
					type:'post',
					url:"/api-admin/datahome/get/count/active/user",
					data:qs_dataCount,
					dataType:'json',
					async:true,
					beforeSend:function(request){
						request.setRequestHeader('Authorization',layui.data('author').Athorization);
					},
					success:function(res){
						if(res.code == 0){
							$(".activeUsers").text(res.data.dataCount);
						}
					}
				});
				//使用时长
				$.ajax({
					type:'post',
					url:'/api-admin/datahome/get/use/time',
					data:qs_dataCount,
					dataType:'json',
					async:true,
					beforeSend:function(request){
						request.setRequestHeader('Authorization',layui.data('author').Athorization);
					},
					success:function(res){
						if(res.code == 0){
							$(".dcsysc_qs").text(util.toDateString(res.data.dataCount,'HH:mm:ss'));
						}
					}
				});
				//新增用户折线
				var qs_xzyh=[],qs_xzyh_dta=[],qs_xzyh_time=[];
				cjhd.json('/api-admin/datahome/get/new/use/day',qs_dataCount,function(res){
					if(res.code == 0){
						qs_xzyh = res.data.dayData;
					}
				},{type:'post'});
				if(qs_xzyh.length>0){
					for(var i in qs_xzyh){
						qs_xzyh_dta.push(qs_xzyh[i].dayData);
						qs_xzyh_time.push(qs_xzyh[i].time);
					}
				var datasets = [{
					label: '新增用户',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:qs_xzyh_dta
					}],
					title = {
						display: true,
						text: ''
					},
					tooltips = {
						mode: 'index'
					},
					hover = {
						mode: 'index'
					},
					xAxes = [{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes=[{
						stacked: true,
						scaleLabel: {
							display: true,
							labelString: '数量'
						}
					}]
				var config = yhqs_chart('line',qs_xzyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
				var ctx = document.getElementById('canvas').getContext('2d');
				window.myLine = new Chart(ctx, config);
				}
				//数据详情
				var qs_sjxq = [],count=0;
				var qs_sjxqData = {page:0,size:8,start:time_sq_start,end:time_sq_end,sort:'DESC',sortBy:'time'}
				cjhd.json('/api-admin/datahome/get/data/details',qs_sjxqData,function(res){
					if(res.code == 0){
						qs_sjxq = res.data.data;
						count = res.data.total;
					}
				},{type:'post'});
				if(qs_sjxq.length>0){
					var template = Handlebars.compile($("#table-template").html());
					$("#tableList").html(template(qs_sjxq));
					$("#page-template").html('<div id="page"></div>');
					laypage.render({
						elem:'page',
						theme:'#1E9FFF',
						count:count,
						limit:qs_sjxqData.size,
						layout:['prev','page','next','count'],
						jump:function(obj,first){
							qs_sjxqData.page = obj.curr - 1;
							if(!first){
								cjhd.json('/api-admin/datahome/get/data/details',qs_sjxqData,function(res){
									if(res.code == 0){
										qs_sjxq = res.data.data;
									}
								},{type:'post'});
								$("#tableList").html(template(qs_sjxq));
							}
						}
					});
				}else{
					$("#tableList").html('<tr><td colspan="6">暂无数据</td></tr>');
				}
				var chart_flag = 0;
				//新增用户
				$("#chart_xzyh").on('click',function(){
					chart_flag = 0;
					var qs_xzyh=[],qs_xzyh_dta=[],qs_xzyh_time=[];
					cjhd.json('/api-admin/datahome/get/new/use/day',qs_dataCount,function(res){
						if(res.code == 0){
							qs_xzyh = res.data.dayData;
						}
					},{type:'post'});
					if(qs_xzyh.length>0){
						for(var i in qs_xzyh){
							qs_xzyh_dta.push(qs_xzyh[i].dayData);
							qs_xzyh_time.push(qs_xzyh[i].time);
						}
					$("#mid_out_xzsb_down_chart").empty();
					$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
					var datasets = [{
						label: '新增用户',
						borderColor: '#1495eb',
						backgroundColor: 'rgba(195,203,214)',
						data:qs_xzyh_dta
						}],
						title = {
							display: true,
							text: ''
						},
						tooltips = {
							mode: 'index'
						},
						hover = {
							mode: 'index'
						},
						xAxes = [{
							scaleLabel: {
								display: true,
								labelString: '30日'
							}
						}],
						yAxes=[{
							stacked: true,
							scaleLabel: {
								display: true,
								labelString: '数量'
							}
							}]
						var config = yhqs_chart('line',qs_xzyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
						var ctx = document.getElementById('canvas').getContext('2d');
						window.myLine = new Chart(ctx, config);
					}
				});
				
				//活跃用户
				$("#chart_hyyh").on('click',function(){
					chart_flag = 1;
					$("#mid_out_xzsb_down_chart").empty();
					$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
					var qs_hyyh=[],qs_hyyh_dta=[],qs_hyyh_time=[];
					cjhd.json('/api-admin/datahome/get/active/use/day',qs_dataCount,function(res){
						if(res.code == 0){
							qs_hyyh = res.data.dayData;
						}
					},{type:'post'});
					if(qs_hyyh.length>0){
						for(var i in qs_hyyh){
							qs_hyyh_dta.push(qs_hyyh[i].dayData);
							qs_hyyh_time.push(qs_hyyh[i].time);
						}
					}
					var datasets = [{
						label: '活跃用户',
						borderColor: '#1495eb',
						backgroundColor: 'rgba(195,203,214)',
						data:qs_hyyh_dta
						}],
						title = {
							display: true,
							text: ''
						},
						tooltips = {
							mode: 'index'
						},
						hover = {
							mode: 'index'
						},
						xAxes = [{
							scaleLabel: {
								display: true,
								labelString: '30日'
							}
						}],
						yAxes=[{
							stacked: true,
							scaleLabel: {
								display: true,
								labelString: '数量'
							}
							}]
						var config = yhqs_chart('line',qs_hyyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
						var ctx = document.getElementById('canvas').getContext('2d');
						window.myLine = new Chart(ctx, config);	
				});
				//周活跃用户
				$("#chart_zhyyh").on('click',function(){
					chart_flag = 2;
					$("#mid_out_xzsb_down_chart").empty();
					$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
					var qs_zhyyh=[],qs_zhyyh_dta=[],qs_zhyyh_time=[];
					cjhd.json('/api-admin/datahome/get/active/use/week',qs_dataCount,function(res){
						if(res.code == 0){
							qs_zhyyh = res.data.dayData;
						}
					},{type:'post'});
					if(qs_zhyyh.length>0){
						for(var i in qs_zhyyh){
							qs_zhyyh_dta.push(qs_zhyyh[i].dayData);
							qs_zhyyh_time.push(qs_zhyyh[i].time);
						}
					}
					var datasets = [{
						label: '周活跃用户',
						borderColor: '#1495eb',
						backgroundColor: 'rgba(195,203,214)',
						data:qs_zhyyh_dta
						}],
						title = {
							display: true,
							text: ''
						},
						tooltips = {
							mode: 'index'
						},
						hover = {
							mode: 'index'
						},
						xAxes = [{
							scaleLabel: {
								display: true,
								labelString: '30日'
							}
						}],
						yAxes=[{
							stacked: true,
							scaleLabel: {
								display: true,
								labelString: '数量'
							}
							}]
						var config = yhqs_chart('line',qs_zhyyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
						var ctx = document.getElementById('canvas').getContext('2d');
						window.myLine = new Chart(ctx, config);	
				});
				//月用户
				$("#chart_yyh").on('click',function(){
					chart_flag = 3;
					$("#mid_out_xzsb_down_chart").empty();
					$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
					var qs_yyh=[],qs_yyh_dta=[],qs_yyh_time=[];
					cjhd.json('/api-admin/datahome/get/active/use/month',qs_dataCount,function(res){
						if(res.code == 0){
							qs_yyh = res.data.dayData;
						}
					},{type:'post'});
					if(qs_yyh.length>0){
						for(var i in qs_yyh){
							qs_yyh_dta.push(qs_yyh[i].dayData);
							qs_yyh_time.push(qs_yyh[i].time);
						}
					}
					var datasets = [{
						label: '月用户',
						borderColor: '#1495eb',
						backgroundColor: 'rgba(195,203,214)',
						data:qs_yyh_dta
						}],
						title = {
							display: true,
							text: ''
						},
						tooltips = {
							mode: 'index'
						},
						hover = {
							mode: 'index'
						},
						xAxes = [{
							scaleLabel: {
								display: true,
								labelString: '30日'
							}
						}],
						yAxes=[{
							stacked: true,
							scaleLabel: {
								display: true,
								labelString: '数量'
							}
							}]
						var config = yhqs_chart('line',qs_yyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
						var ctx = document.getElementById('canvas').getContext('2d');
						window.myLine = new Chart(ctx, config);
				});
				//单次使用时长
				$("#chart_dcsysc").on('click',function(){
					chart_flag = 4;
					$("#mid_out_xzsb_down_chart").empty();
					$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
					var qs_dcsysc=[],qs_dcsysc_dta=[],qs_dcsysc_time=[];
					// console.log(JSON.stringify(qs_dataCount));
					cjhd.json('/api-admin/datahome/get/use/time/day',qs_dataCount,function(res){
						if(res.code == 0){
							// console.log(JSON.stringify(res));
							qs_dcsysc = res.data.dayData;
						}
					},{type:'post'});
					if(qs_dcsysc.length>0){
						for(var i in qs_dcsysc){
							qs_dcsysc_dta.push(parseInt(qs_dcsysc[i].dayData/1000/60/60));
							qs_dcsysc_time.push(qs_dcsysc[i].time);
						}
					}
					var datasets = [{
						label: '单次使用时长',
						borderColor: '#1495eb',
						backgroundColor: 'rgba(195,203,214)',
						data:qs_dcsysc_dta
						}],
						title = {
							display: true,
							text: ''
						},
						tooltips = {
							mode: 'index'
						},
						hover = {
							mode: 'index'
						},
						xAxes = [{
							scaleLabel: {
								display: true,
								labelString: '30日'
							}
						}],
						yAxes=[{
							stacked: true,
							scaleLabel: {
								display: true,
								labelString: '小时'
							}
							}]
						var config = yhqs_chart('line',qs_dcsysc_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
						var ctx = document.getElementById('canvas').getContext('2d');
						window.myLine = new Chart(ctx, config);
				});
				//对比时段
				var sd_f = 0;
				var dbsd_dta = qs_dataCount;
				form.on('checkbox(checkbox_sd)',function(data){
					if(sd_f==0){
						var str = '';
							str += '<li class="icon icon-calendar" style="float:left; margin-top: 2px;"></li>';
							str += '<div style="float:left;margin-top: -10px;">';
							str += '<input type="text" name="sd_date" id="sd_date" class="layui-input" style="border:none;"/>';
							str += '</div>';
							str += '<li class="icon icon-angle-down" style="float:left; margin-left: -5px;"></li>';
						$('.tab_sd_date').html(str);
							laydate.render({
							elem:'#sd_date',
							type:'date',
							range:'~',
							value:util.toDateString(new Date(new Date()-1000*60*60*24*30),'yyyy-MM-dd') + ' ~ ' + util.toDateString(new Date(),'yyyy-MM-dd'),
							btn:'confirm',
							done:function(value,date){
								if(value !=""){
								var start  = value.split(' ~ ')[0],
									end = value.split(' ~ ')[1];
									dbsd_dta.start = start;
									dbsd_dta.end = end;
									if(chart_flag==0){
										//
										chart_flag = 0;
										var qs_xzyh=[],qs_xzyh_dta=[],qs_xzyh_time=[];
										cjhd.json('/api-admin/datahome/get/new/use/day',dbsd_dta,function(res){
											if(res.code == 0){
												qs_xzyh = res.data.dayData;
											}
										},{type:'post'});
										if(qs_xzyh.length>0){
											for(var i in qs_xzyh){
												qs_xzyh_dta.push(qs_xzyh[i].dayData);
												qs_xzyh_time.push(qs_xzyh[i].time);
											}
										$("#mid_out_xzsb_down_chart").empty();
										$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
										var datasets = [{
											label: '新增用户',
											borderColor: '#1495eb',
											backgroundColor: 'rgba(195,203,214)',
											data:qs_xzyh_dta
											}],
											title = {
												display: true,
												text: ''
											},
											tooltips = {
												mode: 'index'
											},
											hover = {
												mode: 'index'
											},
											xAxes = [{
												scaleLabel: {
													display: true,
													labelString: '30日'
												}
											}],
											yAxes=[{
												stacked: true,
												scaleLabel: {
													display: true,
													labelString: '数量'
												}
												}]
											var config = yhqs_chart('line',qs_xzyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
											var ctx = document.getElementById('canvas').getContext('2d');
											window.myLine = new Chart(ctx, config);
											
										}
										//
									}else 
									if(chart_flag==1){
										//
										$("#mid_out_xzsb_down_chart").empty();
										$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
										var qs_hyyh=[],qs_hyyh_dta=[],qs_hyyh_time=[];
										cjhd.json('/api-admin/datahome/get/active/use/day',dbsd_dta,function(res){
											if(res.code == 0){
												qs_hyyh = res.data.dayData;
											}
										},{type:'post'});
										if(qs_hyyh.length>0){
											for(var i in qs_hyyh){
												qs_hyyh_dta.push(qs_hyyh[i].dayData);
												qs_hyyh_time.push(qs_hyyh[i].time);
											}
										}
										var datasets = [{
											label: '活跃用户',
											borderColor: '#1495eb',
											backgroundColor: 'rgba(195,203,214)',
											data:qs_hyyh_dta
											}],
											title = {
												display: true,
												text: ''
											},
											tooltips = {
												mode: 'index'
											},
											hover = {
												mode: 'index'
											},
											xAxes = [{
												scaleLabel: {
													display: true,
													labelString: '30日'
												}
											}],
											yAxes=[{
												stacked: true,
												scaleLabel: {
													display: true,
													labelString: '数量'
												}
												}]
											var config = yhqs_chart('line',qs_hyyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
											var ctx = document.getElementById('canvas').getContext('2d');
											window.myLine = new Chart(ctx, config);	
										//
									}else 
									if(chart_flag==2){
										//
										$("#mid_out_xzsb_down_chart").empty();
										$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
										var qs_zhyyh=[],qs_zhyyh_dta=[],qs_zhyyh_time=[];
										cjhd.json('/api-admin/datahome/get/active/use/week',dbsd_dta,function(res){
											if(res.code == 0){
												qs_zhyyh = res.data.dayData;
											}
										},{type:'post'});
										if(qs_zhyyh.length>0){
											for(var i in qs_zhyyh){
												qs_zhyyh_dta.push(qs_zhyyh[i].dayData);
												qs_zhyyh_time.push(qs_zhyyh[i].time);
											}
										}
										var datasets = [{
											label: '周活跃用户',
											borderColor: '#1495eb',
											backgroundColor: 'rgba(195,203,214)',
											data:qs_zhyyh_dta
											}],
											title = {
												display: true,
												text: ''
											},
											tooltips = {
												mode: 'index'
											},
											hover = {
												mode: 'index'
											},
											xAxes = [{
												scaleLabel: {
													display: true,
													labelString: '30日'
												}
											}],
											yAxes=[{
												stacked: true,
												scaleLabel: {
													display: true,
													labelString: '数量'
												}
												}]
											var config = yhqs_chart('line',qs_zhyyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
											var ctx = document.getElementById('canvas').getContext('2d');
											window.myLine = new Chart(ctx, config);	
										//
									}else
									if(chart_flag==3){
										//
										$("#mid_out_xzsb_down_chart").empty();
										$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
										var qs_yyh=[],qs_yyh_dta=[],qs_yyh_time=[];
										cjhd.json('/api-admin/datahome/get/active/use/month',dbsd_dta,function(res){
											if(res.code == 0){
												qs_yyh = res.data.dayData;
											}
										},{type:'post'});
										if(qs_yyh.length>0){
											for(var i in qs_yyh){
												qs_yyh_dta.push(qs_yyh[i].dayData);
												qs_yyh_time.push(qs_yyh[i].time);
											}
										}
										var datasets = [{
											label: '月用户',
											borderColor: '#1495eb',
											backgroundColor: 'rgba(195,203,214)',
											data:qs_yyh_dta
											}],
											title = {
												display: true,
												text: ''
											},
											tooltips = {
												mode: 'index'
											},
											hover = {
												mode: 'index'
											},
											xAxes = [{
												scaleLabel: {
													display: true,
													labelString: '30日'
												}
											}],
											yAxes=[{
												stacked: true,
												scaleLabel: {
													display: true,
													labelString: '数量'
												}
												}]
											var config = yhqs_chart('line',qs_yyh_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
											var ctx = document.getElementById('canvas').getContext('2d');
											window.myLine = new Chart(ctx, config);
										//
									}else
									if(chart_flag==4){
										//
										$("#mid_out_xzsb_down_chart").empty();
										$("#mid_out_xzsb_down_chart").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
										var qs_dcsysc=[],qs_dcsysc_dta=[],qs_dcsysc_time=[];
										cjhd.json('/api-admin/datahome/get/use/time/day',dbsd_dta,function(res){
											if(res.code == 0){
												qs_dcsysc = res.data.dayData;
											}
										},{type:'post'});
										if(qs_dcsysc.length>0){
											for(var i in qs_dcsysc){
												qs_dcsysc_dta.push(parseInt(qs_dcsysc[i].dayData/1000/60/60));
												qs_dcsysc_time.push(qs_dcsysc[i].time);
											}
										}
										var datasets = [{
											label: '单次使用时长',
											borderColor: '#1495eb',
											backgroundColor: 'rgba(195,203,214)',
											data:qs_dcsysc_dta
											}],
											title = {
												display: true,
												text: ''
											},
											tooltips = {
												mode: 'index'
											},
											hover = {
												mode: 'index'
											},
											xAxes = [{
												scaleLabel: {
													display: true,
													labelString: '30日'
												}
											}],
											yAxes=[{
												stacked: true,
												scaleLabel: {
													display: true,
													labelString: '小时'
												}
												}]
											var config = yhqs_chart('line',qs_dcsysc_time,datasets,true,title,tooltips,hover,xAxes,yAxes);
											var ctx = document.getElementById('canvas').getContext('2d');
											window.myLine = new Chart(ctx, config);
										//
									}
								}	
							}  
						});
						form.render();
						sd_f = 1;
					}else{
						$('.tab_sd_date').empty();
						sd_f = 0;
						window.location.reload();
					}
					return false;
				});
				//数据详情下载
				$("#sjxq_updown").on('click',function(){
					alert('数据详情下载：439');
				});	
				//数据详情help
				$("#sjxq_help").on('mouseover',function(){
					$("#sjxq_movechange").css('display','block');
				});
				$('#sjxq_help').on('mouseout',function(){
					$("#sjxq_movechange").css('display','none');
				});
			
			
				//阻止事件冒泡
				function stopPropagation(e) {
				    var ev = e || window.event;
				    if (ev.stopPropagation) {
				        ev.stopPropagation();
				    }
				    else if (window.event) {
				        window.event.cancelBubble = true;//兼容IE
				    }
				}
				$(".filter").on('click',function(e){
					$(".dropdown-content").show();
					// $(".dropdown-content").slideDown('slow');
					stopPropagation(e);
				});
				$(document).bind('click',function(){
					$(".dropdown-content").hide();
					// $(".dropdown-content").slideUp('slow');
				});
				$(".dropdown-content").click(function (e) {
				    stopPropagation(e);
				});
				//平台选定
				//确定
				$("#filter").on('click',function(){
					$(".dropdown-content").hide();
					var len = $(".filter_left").children(".filter_icon").size();
					if(len>=2){
						cjhd.savePlateForm({});
						window.location.reload();
						return;	
					}else{
						var plate = $(".filter_left").children(".filter_icon").attr("id");
						cjhd.savePlateForm({platfrom:plate});
						window.location.reload();
						return;
					}
				});
				//取消
				$("#reback").on('click',function(){
					$(".dropdown-content").hide();
				});
				// 筛选
				var flag =0 ;
				$("#btn_screen").on('click',function(e){
					if(flag==0){
						$(".shaixuankuang").show();
						flag = 1;
						stopPropagation(e);
					}else{
						$(".shaixuankuang").hide();
						flag = 0;
						stopPropagation(e);
						
					}
				});
				$(document).bind('click',function(e){
					$(".shaixuankuang").hide();
				});
				$(".shaixuankuang").on('click',function(e){
					stopPropagation(e);
				});
				
				
    exports('usertrends',{});
});