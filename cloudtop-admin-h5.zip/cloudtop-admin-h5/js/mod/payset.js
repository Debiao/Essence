var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = {size: 10, sort: 'DESC', sortBy: 'id',page:0};
	cjhd.json('/api-admin/payconfig/list/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
	}, { type: 'post' });
	if(dta.length>0){
		var payset_template = Handlebars.compile($("#payset_template").html());
			$("#tableList").html(payset_template(dta));
			$("#page-template").html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				count:count,
				limit:num,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					data.page = obj.curr - 1;
					if(!first){
						cjhd.json('/api-admin/payconfig/list/all',data,function(res){
							dta = res.data.data;
						},{type:'post'});
						$("#tableList").html(payset_template(dta));
					}
				}
			});
	}else{
		$("#tableList").html('<tr style="height:40px;"><td colspan="7">暂无数据</td></tr>');
	}	
    //键和类型名查询
    form.on('submint(searchByNameAndType)',function(){
        var name=$('input[name="name"]').val(),
            type=$('input[name="type"]').val();
        cjhd.json('/api-admin/payconfig/find/name-type',{name:name,type:type},function(res){
            dta=[res.data];
            $('.news_content').html(tbody(dta));
        },{type:'post'});
           form.render(); 
        return false;
    });
    //类型查询
    form.on('submit(searchByByTypeId)',function(){
        var typeId=$('input[name="typeId"]').val();
        cjhd.json('/api-admin/payconfig/list/type',{type:typeId},function(res){
            dta=res.data.data;
            $('.news_content').html(tbody(dta));
        },{type:'post'});
        form.render(); 
        return false;
    });
    //支付账号查询
    form.on('submit(searchByByuserName)',function(){
        var userName = $('input[name="userName"]').val();
            cjhd.json('/api-admin/payconfig/list/username',{userName:userName},function(res){
                dta=res.data.data;
                $('.news_content').html(tbody(dta));
            },{type:'post'});
            form.render(); 
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '40%'],
			content: 'page/payset/addPayset.html' //iframe的url
		});
    });
    //編輯
    form.on('submit(editDic)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
            type:2,
            title:'',
            shadeClose:true,
            shade:0.8,
            area:['500px','40%'],
            content:'page/payset/editPayset.html'
        });
    });
	exports('payset', {});
	
});