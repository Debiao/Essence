var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form','jquery','element','layer','laydate','util','cjhd'],function(exports){
	var form  = layui.form,
	$ = layui.jquery,
	element = layui.element,
	layer = layui.layer,
	laydate = layui.laydate,
	util = layui.util,
	cjhd = layui.cjhd;
	var plateForm = layui.data('author').plateForm;
	if(JSON.stringify(plateForm)=="{}"){					  
		var str = "";
		str += '<div class="filter_icon" id="android">';
		str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		str += '<div class="filter_icon" id="iOS">';
		str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);
	}else 
	if(plateForm.platfrom=='iOS'){
	
		var str = "";
		str += '<div class="filter_icon" id="iOS">';
		str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);

		var checkbox = $('input[name="checkbox"]');
		checkbox.each(function(i,v){
			if(v.value ==plateForm.platfrom){

			}else{
				$(this).prop('checked',false);
			}
		});
		
	}else 
	if(plateForm.platfrom=='android'){

		var str = "";
		str += '<div class="filter_icon" id="android">';
		str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);
		var checkbox = $('input[name="checkbox"]');
		checkbox.each(function(i,v){
			if(v.value ==plateForm.platfrom){

			}else{
				$(this).prop('checked',false);
			}
		});
		
		
	}
	//平台选定
	var checked = $('input[name="checkbox"]:checked');
					checked.each(function(i,v){
						$(this).click(function(){
							var check = $('input[name="checkbox"]:not(:checked)');
							
							var _this = this.checked;
							if(_this == false){
								var ve = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var checked1 = $('input[name="checkbox"]:checked');
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(ve == idvalue){
										if(checked1.length<1){
											layer.msg("至少需选一种平台信息");
										}else{
											$("#"+idvalue).remove();
										}
										
									}
								});
							}else{	
								var vu = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(idvalue == vu){
										
									}else{
										if(check.length<=1){
											check.each(function(){
												$(this).prop('checked','checked');
											});
										}
										if(vu=='iOS'){
											var str = '';
												str += '<div class="filter_icon" id="iOS">';
												str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
												str += '</div>';
												$(".filter_left").append(str);
										}else
										if(vu == 'android'){
											var str = '';
												str += '<div class="filter_icon" id="android">';
												str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
												str += '</div>';
												$(".filter_left").append(str);
										}
										
									}
									
								});
							}
							
							
						});
					});	
	var check  = $('input[name="checkbox"]:not(checked)');
		check.each(function(i,v){
			$(this).click(function(){
				var _this = this.checked;
				if(_this == true){
					var ve = this.value;
					var len = $(".filter_left").children(".filter_icon").size();
						var arr =[];
						for(var i=0;i<=len-1;i++){
							arr[i] = i;
						}
						$.each(arr,function(i){
							var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
							// alert();
							if(ve == idvalue){
								
							}else{
								if(ve=='iOS'){
									var str = '';
										str += '<div class="filter_icon" id="iOS">';
										str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
										str += '</div>';
										$(".filter_left").append(str);
								}else
								if(ve == 'android'){
									var str = '';
										str += '<div class="filter_icon" id="android">';
										str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
										str += '</div>';
										$(".filter_left").append(str);
								}	
							}
						});
					}else{
							var vu = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var checke = $('input[name="checkbox"]:not(checked)');
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(vu == idvalue){
										if(checke.length<1){
											layer.msg("至少需选一种平台信息");
										}else{
											$("#"+idvalue).remove();
										}
										
									}
								});
				}
			});
		});	
	//设备切换
	var time_flag = 0,flag_device = 0;
	laydate.render({
		elem:'#date',
		type:'date',
		range: '~',
		value:util.toDateString(new Date(new Date()-1000*60*60*24*30),'yyyy-MM-dd')+ ' ~ ' + util.toDateString(new Date(),'yyyy-MM-dd'),
		btn:'confirm',
		done:function(value){
			if(value!=""){
				var startTime = value.split(' ~ ')[0],
					endTime = value.split(' ~ ')[1],
					data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
					if(flag_device==0){
						if(time_flag==0){
							var url = '/api-admin/retentionanalysis/get/day/retention',
							headData = ['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'],
							bodyTempDom = "table_template_day";
							data_temp(url,data,headData,bodyTempDom);
						}else
						 if(time_flag==1){
							var url = '/api-admin/retentionanalysis/get/week/retention',
							headData = ['日期','用户数','+1周','+2周','+3周','+4周','+5周','+6周','+7周','+8周'],
							bodyTempDom = "table_template_week";
							data_temp(url,data,headData,bodyTempDom);
						}else
						if(time_flag==2){
							var url = '/api-admin/retentionanalysis/get/month/retention',
							headData = ['日期','用户数','+1月','+2月','+3月','+4月','+5月','+6月'],
							bodyTempDom = "table_template_month";
							data_temp(url,data,headData,bodyTempDom);
						}
					}else 
					if(flag_device==1){
						if(time_flag==0){
							var url = "/api-admin/retentionanalysis/get/day/active/retention",
							headData = ['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'],
							bodyTempDom = "table_template_day";
							data_temp(url,data,headData,bodyTempDom);
						}else 
						if(time_flag==1){
							var url = '/api-admin/retentionanalysis/get/week/active/retention',
							headData = ['日期','用户数','+1周','+2周','+3周','+4周','+5周','+6周','+7周','+8周'],
							bodyTempDom = "table_template_week";
							data_temp(url,data,headData,bodyTempDom);
						}else 
						if(time_flag==2){
							var url = '/api-admin/retentionanalysis/get/month/active/retention',
							headData = ['日期','用户数','+1月','+2月','+3月','+4月','+5月','+6月'],
							bodyTempDom = "table_template_month";
							data_temp(url,data,headData,bodyTempDom);
						}
					}
					
					
			}
		}
	});
	form.render('checkbox');
	laydate.render('input[name="date"]');
	//数据Nan转换
	Handlebars.registerHelper('formatData',function(v1,opts){
		if(v1=='NaN')
			return 0;
		else
			return v1;

	});

		//新增设备存留
		var startTime = util.toDateString(new Date(new Date()-1000*60*60*24*30),'yyyy-MM-dd'),
			endTime = util.toDateString(new Date(),'yyyy-MM-dd');
			var data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		$.ajax({
			type:'post',
			url:'/api-admin/retentionanalysis/get/day/retention',
			data:data,
			dataType:'json',
			beforeSend:function(request){
				request.setRequestHeader('Authorization',layui.data('author').Authorization);
			},
			success:function(res){
				var dt = [];
				if(res.code == 0){
					dt = res.data.retentionInfo2List;
				}
				var tableHead = Handlebars.compile($("#head_template").html());
					$("#headList_template").html(tableHead(['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'])); 
				if(dt.length>0){
					var tableBody = Handlebars.compile($("#table_template_day").html());
					$("#tbodyList_template").html(tableBody(dt));
				}else{
					$("#tbodyList_template").html('<tr><td colspan="11">暂无数据</td></tr>');
				}
			}
		});
	
	//存留日查询
	
	$("#cunliu_day").on('click',function(){
		time_flag = 0;
		$(this).css('color','#5CADFF');
		$("#cunliu_week").css('color','black');
		$("#cunliu_moth").css('color','black');
		$("#headList_template").empty();
		$("#tbodyList_template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		if(flag_device==0){
			var url = '/api-admin/retentionanalysis/get/day/retention',
			headData = ['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'],
			bodyTempDom = "table_template_day";
			data_temp(url,data,headData,bodyTempDom);
		}else 
		if(flag_device==1){
			var url = "/api-admin/retentionanalysis/get/day/active/retention",
			headData = ['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'],
			bodyTempDom = "table_template_day";
			data_temp(url,data,headData,bodyTempDom);
		}
	});	
	//存留周查询
	$("#cunliu_week").on('click',function(){
		time_flag = 1;
		$(this).css('color','#5CADFF');
		$("#cunliu_day").css('color','black');
		$("#cunliu_moth").css('color','black');
		$("#headList_template").empty();
		$("#tbodyList_template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		if(flag_device==0){
			var url = '/api-admin/retentionanalysis/get/week/retention',
			headData = ['日期','用户数','+1周','+2周','+3周','+4周','+5周','+6周','+7周','+8周'],
			bodyTempDom = "table_template_week";
			data_temp(url,data,headData,bodyTempDom);
		}else 
		if(flag_device==1){
			var url = '/api-admin/retentionanalysis/get/week/active/retention',
			headData = ['日期','用户数','+1周','+2周','+3周','+4周','+5周','+6周','+7周','+8周'],
			bodyTempDom = "table_template_week";
			data_temp(url,data,headData,bodyTempDom);
		}
	});
	//存留月查询
	$("#cunliu_moth").on('click',function(){
		time_flag = 2;
		$(this).css('color','#5CADFF');
		$("#cunliu_day").css('color','black');
		$("#cunliu_week").css('color','black');
		$("#headList_template").empty();
		$("#tbodyList_template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};	
		if(flag_device==0){
			var url = '/api-admin/retentionanalysis/get/month/retention',
			headData = ['日期','用户数','+1月','+2月','+3月','+4月','+5月','+6月'],
			bodyTempDom = "table_template_month";
			data_temp(url,data,headData,bodyTempDom);
		}else 
		if(flag_device==1){
			var url = '/api-admin/retentionanalysis/get/month/active/retention',
				headData = ['日期','用户数','+1月','+2月','+3月','+4月','+5月','+6月'],
				bodyTempDom = "table_template_month";
				data_temp(url,data,headData,bodyTempDom);
		}
	});
	 //新增设备
	 $("#addDevice").on('click',function(){
		flag_device = 0;
		$("#headList_template").empty();
		$("#tbodyList_template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};	
		if(time_flag==0){
			var url = '/api-admin/retentionanalysis/get/day/retention',
			headData = ['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'],
			bodyTempDom = "table_template_day";
			data_temp(url,data,headData,bodyTempDom);
		}else
		 if(time_flag==1){
			var url = '/api-admin/retentionanalysis/get/week/retention',
			headData = ['日期','用户数','+1周','+2周','+3周','+4周','+5周','+6周','+7周','+8周'],
			bodyTempDom = "table_template_week";
			data_temp(url,data,headData,bodyTempDom);
		}else
		if(time_flag==2){
			var url = '/api-admin/retentionanalysis/get/month/retention',
			headData = ['日期','用户数','+1月','+2月','+3月','+4月','+5月','+6月'],
			bodyTempDom = "table_template_month";
			data_temp(url,data,headData,bodyTempDom);
		}	 
	 });
	 //表格数据模板
	 function data_temp(url,data,headData,bodyTempDom){
		var dta = [];
		cjhd.json(url,data,function(res){
			if(res.code == 0){
				dta = res.data.retentionInfo2List;
			};
		},{type:'post'});
		var tableHead = Handlebars.compile($("#head_template").html());
		$("#headList_template").html(tableHead(headData)); 
		if(dta.length>0){
			var tableBody = Handlebars.compile($("#"+bodyTempDom).html());
			$("#tbodyList_template").html(tableBody(dta));
		}else{
			var len = headData.length;
			$("#tbodyList_template").html('<tr><td colspan="'+len+'">暂无数据</td></tr>');
		}
	 }
	 //活跃设备
	 $("#activeDevice").on('click',function(){
		flag_device = 1;
		$("#headList_template").empty();
		$("#tbodyList_template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
			if(time_flag==0){
				var url = "/api-admin/retentionanalysis/get/day/active/retention",
				headData = ['日期','用户数','+1日','+2日','+3日','+4日','+5日','+6日','+7日','+30日'],
				bodyTempDom = "table_template_day";
				data_temp(url,data,headData,bodyTempDom);
			}else 
			if(time_flag==1){
				var url = '/api-admin/retentionanalysis/get/week/active/retention',
				headData = ['日期','用户数','+1周','+2周','+3周','+4周','+5周','+6周','+7周','+8周'],
				bodyTempDom = "table_template_week";
				data_temp(url,data,headData,bodyTempDom);
			}else 
			if(time_flag==2){
				var url = '/api-admin/retentionanalysis/get/month/active/retention',
				headData = ['日期','用户数','+1月','+2月','+3月','+4月','+5月','+6月'],
				bodyTempDom = "table_template_month";
				data_temp(url,data,headData,bodyTempDom);
			}
	 });
	//存留下载
	$("#cunliu_updown").on('click',function(){
		alert('cunliu_updown:309');
	});
	//存留移进移出cunliu_help
	$("#cunliu_help").on('mouseover',function(){
		$("#movechange").css('display','block');
	});
	$("#cunliu_help").on('mouseout',function(){
		$("#movechange").css('display','none');
	});
	$("#cunliu_updown").on('click',function(){
		alert('cunliu_updown');
	});
	var sd_f = 0;
	form.on('checkbox(checkbox_sd)',function(data){
		if(sd_f==0){
			var str = '';
				str += '<li class="icon icon-calendar" style="float:left; margin-top: 2px;"></li>';
				str += '<div style="float:left;margin-top: -10px;">';
				str += '<input type="text" name="sd_date" id="sd_date" class="layui-input" style="border:none;"/>';
				str += '</div>';
				str += '<li class="icon icon-angle-down" style="float:left; margin-left: -5px;"></li>';
			$('.tab_sd_date').html(str);
				laydate.render({
				elem:'#sd_date',
				type:'date',
				range:'~',
				value:'2018-10-1 ~ 2019-03-21'
					});
			form.render();
			sd_f = 1;
		}else{
			$('.tab_sd_date').empty();
			sd_f = 0;
		}
		return false;
	});

	//阻止时间冒泡
	function stopPropagation(e) {
		var ev = e || window.event;
		if (ev.stopPropagation) {
			ev.stopPropagation();
		}
		else if (window.event) {
			window.event.cancelBubble = true;//兼容IE
		}
	}
	$(".filter").on('click',function(e){
		$(".dropdown-content").show();
		// $(".dropdown-content").slideDown('slow');
		stopPropagation(e);
	});
	$(document).bind('click',function(){
		$(".dropdown-content").hide();
		// $(".dropdown-content").slideUp('slow');
	});
	$(".dropdown-content").click(function (e) {
		stopPropagation(e);
	});
	//平台选定
	$("#filter").on('click',function(){
		var len = $(".filter_left").children(".filter_icon").size();
		if(len>=2){
			cjhd.savePlateForm({});
			window.location.reload();
			return;	
		}else{
			var plate = $(".filter_left").children(".filter_icon").attr("id");
			cjhd.savePlateForm({platfrom:plate});
			window.location.reload();
			return;
		}
	});
	$("#reback").on('click',function(){
		$(".dropdown-content").hide();
	});
	// 筛选
	var flag =0 ;
	$("#btn_screen").on('click',function(e){
		if(flag==0){
			$(".shaixuankuang").show();
			flag = 1;
			stopPropagation(e);
		}else{
			$(".shaixuankuang").hide();
			flag = 0;
			stopPropagation(e);
			
		}
	});
	$(document).bind('click',function(e){
		$(".shaixuankuang").hide();
	});
	$(".shaixuankuang").on('click',function(e){
		stopPropagation(e);
	});
	$("#shaixuankuang_down_qx").on('click',function(){
		$(".shaixuankuang").hide();
	});
	
    exports('retentionanalysic',{});
});