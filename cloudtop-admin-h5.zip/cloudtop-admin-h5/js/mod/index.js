/**

 @Name: Fly主入口

 */
 

layui.define(['layer','laytpl'], function(exports){
  
  var $ = layui.jquery
  ,layer = layui.layer
  ,device = layui.device()
  ,DISABLED = 'layui-btn-disabled';
  //阻止IE7以下访问
  if(device.ie && device.ie < 8){
    layer.alert('如果您非得使用 IE 浏览器访问Fly社区，那么请使用 IE8+');
  }
  
  layui.focusInsert = function(obj, str){
    var result, val = obj.value;
    obj.focus();
    if(document.selection){ //ie
      result = document.selection.createRange(); 
      document.selection.empty(); 
      result.text = str; 
    } else {
      result = [val.substring(0, obj.selectionStart), str, val.substr(obj.selectionEnd)];
      obj.focus();
      obj.value = result.join('');
    }
  };

  //数字前置补零
  layui.laytpl.digit = function(num, length, end){
    var str = '';
    num = String(num);
    length = length || 2;
    for(var i = num.length; i < length; i++){
      str += '0';
    }
    return num < Math.pow(10, length) ? str + (num|0) : num;
  };
  
  //公共函数
  var cjhd = {
    //Ajax
    json: function(url, data, success, options){
      var that = this, type = typeof data === 'function';
      
      if(type){
        options = success
        success = data;
        data = {};
      }
      var loading = layer.msg('正在处理数据中,请勿刷新', {
        icon: 16
        ,shade: 0.5,
        time:2000000
      });
      options = options || {};
      var ajaxData = {
        type: options.type || 'post',
        dataType: options.dataType || 'json',
        data: data,
        url: url,
        async:false,
        traditional: true,
        timeout: 20000, //超时时间：20秒
        beforeSend:function(request) {
					if (layui.data("author").login=="login"){
          }else{
           request.setRequestHeader("Authorization", layui.data("author").Authorization);
          }
        },
        success: function(res){
          var tabsNumber=window.sessionStorage.getItem("curmenu");
          if(tabsNumber==null||tabsNumber==undefined){
            tabsNumber  =[]
          }
          if(res.code === 0) {
            success && success(res);
          } 
          else if(res.code===401){
            if(tabsNumber.length==9){
              layer.confirm('登录已过期请重新登录1', {
                btn: ['重新登录'] 
              }, function(){
                location.href="page/user/login.html";
              })
            } 
            else{
              layer.confirm('登录已过期请重新登录3', {
                btn: ['重新登录'] 
              }, function(){
                parent.location.href="../../page/user/login.html";
              })
            }
            
          }else if(res.code===403){
            if(window.sessionStorage.getItem("curmenu").length==9){
                layer.confirm('您的账号密码在别处已登录请重新登录', {
                  btn: ['重新登录'] 
                }, function(){
                  location.href="page/user/login.html";
                })
            }else{
              layer.confirm('您的账号密码在别处已登录请重新登录', {
                btn: ['重新登录'] 
              }, function(){
                location.href="page/user/login.html";
              })
            }
           
          }
        
        }
        ,error: function(e){
          if (e.status == 401) {
            location.href="../../page/user/login.html";
          }else 
          if(e.code==401){
            if(window.sessionStorage.getItem("curmenu").length==9){
              layer.confirm('登录已过期请重新登录11', {
                btn: ['重新登录'] 
              }, function(){
                location.href="page/user/login.html";
              })
            }else if(e.status==500){
              layer.confirm('服务器出现错误了...', {
                btn: ['返回登录页面等待维护'] 
                }, function(){
                location.href="../../page/user/login.html";
                })
            }else{
              layer.confirm('登录已过期请重新登录22', {
                btn: ['重新登录'] 
              }, function(){
                parent.location.href="../../page/user/login.html";
              })
            }
          }else 
          if(e.code==403){
            if(window.sessionStorage.getItem("curmenu").length==9){
              layer.confirm('您的账号密码在别处已登录请重新登录', {
                btn: ['重新登录'] 
              }, function(){
                location.href="page/user/login.html";
              })
            }else{
              layer.confirm('您的账号密码在别处已登录请重新登录', {
                btn: ['重新登录'] 
              }, function(){
                parent.location.href="../../page/user/login.html";
              })
            }
          }else {
            if (e.responseJSON && e.responseJSON.status == 403){
              layer.msg(e.responseJSON.message, {shift: 6});
              window.location.href = "page/user/login.html";
            } else {
              layer.msg('请求异常，请重试:'+e.statusText, {shift: 6});
              options.error && options.error(e);
              // window.location.href = "page/user/login.html";
            }
          }
          
        },
        complete: function () {//完成响应
          layer.close(loading);
        }
      };
      return $.ajax(ajaxData);
     

    }
    //取随机整数数
    ,randomNum: function(min,max){
      var range = max - min;
      var rand = Math.random();  
      var num = min + Math.round(rand * range);
      return num;
    }
    //取随机整小数,保留2位小数
    ,randomDecimal: function(min,max){
      var range = max - min;
      var rand = Math.random();
      var randMax = rand * range;
      var num = min + randMax;
      return num.toFixed(2);
    }
    //计算字符长度
    ,charLen: function(val){
      var arr = val.split(''), len = 0;
      for(var i = 0; i <  val.length ; i++){
        arr[i].charCodeAt(0) < 299 ? len++ : len += 2;
      }
      return len;
    }
    , getQueryString: function (name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
      var r = window.location.search.substr(1).match(reg);
      if (r != null) return unescape(r[2]); return null;
    }
    //保存用户验证的头信息
//     ,saveAuthorHeader: function(username,psw){
//       layui.data("author",{
//         key:"Authorization",
//         value:"Basic " + btoa(username + ":" + psw)
//       });
//     }
		,saveAuthorHeader: function(Authorization){
      layui.data("author",{
        key:"Authorization",
        value:Authorization
      });
    }
    ,saveAuthorUser: function(userData){
      layui.data("author",{
        key:"userData",
        value:userData
      });
    },
		saveLogin: function(login){
		  layui.data("author",{
		    key:"login",
		    value:login
		  });
		},
		edit: function(edit){
		  layui.data("author",{
		    key:"edit",
		    value:edit
		  });
		}
		,deledit: function(){
		  layui.data("author",{
		    key:"edit",
		    remove:true
		  });
		}
		,add: function(add){
		  layui.data("author",{
		    key:"add",
		    value:add
		  });
		}
		,deladd: function(){
		  layui.data("author",{
		    key:"add",
		    remove:true
		  });
    }
    ,savePlateForm:function(plateForm){
      layui.data("author",{
        key:"plateForm",
        value:plateForm
      })
    }
		,addStatic: function(statc){
		  layui.data("author",{
		    key:"statc",
		    value:statc
		  });
		}
		,delLogin: function(){
		  layui.data("author",{
		    key:"login",
		    remove:true
		  });
		}
    ,saveAuthorUsername: function(username){
      layui.data("author",{
        key:'username',
        value:username
      });
    }
    ,saveAuthorRoleName:function(roleName){
      layui.data("author",{
        key:'roleName',
        value:roleName
      });
    }
    ,saveAuthorPsw: function(psw){
      layui.data("author",{
        key:'psw',
        value:psw
      });
    }
    ,saveAuthorAdminUsername: function(username){
      layui.data("author",{
        key:'adminusername',
        value:username
      });
    }
    ,saveAuthorAdminPsw: function(psw){
      layui.data("author",{
        key:'adminpsw',
        value:psw
      });
    }
    ,saveAuthorId: function(id){
      layui.data("author",{
        key:'id',
        value:id
      });
    }
    //视频发布者的名称
    ,saveAuthorPublishname: function(publishname){
      layui.data("author",{
        key:'publishname',
        value:publishname
      });
    }
    ,saveAuthorNickname: function(nickname){
      layui.data("author",{
        key:'nickname',
        value:nickname
      });
    }
    //我的邀请码
    ,saveInvitationCode: function(invitationCode){
      layui.data("author",{
        key:'invitationCode',
        value:invitationCode
      });
    }
    //邀请人的编号
    ,saveInviterId: function(inviterId){
      layui.data("author",{
        key:'inviterId',
        value:inviterId
      });
    }
    , getQueryString: function (name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
      var r = window.location.search.substr(1).match(reg);
      if (r != null) return unescape(r[2]); return null;
    }
    , saveNickname: function (nickname) {
      layui.data("author", {
        key: 'nickname',
        value: nickname
      });
    }
    , saveVideoId: function (videoId) {
      layui.data("author", {
        key: 'videoId',
        value: videoId
      });
    }
    , savePrice: function (price) {
      layui.data("author", {
        key: 'price',
        value: price
      });
    }
    //缓存付费成功的订单
    , saveCompleteOrderId: function (videoId,orderId) {
      layui.data("author", {
        key: 'completeOrderId_'+videoId,
        value: orderId
      });
    }
    , saveWx: function (orderId,url) {
      layui.data("WX", {
        key: 'orderId',
        value: orderId
      });
      layui.data("WX", {
        key: 'url',
        value: url
      });
    }
    , saveAli: function (orderId,url) {
      layui.data("ALI", {
        key: 'orderId',
        value: orderId
      });
      layui.data("ALI", {
        key: 'url',
        value: url
      });
    }
    ,clearAuthorData: function (){
      layui.data('author', null);
    }
    ,liveWeixinTips: function() {
      //提示浏览器打开
      var winHeight = $(window).height();
      $(".weixin-tip").css("height", winHeight);
      $(".weixin-tip").show();
    }
  };
  
  $('#fensi_btn').click(function(){
      layer.alert('暂未开放', {title:"粉丝榜",icon: 0});
  });

  $('#kefu_btn').click(function(){
      layer.open({
          title:"客服QQ",
          type: 2,
          skin: 'layui-layer-molv',
          content: 'service.html',
          success: function(layero, index){
              var body = layer.getChildFrame('body', index);
              body.find('input').val('2247091019')
          }
      });
  });

  //退出登录
  $('#logout').click(function(){
    layui.data('author', null); //删除author表
    window.location.reload();
  });


  
  //加载特定模块
  if(layui.cache.page && layui.cache.page !== 'index'){
    var extend = {};
    extend[layui.cache.page] = layui.cache.page;
    layui.extend(extend);
    layui.use(layui.cache.page);
  }else{
    if (layui.data("author").nickname) {//已经登陆过
      $('#account').text(layui.data("author").nickname);

      //获取公告
      cjhd.json('/api/announcement', null, function(res){
        if(res.code == 0){
          $('#notice').text("公告："+res.object[0].content);
        };
      },{type:'get'});
    }
    
  }

  //手机设备的简单适配
  var treeMobile = $('.site-tree-mobile')
  ,shadeMobile = $('.site-mobile-shade')

  treeMobile.on('click', function(){
    $('body').addClass('site-mobile');
  });

  shadeMobile.on('click', function(){
    $('body').removeClass('site-mobile');
  });

  exports('cjhd', cjhd);

});

