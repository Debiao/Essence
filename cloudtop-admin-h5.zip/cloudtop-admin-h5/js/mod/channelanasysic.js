var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form','jquery','element','layer','laydate','laypage','util','cjhd'],function(exports){
	var form  = layui.form,
	$ = layui.jquery,
	element = layui.element,
	layer = layui.layer,
	laydate = layui.laydate,
	laypage = layui.laypage,
	util = layui.util,
	cjhd = layui.cjhd,
	flag_device = 0,
	flag_index = 0;
	Handlebars.registerHelper('timeChange',function(v1,opts){
		return userTineMode(v1);
	});
	laydate.render({
		elem:'#date',
		type:'date',
		range: '~',
		value:util.toDateString(new Date(new Date()-1000*60*60*24*30),'yyyy-MM-dd')+ ' ~ ' + util.toDateString(new Date(),'yyyy-MM-dd'),
		btn:'confirm',
		done:function(value){
			if(value!=""){
				var stime = value.split(' ~ ')[0],
					etime = value.split(' ~ ')[1],
					sdata = {start:stime,end:etime,platfrom:plateForm.platfrom};
					if(flag_device==0){
						$("#channel_chart").empty();
						$("#channel_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
						deviceData('/api-admin/channelanalysis/get/new/user/channel',sdata);	
					}else 
					if(flag_device==1){
						$("#channel_chart").empty();
						$("#channel_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
						deviceData('/api-admin/channelanalysis/get/active/user/channel',sdata);
					}
					if(flag_index==0){
						$("#theadList").empty();
						$("#tbodyList").empty();
						$("#page-template").empty();
						var url = '/api-admin/channelanalysis/get/count/index',
						tbodyDom = 'tbody-template_number',
						num = 5,
						headData = ['渠道名称','平台','今日新增','昨日新增','新增设备','活跃设备','累计设备','操作'];
						indexModel(url,sdata,tbodyDom,num,headData);
					}else 
					if(flag_index==1){
						$("#theadList").empty();
						$("#tbodyList").empty();
						$("#page-template").empty();
						var url = '/api-admin/channelanalysis/get/quality/index',
						tbodyDom = 'tbody-template_quality',
						num = 5,
						headData = ['渠道名称','平台','今日启动','今日活跃','昨日活跃','启动次数','人均启动次数','一次性用户占比','单次使用时长','操作'];
						indexModel(url,sdata,tbodyDom,num,headData);
					}
			}
		} 
	});
	
// 分页
	form.render('checkbox');
	var plateForm = layui.data('author').plateForm;
	if(JSON.stringify(plateForm)=="{}"){					  
		var str = "";
		str += '<div class="filter_icon" id="android">';
		str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		str += '<div class="filter_icon" id="iOS">';
		str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);
	}else 
	if(plateForm.platfrom=='iOS'){
	
		var str = "";
		str += '<div class="filter_icon" id="iOS">';
		str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);

		var checkbox = $('input[name="checkbox"]');
		checkbox.each(function(i,v){
			if(v.value ==plateForm.platfrom){

			}else{
				$(this).prop('checked',false);
			}
		});
		
	}else 
	if(plateForm.platfrom=='android'){

		var str = "";
		str += '<div class="filter_icon" id="android">';
		str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);
		var checkbox = $('input[name="checkbox"]');
		checkbox.each(function(i,v){
			if(v.value ==plateForm.platfrom){

			}else{
				$(this).prop('checked',false);
			}
		});
		
		
	}
	 //时长模板
	 function userTineMode(time){
		var hour = parseInt(time/(1000*60*60)),
		fen =parseInt((time/(1000*60*60) - hour)*60),
		miao = parseInt(((time/(1000*60*60) - hour)*60 - fen)*60);
		if(hour<10)
			hour = "0" + hour;
		if(fen<10)
			fen = "0" + fen;
		 if(miao<10)
			miao = "0" + miao; 
		   return hour + ":" + fen + ":" + miao; 
	}
	//平台选定
	var checked = $('input[name="checkbox"]:checked');
					checked.each(function(i,v){
						$(this).click(function(){
							var check = $('input[name="checkbox"]:not(:checked)');
							
							var _this = this.checked;
							if(_this == false){
								var ve = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var checked1 = $('input[name="checkbox"]:checked');
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(ve == idvalue){
										if(checked1.length<1){
											layer.msg("至少需选一种平台信息");
										}else{
											$("#"+idvalue).remove();
										}
										
									}
								});
							}else{	
								var vu = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(idvalue == vu){
										
									}else{
										if(check.length<=1){
											check.each(function(){
												$(this).prop('checked','checked');
											});
										}
										if(vu=='iOS'){
											var str = '';
												str += '<div class="filter_icon" id="iOS">';
												str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
												str += '</div>';
												$(".filter_left").append(str);
										}else
										if(vu == 'android'){
											var str = '';
												str += '<div class="filter_icon" id="android">';
												str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
												str += '</div>';
												$(".filter_left").append(str);
										}
										
									}
									
								});
							}
							
							
						});
					});	
	var check  = $('input[name="checkbox"]:not(checked)');
		check.each(function(i,v){
			$(this).click(function(){
				var _this = this.checked;
				if(_this == true){
					var ve = this.value;
					var len = $(".filter_left").children(".filter_icon").size();
						var arr =[];
						for(var i=0;i<=len-1;i++){
							arr[i] = i;
						}
						$.each(arr,function(i){
							var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
							// alert();
							if(ve == idvalue){
								
							}else{
								if(ve=='iOS'){
									var str = '';
										str += '<div class="filter_icon" id="iOS">';
										str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
										str += '</div>';
										$(".filter_left").append(str);
								}else
								if(ve == 'android'){
									var str = '';
										str += '<div class="filter_icon" id="android">';
										str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
										str += '</div>';
										$(".filter_left").append(str);
								}	
							}
						});
					}else{
							var vu = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var checke = $('input[name="checkbox"]:not(checked)');
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(vu == idvalue){
										if(checke.length<1){
											layer.msg("至少需选一种平台信息");
										}else{
											$("#"+idvalue).remove();
										}
										
									}
								});
				}
			});
		});	
		
	function conifg_chart(type,labels,datasets,responsive,title,tooltips,hover,scales){
		var config = {
			type:type,
			data:{
				labels:labels,
				datasets:datasets
			},
			options: {
				responsive:responsive,
				title:title,
				tooltips:tooltips,
				hover:hover,
				scales:scales
			}
		}
		return config;
	}	
	//新增设备
	var startTime = util.toDateString(new Date(new Date() - 30*24*60*60*1000),'yyyy-MM-dd'),
		endTime = util.toDateString(new Date(),'yyyy-MM-dd'),
		data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
	//设备折线model
	function deviceData(url,data){
		$.ajax({
			type:'post',
			url:url,
			data:data,
			dataType:'json',
			beforeSend:function(request){
				request.setRequestHeader('Authorization',layui.data('author').Authorization);
			},
			success:function(res){
				var data = [],labels=[];
				if(res.code == 0){
					data = res.data.clist;
				}
				if(data.length>0){
					var len = res.data.clist[0].ecList.length,channelName = [],allData = [],datasets=[];
					for(var n=0;n<len;n++){
						channelName.push(res.data.clist[0].ecList[n].channelName);
							var chanelTotal = [];
							labels.length = 0;
							for(var i in data){
								labels.push(data[i].time);
								chanelTotal.push(data[i].ecList[n].channelCount);	
							}
							allData.push(chanelTotal);	
					}
					var colors = ['#8960df','#FF7F50','#20B2AA','#00BFFF','#FF4500','#CD5C5C','#6A5ACD','#FFB6C1','#800080'];
					for(var m=0;m<channelName.length;m++){
						datasets.push(
							{
								label: channelName[m],
								backgroundColor:colors[m] ,
								borderColor: colors[m],
								data: allData[m],
								fill: false,
							}
						);
					
						var title = {
								display: true,
								text: ''
							},
							tooltips = {
								mode: 'index',
								intersect: false,
							},
							hover = {
								mode: 'nearest',
								intersect: true
							},
							scales = {
								xAxes: [{
									display: true,
									scaleLabel: {
										display: true,
										labelString: 'day'
									}
								}],
								yAxes: [{
									display: true,
									scaleLabel: {
										display: true,
										labelString: 'Value'
									}
								}]
							}	
						}
						var config = conifg_chart('line',labels,datasets,true,title,tooltips,hover,scales);
						var ctx = document.getElementById('sd_canvas').getContext('2d');
						window.myLine = new Chart(ctx, config);
				}
			}
		});//ajax

	}
	deviceData('/api-admin/channelanalysis/get/new/user/channel',data)		
	//新增设备事件
	$("#newAddDevice").on('click',function(){
		flag_device = 0;
		var time = $("#date").val(),
		startTime = time.split(' ~ ')[0],
		endTime = time.split(' ~ ')[1];
		var data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		$("#channel_chart").empty();
		$("#channel_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
		deviceData('/api-admin/channelanalysis/get/new/user/channel',data);	
	});
	//活跃设备事件
	$("#activeDevice").on('click',function(){
		flag_device = 1;
		var time = $("#date").val(),
		startTime = time.split(' ~ ')[0],
		endTime = time.split(' ~ ')[1],
		data = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		$("#channel_chart").empty();
		$("#channel_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
		deviceData('/api-admin/channelanalysis/get/active/user/channel',data);
	});
	//指标模板
	function indexModel(url,data,tbodyDom,num,headData){
		$.ajax({
			type:'post',
			url:url,
			data:data,
			dataType:'json',
			beforeSend:function(request){
				request.setRequestHeader('Authorization',layui.data('author').Authorization);
			},
			success:function(res){
				var dta = [];
				if(res.code == 0){
					dta = res.data.cdiList;
				}
				var headTepm = Handlebars.compile($("#thead-template").html());
				$("#theadList").html(headTepm(headData));
				if(dta.length>0){
					var tbodyTemp = Handlebars.compile($("#"+tbodyDom).html());
					$("#tbodyList").html(tbodyTemp(pageProce(dta,1,num)));
					$("#page-template").html('<div id="page"></div>');
					laypage.render({
						elem:'page',
						theme:'#1E9FFF',
						count:dta.length,
						limit:num,
						layout:['prev','page','next','count'],
						jump:function(obj,first){
							if(!first){
								$("#tbodyList").html(tbodyTemp(pageProce(dta,obj.curr,num)));
							}
						}
					});
				}else{
					$("#tbodyList").html('<tr><td colspan="'+headData.length+'">暂无数据</td></tr>');
				}
			}
		});
	}
	//数量指标
	var url = '/api-admin/channelanalysis/get/count/index',
		tbodyDom = 'tbody-template_number',
		num = 5,
		headData = ['渠道名称','平台','今日新增','昨日新增','新增设备','活跃设备','累计设备','操作'];
		indexModel(url,data,tbodyDom,num,headData);
	//数量指标
	$("#indexNumber").on('click',function(){
		flag_index = 0;
		$("#theadList").empty();
		$("#tbodyList").empty();
		$("#page-template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			numberData = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		var url = '/api-admin/channelanalysis/get/count/index',
		tbodyDom = 'tbody-template_number',
		num = 5,
		headData = ['渠道名称','平台','今日新增','昨日新增','新增设备','活跃设备','累计设备','操作'];
		indexModel(url,numberData,tbodyDom,num,headData);
	});
	//质量指标
	$("#indexQuality").on('click',function(){
		flag_index = 1;
		$("#theadList").empty();
		$("#tbodyList").empty();
		$("#page-template").empty();
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			qualityData = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
		var url = '/api-admin/channelanalysis/get/quality/index',
		tbodyDom = 'tbody-template_quality',
		num = 5,
		headData = ['渠道名称','平台','今日启动','今日活跃','昨日活跃','启动次数','人均启动次数','一次性用户占比','单次使用时长','操作'];
		indexModel(url,qualityData,tbodyDom,num,headData);
	});
	//操作下的详情(数量指标)
	form.on('submit(detailDataNumber)',function(data){
		var time = $("#date").val(),
			startTime = time.split(' ~ ')[0],
			endTime = time.split(' ~ ')[1],
			channelId = $('input[name="channel_id"]').val(),
			formData = {start:startTime,end:endTime,channelId:channelId};
			cjhd.edit(formData);	
			layer.open({
				type: 2,
				title: false,
				closeBtn: 0,
				shadeClose: true,
				area: ['100%', '100%'],
				content:'../../page/channelanasysic/channeldetail.html'
			});
		return false;
	});
	// //操作下的情况(质量指标)
	// form.on('submit(detailDataQuality)',function(data){
	// 	alert();
	// 	return false;
	// });
	//分页处理
	function pageProce(data,curr,num){
		var dta = [];
		return	dta.concat(data).splice(curr*num-num,num);
	}
	//渠道总览搜索
	$('#qu_seach').on('click',function(){
		alert('qu_seach:311');
	});
	//渠道总览qq_setup
	$('#qq_setup').on('click',function(){
		alert('qq_setup:315');
	});
	//渠道总览数据下载
	$('#qdzl_updown').on('click',function(){
		alert('下载:319');
	});
	//渠道总览鼠标移入事件
	$("#qdzl_help").on('mouseover',function(){
		$('#qdzl_movechange').css('display','block');
	});
	//渠道总览鼠标移出事件
	$("#qdzl_help").on('mouseout',function(){
		$('#qdzl_movechange').css('display','none');
	});

	//阻止时间冒泡
	function stopPropagation(e) {
		var ev = e || window.event;
		if (ev.stopPropagation) {
			ev.stopPropagation();
		}
		else if (window.event) {
			window.event.cancelBubble = true;//兼容IE
		}
	}
	$(".filter").on('click',function(e){
		$(".dropdown-content").show();
		stopPropagation(e);
	});
	$(document).bind('click',function(){
		$(".dropdown-content").hide();
		// $(".dropdown-content").slideUp('slow');
	});
	$(".dropdown-content").click(function (e) {
		stopPropagation(e);
	});
	//平台事件	
	$("#filter").on('click',function(){
		$(".dropdown-content").hide();
		var len = $(".filter_left").children(".filter_icon").size();
		if(len>1){
			cjhd.savePlateForm({});
			window.location.reload();
			return; 
		}else{
		var plate = $(".filter_left").children(".filter_icon").attr("id");
			//**** 平台查询*/
			cjhd.savePlateForm({platfrom:plate});
			window.location.reload();
			return;
			//*****end */
			}
	});
	$("#reback").on('click',function(){
		$(".dropdown-content").hide();
	});
	// 筛选
	var flag =0 ;
	$("#btn_screen").on('click',function(e){
		if(flag==0){
			$(".shaixuankuang").show();
			flag = 1;
			stopPropagation(e);
		}else{
			$(".shaixuankuang").hide();
			flag = 0;
			stopPropagation(e);
			
		}
	});
	$(document).bind('click',function(e){
		$(".shaixuankuang").hide();
	});
	$(".shaixuankuang").on('click',function(e){
		stopPropagation(e);
	});
	$("#shaixuankuang_down_qx").on('click',function(){
		$(".shaixuankuang").hide();
	});
	
    exports('channelanasysic',{});
});