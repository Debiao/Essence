var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
        table = layui.table,
        util = layui.util,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size: 10, sort: 'DESC', sortBy: 'id',page:0};
        Handlebars.registerHelper('formatDate',function(v1,opts){
            if(v1>0)
                return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
            else 
                return "";	
        });
        Handlebars.registerHelper('if_eq',function(v1, v2 ,opts){
              if(v1 == v2) 
                    return opts.fn(this);
              else
                    return opts.inverse(this);       
        });
        cjhd.json('/api-admin/point/find/all', data, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:10,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    data.page=obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/point/find/all', data, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            form.render();
                        }, { type: 'post' });
                        $("#tableList").empty();
                         var myTemplate = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(myTemplate(dta));
                    } 
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>"); 
        }
    //状态查询 
    var enableData= { size: 10, sort: 'DESC', sortBy: 'id',page:0};
    form.on('submit(searchByEnable)',function(data){
        $("#tableList").empty();
        $("#page-template").empty();
        $.extend(enableData,data.field);
        console.log(JSON.stringify(enableData));
        cjhd.json('/api-admin/point/find/all', enableData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
            if(dta.length>0){
                var myTemplate = Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        enableData.page=obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/point/find/all', enableData, function (res) {
                                dta = res.data.data;
                                count = res.data.total;
                                form.render();
                            }, { type: 'post' });
                            $("#tableList").empty();
                             var myTemplate = Handlebars.compile($("#table-template").html());
                            $("#tableList").html(myTemplate(dta));
                        } 
                    }
                });
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>"); 
            }
        return false;
    });
    //ID查询
    form.on('submit(searchByById)',function(){
        $("#tableList").empty();
        $("#page-template").empty();
        var id=$('input[name="id"]').val();
        cjhd.json('/api-admin/point/find/id',{id:id},function(res){
            dta=[res.data];
        },{type:'post'});
            if(dta.length>0){
                var myTemplate = Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>"); 
            }
        return false;
    });
    //全查
    var allData = { size: 10, sort: 'DESC', sortBy: 'id',page:0};
    form.on('submit(searchByAll)',function(data){
        $("#tableList").empty();
        $("#page-template").empty();
        cjhd.json('/api-admin/point/find/all', allData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:10,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    allData.page=obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/point/find/all', allData, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            form.render();
                        }, { type: 'post' });
                        $("#tableList").empty();
                         var myTemplate = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(myTemplate(dta));
                    } 
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>"); 
        }
        return false;
    });
    //用户id查询
    form.on('submit(searchByByuserId)',function(){
        var userId=$('input[name="userId"]').val();
        cjhd.json('/api-admin/cardbags/find/user',{userId:userId},function(res){
            dta=res.data.data;
            $('.news_content').html(tbody(dta));
        },{type:'post'});
        form.render(); 
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','60%'],
                content:'page/pointrace/addPointrace.html'
        });
        return false;
    });
   
	exports('pointrace', {});
	
});