layui.define(['form','jquery','layer','element','laydate','laypage','util','cjhd'],function(exports){

    var form = layui.form,
        $ = layui.jquery,
        layer = layui.layer,
        element = layui.element,
        laydate = layui.laydate,
        laypage = layui.laypage,
        util = layui.util,
        cjhd = layui.cjhd,
        chart_product_index = 0,
        chart_consume_index = 0,
        formList = [];
        colors = ['#8960df','#FF7F50','#20B2AA','#00BFFF','#FF4500','#CD5C5C','#6A5ACD','#FFB6C1','#800080'];

        var plateForm = layui.data('author').plateForm;
        if(JSON.stringify(plateForm)=="{}"){					  
            var str = "";
            str += '<div class="filter_icon" id="android">';
            str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
            str += '</div>';
            str += '<div class="filter_icon" id="iOS">';
            str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
            str += '</div>';
            $('.filter_left').html(str);
            formList = ['android','iOS'];

        }else 
        if(plateForm.platfrom=='iOS'){
        
            var str = "";
            str += '<div class="filter_icon" id="iOS">';
            str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
            str += '</div>';
            $('.filter_left').html(str);

            var checkbox = $('input[name="checkbox"]');
            checkbox.each(function(i,v){
                if(v.value ==plateForm.platfrom){

                }else{
                    $(this).prop('checked',false);
                }
            });
            formList = ['iOS'];
        }else 
        if(plateForm.platfrom=='android'){

            var str = "";
            str += '<div class="filter_icon" id="android">';
            str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
            str += '</div>';
            $('.filter_left').html(str);
            var checkbox = $('input[name="checkbox"]');
            checkbox.each(function(i,v){
                if(v.value ==plateForm.platfrom){

                }else{
                    $(this).prop('checked',false);
                }
            });
            
            formList = ['android'];
        }

        laydate.render({
            elem:'#date',
            type:'date',
            range:'~',
            value:util.toDateString(new Date(new Date()-30*24*60*60*1000),'yyyy-MM-dd')+' ~ '+util.toDateString(new Date(),'yyyy-MM-dd'),
            btn:'confirm',
            done:function(value){
                if(value!=""){
                    var start = value.split(' ~ ')[0],
                        end = value.split(' ~ ')[1];
                        //系统赠送总额
                        var url = '/api-admin/gold/get/amount/time',
                        labelName = '系统赠送总额',
                        labelStringX = '天',
                        labelStringY = '值',
                        cavasDom = 'sd_canvas';
                        if(chart_product_index==0){
                            chart_product_index = 0;
                            $("#productionTotal_chart").empty();
                            $("#productionTotal_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
                            var data = {plafromList:formList,type:'system_give',start:start,end:end};
                            chart_trendMode(url,data,labelName,labelStringX,labelStringY,cavasDom,colors[0]);  
                        }else 
                        if(chart_product_index==1){
                            $("#productionTotal_chart").empty();
                            $("#productionTotal_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
                            var data_userpay = {plafromList:formList,type:'user_pay',start:start,end:end};
                            chart_trendMode(url,data_userpay,'用户充值总额',labelStringX,labelStringY,cavasDom,colors[2]);
                        }
                        
                        //系统消耗总额
                        var dataComsump = {plafromList:formList,type:'system_collect',start:start,end:end},
                        labelName1 = '系统消耗总额',
                        cavasDom1 = 'sd_canvas_comsumption';
                        if(chart_consume_index==0){
                            $("#comsumptionTotal_chart").empty();
                            $("#comsumptionTotal_chart").html('<canvas id="sd_canvas_comsumption" style="width: 100%; height: 300px;"></canvas>');
                            chart_trendMode(url,dataComsump,labelName1,labelStringX,labelStringY,cavasDom1,colors[1]);
                        }else 
                        if(chart_consume_index==1){
                            $("#comsumptionTotal_chart").empty();
                            $("#comsumptionTotal_chart").html('<canvas id="sd_canvas_comsumption" style="width: 100%; height: 300px;"></canvas>');
                            var user_totalData = {plafromList:formList,type:'user_consume',start:start,end:end};
                            chart_trendMode(url,user_totalData,'用户消耗总额',labelStringX,labelStringY,cavasDom1,colors[5]);
                        }
                }
            }   
        });

        //平台选定
        var checked = $('input[name="checkbox"]:checked');
        checked.each(function(i,v){
            $(this).click(function(){
                var check = $('input[name="checkbox"]:not(:checked)');
                
                var _this = this.checked;
                if(_this == false){
                    var ve = this.value;
                    var len = $(".filter_left").children(".filter_icon").size();
                    var arr =[];
                    for(var i=0;i<=len-1;i++){
                        arr[i] = i;
                    }
                    $.each(arr,function(i){
                        var checked1 = $('input[name="checkbox"]:checked');
                        var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
                        if(ve == idvalue){
                            if(checked1.length<1){
                                layer.msg("至少需选一种平台信息");
                            }else{
                                $("#"+idvalue).remove();
                            }
                            
                        }
                    });
                }else{	
                    var vu = this.value;
                    var len = $(".filter_left").children(".filter_icon").size();
                    var arr =[];
                    for(var i=0;i<=len-1;i++){
                        arr[i] = i;
                    }
                    $.each(arr,function(i){
                        var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
                        if(idvalue == vu){
                            
                        }else{
                            if(check.length<=1){
                                check.each(function(){
                                    $(this).prop('checked','checked');
                                });
                            }
                            if(vu=='iOS'){
                                var str = '';
                                    str += '<div class="filter_icon" id="iOS">';
                                    str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
                                    str += '</div>';
                                    $(".filter_left").append(str);
                            }else
                            if(vu == 'android'){
                                var str = '';
                                    str += '<div class="filter_icon" id="android">';
                                    str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
                                    str += '</div>';
                                    $(".filter_left").append(str);
                            }
                            
                        }
                        
                    });
                }
                
                
            });
        });	
        var check  = $('input[name="checkbox"]:not(checked)');
        check.each(function(i,v){
        $(this).click(function(){
        var _this = this.checked;
        if(_this == true){
            var ve = this.value;
            var len = $(".filter_left").children(".filter_icon").size();
                var arr =[];
                for(var i=0;i<=len-1;i++){
                    arr[i] = i;
                }
                $.each(arr,function(i){
                    var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
                    // alert();
                    if(ve == idvalue){
                        
                    }else{
                        if(ve=='iOS'){
                            var str = '';
                                str += '<div class="filter_icon" id="iOS">';
                                str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
                                str += '</div>';
                                $(".filter_left").append(str);
                        }else
                        if(ve == 'android'){
                            var str = '';
                                str += '<div class="filter_icon" id="android">';
                                str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
                                str += '</div>';
                                $(".filter_left").append(str);
                        }	
                    }
                });
            }else{
                    var vu = this.value;
                        var len = $(".filter_left").children(".filter_icon").size();
                        var arr =[];
                        for(var i=0;i<=len-1;i++){
                            arr[i] = i;
                        }
                        $.each(arr,function(i){
                            var checke = $('input[name="checkbox"]:not(checked)');
                            var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
                            if(vu == idvalue){
                                if(checke.length<1){
                                    layer.msg("至少需选一种平台信息");
                                }else{
                                    $("#"+idvalue).remove();
                                }
                                
                            }
                        });
            }
            });
        });	

      //豆币橄榄
        $.ajax({
            type:'post',
            url:'/api-admin/gold/get/total/amount',
            data:{plafromList:formList},
            traditional:true,
            dataType:'json',
            beforeSend:function(request){
                request.setRequestHeader('Authorization',layui.data('author').Authorization);
            },
            success:function(res){
                if(res.code == 0){
                    $("#productionTotal").html(res.data.produceTotalAmount);
                    $("#comsumptionTotal").html(res.data.consumeTotalAmount);                           
                }
            }
        });  
       
    
      
       //折线模板
       function conifg_chart(type,labels,datasets,responsive,title,tooltips,hover,scales){
            var config = {
                type:type,
                data:{
                    labels:labels,
                    datasets:datasets
                },
                options: {
                    responsive:responsive,
                    title:title,
                    tooltips:tooltips,
                    hover:hover,
                    scales:scales
                }
            }
            return config;
        }	
       
        //趋势图模板
        function chart_trendMode(url,data,labelName,labelStringX,labelStringY,cavasDom,colors_chart){
            $.ajax({
                type:'post',
                url:url,
                data:data,
                dataType:'json',
                traditional:true,
                async:false,
                beforeSend:function(request){
                    request.setRequestHeader('Authorization',layui.data('author').Authorization);
                },
                success:function(res){
                    
                    var time=[],dta = [],total=[];
                    if(res.code ==0){
                       dta = res.data.dataStatGoldInfoList;
                    }
                   
                    if(dta.length>0){
                        for(var i in dta){
                            time.push(dta[i].time);
                            total.push(dta[i].totalAmount);
                        }
                
                    var  labels = time.reverse(),
                        datasets = [{
                            label:labelName,
                            backgroundColor:colors_chart,
                            borderColor:colors_chart,
                            data: total.reverse(),
                            fill: false,
                        }],
                         title = {
                            display: true,
                            text: ''
                        },
                        tooltips = {
                            mode: 'index',
                            intersect: false,
                        },
                        hover = {
                            mode: 'nearest',
                            intersect: true
                        },
                        scales = {
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: labelStringX
                                }
                            }],
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: labelStringY
                                }
                            }]
                        };
                        
                        var config = conifg_chart('line',labels,datasets,true,title,tooltips,hover,scales);
                        var ctx = document.getElementById(cavasDom).getContext('2d');
                        window.myLine = new Chart(ctx, config);
                    }
                }
            });
        }
        //系统赠送总额
        var url = '/api-admin/gold/get/amount/defult',
            data = {plafromList:formList,type:'system_give'},
            labelName = '系统赠送总额',
            labelStringX = '天',
            labelStringY = '值',
            cavasDom = 'sd_canvas';
        chart_trendMode(url,data,labelName,labelStringX,labelStringY,cavasDom,colors[0]);
        //系统赠送总额点击事件
        $("#system_zstotal").on('click',function(){
            chart_product_index = 0;
            $("#productionTotal_chart").empty();
            $("#productionTotal_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
            chart_trendMode(url,data,labelName,labelStringX,labelStringY,cavasDom,colors[0]);
        });
        //用户充值总额事件
        $("#user_paytotal").on('click',function(){
            chart_product_index = 1;
            $("#productionTotal_chart").empty();
            $("#productionTotal_chart").html('<canvas id="sd_canvas" style="width: 100%; height: 300px;"></canvas>');
            var data_userpay = {plafromList:formList,type:'user_pay'};
            chart_trendMode(url,data_userpay,'用户充值总额',labelStringX,labelStringY,cavasDom,colors[2]);
        });

       //系统消耗总额
            var dataComsump = {plafromList:formList,type:'system_collect'},
            labelName1 = '系统消耗总额',
            cavasDom1 = 'sd_canvas_comsumption';
            chart_trendMode(url,dataComsump,labelName1,labelStringX,labelStringY,cavasDom1,colors[1]);
        //系统消耗总额事件
        $("#system_xhtotal").on('click',function(){
            chart_consume_index = 0;
            $("#comsumptionTotal_chart").empty();
            $("#comsumptionTotal_chart").html('<canvas id="sd_canvas_comsumption" style="width: 100%; height: 300px;"></canvas>');
            chart_trendMode(url,dataComsump,labelName1,labelStringX,labelStringY,cavasDom1,colors[1]);
        });
        //用户消耗总额事件
        $("#user_xhtotal").on('click',function(){
            chart_consume_index = 1;
            $("#comsumptionTotal_chart").empty();
            $("#comsumptionTotal_chart").html('<canvas id="sd_canvas_comsumption" style="width: 100%; height: 300px;"></canvas>');
            var user_totalData = {plafromList:formList,type:'user_consume'};
            chart_trendMode(url,user_totalData,'用户消耗总额',labelStringX,labelStringY,cavasDom1,colors[5]);
        });
        //列表详情
         systemGiveData={plafromList:formList,type:'system_give',size:8,sort:'ASC',page:0};
         //列表模板
         function listTbleTem(data){
            $.ajax({
                type:'post',
                url:'/api-admin/gold/get/details/amount',
                data:data,
                dataType:'json',
                traditional:true,
                beforeSend:function(request){
                    request.setRequestHeader('Authorization',layui.data('author').Authorization);
                },
                success:function(res){
                    var dta = [],count;
                    if(res.code ==0){
                        dta = res.data.dataStatGoldInfoList;  
                        count = res.data.total;
                    }
                    var theadTemp = Handlebars.compile($("#thead-template").html());
                        $("#theadList").html(theadTemp(['用户名','数额','时间']));
                   if(dta.length>0){
                       var tbodyTemp = Handlebars.compile($("#tbody-template").html());
                       $("#tableList").html(tbodyTemp(dta));  
                       $("#page-template").html('<div id="page"></div>');
                       laypage.render({
                            elem:'page',
                            limit:systemGiveData.size,
                            count:count,
                            layout:['prev','page','next','count'],
                            jump:function(obj,first){
                                systemGiveData.page = obj.curr -1;
                                if(!first){
                                    $.ajax({
                                        type:'post',
                                        url:'/api-admin/gold/get/details/amount',
                                        data:data,
                                        dataType:'json',
                                        traditional:true,
                                        beforeSend:function(request){
                                            request.setRequestHeader('Authorization',layui.data('author').Authorization);
                                        },
                                        success:function(res){
                                            var dt = [];
                                            if(res.code==0){
                                                dt = res.data.dataStatGoldInfoList;
                                            }
                                            if(dt.length>0){
                                                $("#tableList").html(tbodyTemp(dt));  
                                            }else{
                                                $("#tableList").html('<tr><td colspan="3">暂无数据</td></tr>');
                                            }
                                        }
                                    });
                                }
                            }
                       })
                   }else{
                     $("#tableList").html('<tr><td colspan="3">暂无数据</td></tr>');
                   } 
                }
            });
         }
         listTbleTem(systemGiveData);
         var total_index = 0;
        //领币用户
        $("#getCurrentUser").on('click',function(){
            total_index = 0;
            $("#theadList").empty();
            $("#tableList").empty();
            $("#page-template").empty();
            var time = $('input[name="date"]').val(),
                start = time.split(' ~ ')[0],
                end = time.split(' ~ ')[1],
                userName = $('input[name="userName"]').val(),
                stime = $('input[name="time"]').val(),
                getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'system_give'};
                listTbleTem(getCurrentUserData);

        });
        //充值用户
        $("#payUser").on('click',function(){
            total_index = 1;
            $("#theadList").empty();
            $("#tableList").empty();
            $("#page-template").empty();
            var time = $('input[name="date"]').val(),
            start = time.split(' ~ ')[0],
            end = time.split(' ~ ')[1],
            userName = $('input[name="userName"]').val(),
            stime = $('input[name="time"]').val(),
            getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'user_pay'};
            listTbleTem(getCurrentUserData); 
        });
        //系统消耗
        $("#systmeConsume").on('click',function(){
            total_index = 2;
            $("#theadList").empty();
            $("#tableList").empty();
            $("#page-template").empty();
            var time = $('input[name="date"]').val(),
            start = time.split(' ~ ')[0],
            end = time.split(' ~ ')[1],
            userName = $('input[name="userName"]').val(),
            stime = $('input[name="time"]').val(),
            getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'system_collect'};
            listTbleTem(getCurrentUserData); 
        });
        //用户消耗
        $("#userConsume").on('click',function(){
            total_index = 3;
            $("#theadList").empty();
            $("#tableList").empty();
            $("#page-template").empty();
            var time = $('input[name="date"]').val(),
            start = time.split(' ~ ')[0],
            end = time.split(' ~ ')[1],
            userName = $('input[name="userName"]').val(),
            stime = $('input[name="time"]').val(),
            getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'user_consume'};
            listTbleTem(getCurrentUserData); 
        });
        //查询
        form.on('submit(searchByUserNameAndTime)',function(data){
             if(total_index==0){
                $("#theadList").empty();
                $("#tableList").empty();
                $("#page-template").empty();
                var time = $('input[name="date"]').val(),
                start = time.split(' ~ ')[0],
                end = time.split(' ~ ')[1],
                userName = $('input[name="userName"]').val(),
                stime = $('input[name="time"]').val(),
                getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'system_give'};
                listTbleTem(getCurrentUserData);   
             }else 
             if(total_index==1){
                $("#theadList").empty();
                $("#tableList").empty();
                $("#page-template").empty();
                var time = $('input[name="date"]').val(),
                start = time.split(' ~ ')[0],
                end = time.split(' ~ ')[1],
                userName = $('input[name="userName"]').val(),
                stime = $('input[name="time"]').val(),
                getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'user_pay'};
                listTbleTem(getCurrentUserData); 
             }else 
             if(total_index==2){
                $("#theadList").empty();
                $("#tableList").empty();
                $("#page-template").empty();
                var time = $('input[name="date"]').val(),
                start = time.split(' ~ ')[0],
                end = time.split(' ~ ')[1],
                userName = $('input[name="userName"]').val(),
                stime = $('input[name="time"]').val(),
                getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'system_collect'};
                listTbleTem(getCurrentUserData); 
             }else 
             if(total_index==3){
                $("#theadList").empty();
                $("#tableList").empty();
                $("#page-template").empty();
                var time = $('input[name="date"]').val(),
                start = time.split(' ~ ')[0],
                end = time.split(' ~ ')[1],
                userName = $('input[name="userName"]').val(),
                stime = $('input[name="time"]').val(),
                getCurrentUserData={plafromList:formList,page:0,size:8,sort:'ASC',start:start,end:end,userName:userName,time:stime,type:'user_consume'};
                listTbleTem(getCurrentUserData); 
             }                          
            return false;
        })
      

        //阻止时间冒泡
        function stopPropagation(e) {
            var ev = e || window.event;
            if (ev.stopPropagation) {
                ev.stopPropagation();
            }
            else if (window.event) {
                window.event.cancelBubble = true;//兼容IE
            }
        }

        //平台事件	
        $("#filter").on('click',function(){
            $(".dropdown-content").hide();
            var len = $(".filter_left").children(".filter_icon").size();
                if(len>1){
                    cjhd.savePlateForm({});
                    window.location.reload();
                    return; 
                }else{
                var plate = $(".filter_left").children(".filter_icon").attr("id");
                    //**** 平台查询*/

                    cjhd.savePlateForm({platfrom:plate});
                    window.location.reload();
                    return;

                    //*****end */
                }
        });
        $(".filter").on('click',function(e){
            $(".dropdown-content").show();
            // $(".dropdown-content").slideDown('slow');
            stopPropagation(e);
        });
        $(document).bind('click',function(){
            $(".dropdown-content").hide();
            // $(".dropdown-content").slideUp('slow');
        });
        $(".dropdown-content").click(function (e) {
            stopPropagation(e);
        });
		
		$("#reback").on('click',function(){
			$(".dropdown-content").hide();
		});

    
    exports('doucurrentytrendchart',{});
});