var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
        data = { size: 10,page:0,sortBy:'id'};
        Handlebars.registerHelper('if_eq',function(v1, v2, opts){
            if(v1 == v2)
                return opts.fn(this);
             else
                return opts.inverse(this);   
        });
	cjhd.json('/api-admin/faq/list/enable', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
    }, { type: 'post' });
    if(dta.length>0){
        var template = Handlebars.compile($("#table-template").html());
           $("#tableList").html(template(dta));
           $("#page-template").html('<div id="page"></div>'); 
           laypage.render({
               elem:'page',
               count:count,
               limit:data.size,
               layout:['prev','page','next','count'],
               jump:function(obj,first){
                   data.page = obj.curr - 1;
                   if(!first){
                        cjhd.json('/api-admin/faq/list/enable',data,function(res){
                            dta = res.data.data;
                            count = res.data.total;
                        },{type:'post'});
                            $("#tableList").empty();
                        var template = Handlebars.compile($("#table-template").html());
                            $("#tableList").html(template(dta)); 
                   }
               }
           });
    }else{
        $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
    }

    //启用状态查询
  var enableData = {page:0,size:10,sort:'DESC',sortBy:'id'}
    form.on('submit(searchByEnable)',function(){
        $("#tableList").empty();
        $("#page-template").empty();
        var enable = $("select[name='enable']").val();
            if(enable==1)
                enable = true;
            if(enable==2)
                enable = false;    
        enableData.enable = enable;
        console.log(JSON.stringify(enableData));
        cjhd.json('/api-admin/faq/list/enable',enableData,function(res){
            dta = res.data.data;
            count = res.data.total;
        },{type:'post'});
        if(dta.length>0){
            var template = Handlebars.compile($("#table-template").html());
            $("#tableList").html(template(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:enableData.size,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    enableData.page = obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/faq/list/enable',enableData,function(res){
                              dta = res.data.data;
                              count = res.data.total;  
                        },{type:'post'});
                        $("#tableList").empty();
                       var template = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(template(dta));
                    }   
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
        }
        return false;
    });
    //查看已删除状态数据
    delData = {page:0,size:10,sort:'DESC',sortBy:'id'}
    form.on('submit(searchByByQuestion)',function(){
        $("#tableList").empty();
        $("#page-template").empty();
        var questions = $('input[name="questions"]').val();
        delData.questions = questions;
        cjhd.json('/api-admin/faq/list/deleted',delData,function(res){
            dta = res.data.data;
            count = res.data.total;
        },{type:'post'});
        if(dta.length>0){
            var template = Handlebars.compile($("#table-template").html());
            $("#tableList").html(template(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:delData.size,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    delData.page = obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/faq/list/deleted',delData,function(res){
                            dta = res.data.data;
                            count = res.data.total;
                        },{type:'post'});
                        var template = Handlebars.compile($("#table-template").html())
                            $("#tableList").html(template(dta));
                    }
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
        }
        return false;
    });
    //关键字搜索常见问题
    keyWordData = {page:0,size:10,sort:'DESC',sortBy:'id'}
    form.on('submit(searchByKeyWord)',function(res){
        $("#tableList").empty();
        $("#page-template").empty();
        var questions_kw = $('input[name="questions_kw"]').val();
        keyWordData.questions = questions_kw;
        cjhd.json('/api-admin/faq/list/search',keyWordData,function(res){
            dta = res.data.data;
            count  = res.data.total;
        },{type:'post'});
        if(dta.length>0){
            $("#tableList").empty();
         var template = Handlebars.compile($("#table-template").html());
            $("#tableList").html(template(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:keyWordData.size,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    keyWordData.page = obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/faq/list/search',keyWordData,function(res){
                            dta = res.data.data;
                            count = res.data.total;
                        },{type:'post'});
                        var template = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(template(dta));
                    } 
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
        }
        return false;
    });
    //全查
    form.on('submit(searchByAll)',function(){

    });
	
    //ID查询
    form.on('submint(searchById)',function(){
        var name=$('input[name="id"]').val();
        cjhd.json('/api-admin/cardbags/find/id',{id:id},function(res){
            dta=[res.data];
            $('.news_content').html(tbody(dta));
        },{type:'post'});
           form.render(); 
        return false;
    });
    //用户id查询
    form.on('submit(searchByByuserId)',function(){
        var userId=$('input[name="userId"]').val();
        cjhd.json('/api-admin/cardbags/find/user',{userId:userId},function(res){
            dta=res.data.data;
            $('.news_content').html(tbody(dta));
        },{type:'post'});
        form.render(); 
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','40%'],
                content:'page/questionanser/addQuestionanser.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteQuestionanser)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/faq/remove',{id:id},function(res){
            if(res.code==0){
                location.reload();
            }else{
                layer.msg('服务器出错了...');
            }
        },{type:'post'});
        return false;
    });
    //编辑
    form.on('submit(editQuestionanser)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','40%'],
                content:'page/questionanser/editQuestionanser.html' 
        });
        return false;
    });
	exports('questionanser', {});
	
});