var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false,page:0};
	cjhd.json('/api-admin/gamearena/find/list', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
	}, { type: 'post' });
    if(dta.length>0){
        var gameservice_template = Handlebars.compile($("#gameservice_template").html());
        $("#tableList").html(gameservice_template(dta));
        $("#page-template").html('<div id="page"></div>');
        laypage.render({
            elem:'page',
            count:count,
            limit:data.size,
            layout:['prev','page','next','count'],
            jump:function(obj,first){
                data.page = obj.curr - 1;
                if(!first){
                    cjhd.json('/api-admin/',data,function(res){
                        dta = res.data.data;
                    },{type:'post'});
                   $("#tableList").html(gameservice_template(dta)); 
                }
            }
        });
    }else{
        $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
    }
   
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','50%'],
                content:'page/gameservice/addGameservice.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteGameService)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/gamearena/remove',{id:id},function(res){
            if(res.code==0){
                parent.layer.close(inx);
                parent.location.reload();
            }else{
                layer.msg('服务器出错了...');
                parent.layer.close();
            }
        },{type:'post'});
    });
   
	
	exports('gamesevice', {});
	
});