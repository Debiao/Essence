var dta = [],dictionData=[], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { sort: 'DESC' };
		Handlebars.registerHelper('eq_if',function(v1, v2, opts){
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);
		});
	cjhd.json('/api-admin/datadicts/find/all', data, function (res) {
		dictionData = res.data;
	}, { type: 'post' });
	if(dictionData.length>0){
		dataprocess(dictionData);
	var dt = findLimit(dta,1,num);
	var table_template = Handlebars.compile($("#template_table").html());
		$("#tableList").html(table_template(dt));
		form.render('checkbox');		
		$("#page-template").html('<div id="page"></div>');
		//分页条
		laypage.render({
			elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
			, count: dta.length //数据总数，从服务端得到
			, limit: num
			, layout: ['prev', 'page', 'next', 'count']
			, jump: function (obj, first) {
				//首次不执行
				if (!first) {
					var dd = findLimit(dta, obj.curr, num);
					$("#tableList").html(table_template(dd));
					form.render();
					//
				}
			}
		});
	}else{
		$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='10'>暂无数据</td></tr>");
	}
	

	//过滤查询
	form.on('submit(search)', function () {

		var tt = { id: $("#id").val() };
		cjhd.json('/api-admin/datadicts/find/id', tt, function (res) {

		}, { type: 'post' });
	});
	// 		数据处理
	function dataprocess(data) {
		dta.length = 0;
		if (data.length != 0) {
			for (var i in data) {
				dta = dta.concat(data[i]);
				if (data[i].children != 0) {
					dta = dta.concat(data[i].children);
				}
			}
		} else {
			console.log(data);
		}

	}

	//全选
	form.on('checkbox(allChoose)', function (data) {
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
		child.each(function (index, item) {
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	})
	//添加
	form.on('submit(add)', function (data) {
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '63%'],
			content: 'page/dictionary/addDictionary.html' //iframe的url
		});
		return false;
	})
	//删除
	form.on('submit(deleteDic)', function (data) {
		var id = $(data.elem).parents('tr').find('#data-id').attr('data-id');
		cjhd.json('/api-admin/datadicts/remove', {id:id}, function (res) {
			if (res.code == 0) {
				location.reload();
			} else {
				layer.msg("服务器出错了");
			}
		}, { type: 'post' });
	});
	//编辑
	form.on('submit(editDic)', function (data) {
		var id = $(data.elem).parents('tr').find('#data-id').attr('data-id');
		cjhd.edit(id);
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '63%'],
			content: 'page/dictionary/editDictionary.html' //iframe的url
		});

	});
	//批量删除
	form.on('submit(delete)', function () {
		var $checkbok = $('news_list tbody input[type="checkbox"][name="checked"]'),
			$checked = $('news_list tbody input[type="checkbox"][name="checked"]:checked'),
			id = "";
		if ($checkbok.is(":checked")) {
			for (var i = 0; i < $checked.length; i++) {
				for (var j = 0; j < dta.length; j++) {
					if (dta[j].id == $checked.eq(i).attr('data-id')) {
						var my = dta[i].id;
						if (id == "") {
							id += my;
						} else {
							id += "," + my;
						}
						form.render();
					}
				}
			}
		}
	});
	//分頁
	function findLimit(dta, curr, nums) {
		var dd = [];
		return dd.concat(dta).splice(curr * nums - nums, nums);
	}
	exports('dictionary', {});
	
});