var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		util = layui.util,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false,page:0},
		dataAll = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false },
		dataPlayerole = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false }
		userIdData = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false,page:0};
	Handlebars.registerHelper('formatDate',function(v1,opts){
		if(v1>0)
			return util.toDateString(v1);
		else 
			return "";	
	});
	cjhd.json('/api-admin/player/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
	}, { type: 'post' });
	if(dta.length>0){
		var myTemplate = Handlebars.compile($("#table-template").html());
		$('#tableList').html(myTemplate(dta));
		$('#page-template').html('<div id="page"></div>');
		laypage.render({
			elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
			, count: count //数据总数，从服务端得到
			, limit: 10
			, layout: ['prev', 'page', 'next', 'count']
			, jump: function (obj, first) {
				data.page = obj.curr - 1;
				//首次不执行
				if (!first) {
					console.log(data);
					cjhd.json('/api-admin/player/find/all', data, function (res) {
						dta = res.data.data;
						count = res.data.total;
						$('#tableList').empty();
						var myTemplate = Handlebars.compile($("#table-template").html());
						$('#tableList').html(myTemplate(dta));
					}, { type: 'post' });
					//
				}
			}
		});
	}else{
		$('#tableList').html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");

	}
	// 全查
	form.on('submit(searchAll)',function(){
		count=0;
		$('#tableList').empty();
		$('#page-template').empty();
		cjhd.json('/api-admin/player/find/all',dataAll,function(res){
			dta=res.data.data;
			count=res.data.total;
		},{type:'post'});
		if(dta.length>0){
			var myTemplate = Handlebars.compile($("#table-template").html());
			$('#tableList').html(myTemplate(dta));
			$('#page-template').html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				count:count,
				limit:10,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					dataAll.page=obj.curr-1;
					if(!first){
						console.log(dataAll);
						cjhd.json('/api-admin/player/find/all',dataAll,function(res){
							dta=res.data.data;
							count=res.data.total;
						},{type:'post'});	
						$('#tableList').empty();
						var myTemplate = Handlebars.compile($("#table-template").html());
						$('#tableList').html(myTemplate(dta));
					}
				}
			});
		}else{
			$('#tableList').html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
		}
		
		form.render();
		return false;
	});
	// id查询
	form.on('submit(searchById)',function(data){
		$('#tableList').empty();
		$('#page-template').empty();
		var playerId=$('input[name="playerId"]').val();
			playerId=parseInt(playerId);
		cjhd.json('/api-admin/player/find/id',{playerId:playerId},function(res){
			dta=[res.data];
		},{type:'post'});
		if(dta.length>0){
			var myTemplate = Handlebars.compile($("#table-template").html());
			$('#tableList').html(myTemplate(dta));
		}else{
			$('#tableList').html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
		}
		return false;
	});
	
	//用户id查询
	form.on('submit(searchByByUserId)',function(data){
		count=0;
		// alert(JSON.stringify(data.field));	
		$('#tableList').empty();
		$('#page-template').empty();
		var userId = $('input[name="userId"]').val();
			userIdData.userId=userId;
		cjhd.json('/api-admin/player/find/user',userIdData,function(res){
			dta=res.data.data;
			count= res.data.total;
		},{type:'post'});
		if(dta.length>0){
			var myTemplate = Handlebars.compile($("#table-template").html());
			$('#tableList').html(myTemplate(dta));
			$('#page-template').html('<div id="page"></div>');
			laypage.render({
						elem:'page',
						count:count,
						limit:10,
						layout:['prev','page','next','count'],
						jump:function(obj,first){
							userIdData.page=obj.curr-1;
							if(!first){
								console.log(userIdData);
								cjhd.json('/api-admin/player/find/all',userIdData,function(res){
									dta=res.data.data;
									count=res.data.total;
								},{type:'post'});	
								$('#tableList').empty();
								var myTemplate = Handlebars.compile($("#table-template").html());
								$('#tableList').html(myTemplate(dta));
							}
						}
			
				});
		}else{
			$('#tableList').html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
		}
		
		return false;
	});	
	
	exports('playerrole', {});
	
});