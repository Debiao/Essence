var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['layer','jquery','form','element','laypage','cjhd','laydate','util'],function(exports){
    var layer = layui.layer,
    $ = layui.jquery,
    form = layui.form,
    element = layui.element,
    laypage = layui.laypage,
    cjhd = layui.cjhd,
    laydate = layui.laydate,
    util = layui.util;
    laydate.render({ 
        elem:'#start_first',
        type:'datetime'
      });
    laydate.render({
        elem:'#end_first',
        type:'datetime'
    });
    laydate.render({
        elem:'#start_second',
        type:'datetime'
    });
    laydate.render({
        elem:'#end_second',
        type:'datetime'
    });
    Handlebars.registerHelper('formatDate',function(v1,opts){
        if(v1>0)
            return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
         else
            return "";   
    });
   var  dataAddress = {page:0,size:10,sort:'DESC'};
   form.on('submit(search_first)',function(){
    var start = $('input[name="start_first"]').val();
    var end = $('input[name="end_first"]').val();
    var tableData = {},col = ['编号','真实地址|人数'],row = [];
        start =  Date.parse(new Date(start));
        end = Date.parse(new Date(end));
        dataAddress.start = start;
        dataAddress.end = end;
      cjhd.json('/api-admin/data/get/address/time',dataAddress,function(res){
            dta = res.data.data;
            count = res.data.total;
      },{type:'post'});
        if(dta.length>0){
            tableData.col = col;
            tableData.row = dta;
            var template = Handlebars.compile($("#template_first").html());
            $("#tableList_first").html(template(tableData));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:dataAddress.size,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    dataAddress.page = obj.curr - 1;
                    if(!first){
                           cjhd.json('/api-admin/data/get/address/time',dataAddress,function(res){
                                dta = res.data.data;
                                count = res.data.total;
                           },{type:'post'}); 
                           $("#tableList_first").empty();
                           tableData.row = dta;
                           var template =  Handlebars.compile($("#template_first").html());
                           $("#tableList_first").html(template(tableData));
                    }  
                }
            });
       }else{
            $("#tableList_first").html('<tr class="tbody" style="height:40px;"><td colspan="5">暂无数据</td></tr>');
       }    
    return false;
   });
   //真实地址
    $("#realAddress").on('click',function(){
        location.reload();
    });
    //冻结金额
    $("#freezingAmount").on('click',function(){
        $("#searchFilter").empty();
       $("#tableList_first").empty();
       $("#page-template").empty();
       var str ="";
            str += '<label class="layui-form-label">开始时间:</label>';
            str += '<div class="layui-input-inline" >';
            str += '<input type="text" name="start_first" id="start_first" class="layui-input">';
            str += '</div>';
            str += '<label class="layui-form-label">结束时间:</label>';
            str += '<div class="layui-input-inline" >';
            str += '<input type="text" name="end_first" id="end_first" class="layui-input">';
            str += '</div>';
            str += '<div class="layui-input-inline">';
            str += '<button class="layui-btn" lay-submit lay-filter="search_freezingAmountData">查询</button>';
            str += '</div>';
            $("#searchFilter").html(str);
            form.render();
            laydate.render({ 
                elem:'#start_first',
                type:'datetime'
              });
            laydate.render({
                elem:'#end_first',
                type:'datetime'
            }); 
    
    });
    var freezingAmountData = {pape:0,size:10,sort:'ASC'};
    form.on('submit(search_freezingAmountData)',function(){
        var start = $('input[name="start_first"]').val();
        var end = $('input[name="end_first"]').val();
            start = Date.parse(new Date(start)); 
            end = Date.parse(new Date(end));
            console.log(start);
            console.log(end);
            freezingAmountData.start  = start;
            freezingAmountData.end = end;
            var tableData = {},col = ['编号','参赛费','信息服务费','总金额','创建时间'],row = []; 
            cjhd.json('/api-admin/data/get/frozen/time',freezingAmountData,function(res){
                 dta  = res.data.data;
                 count = res.data.total;   
            },{type:'post'});
            if(dta.length>0){
                row = dta;
                tableData.col = col;
                tableData.row = row;
                var template = Handlebars.compile($('#template_freezingAmountData').html());
                $("#tableList_first").html(template(tableData));
            }else{
                $("#tableList_first").html('<tr class="tbody"><td colspan="2">暂无数据</td></tr>'); 
            }
        return false;
    });
    // //用户资金
    // $("#userCapital").on('click',function(){
        
        
    // });
    // //各赛场在线人数
    // $("#courtNumber").on('click',function(){
        
        
    // });
    // //参赛费
    // $("#courtMoney").on('click',function(){
        
        
    // });
    // //玩家性别
    // $("#playerGender").on('click',function(){
        
        
    // });
    // //斗号消耗
    // $("#douConsume").on('click',function(){
        
        
    // });
    // //在线时长
    // $("#onlineTime").on('click',function(){
        
        
    // });
    // //在线人数
    // $("#onlinePeople").on('click',function(){
        
        
    // });
    // //兑换战利品
    // $("#exchangezlp").on('click',function(){
        
        
    // });
    // //来源
    // $("#source").on('click',function(){
        
        
    // });
    // //各战场小队
    // $("#everyTeam").on('click',function(){
        
        
    // });
    // //登录用户
    // $("#loginUser").on('click',function(){
        
        
    // });
    // //匹配
    // $("#matching").on('click',function(){
        
        
    // });
    exports('raletedinfo',{});
});