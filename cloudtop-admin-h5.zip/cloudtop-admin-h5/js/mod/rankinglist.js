var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate','element', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		element= layui.element,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { size: 10,userId:$("input[name='userId']").val(),page:0};
		Handlebars.registerHelper('if_eq',function(v1, v2, opts){
            if(v1 == v2)
                return opts.fn(this);
             else
                return opts.inverse(this);   
        });
		element.on('tab(test1)', function(){
			var layId=this.getAttribute('lay-id');
			if(layId==1){
				$("#tableList-zl").empty();
				$("#page-template-zl").empty();
				var ziData={page:0,size:10};		
					cjhd.json('/api-admin/ranking/find/fundsFlow', ziData, function (res) {
						dta = res.data.data;
						count = res.data.total;
						form.render();
					}, { type: 'post' });
					if(dta.length>0){
						var zlTemplate = Handlebars.compile($("#table-zl-template").html());
						$("#tableList-zl").html(zlTemplate(dta));
						$("#page-template-zl").html('<div id="page"></div>');
						laypage.render({
							elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
							, count: count //数据总数，从服务端得到
							, limit: 10
							, layout: ['prev', 'page', 'next', 'count']
							, jump: function (obj, first) {
								ziData.page = obj.curr - 1;
								//首次不执行
								if (!first) {
									cjhd.json('/api-admin/ranking/find/fundsFlow', ziData, function (res) {
										dta = res.data.data;
										count = res.data.total;
									}, { type: 'post' });
									$("#tableList-zl").empty();
									var zlTemplate = Handlebars.compile($("#table-zl-template").html());
									$("#tableList-zl").html(zlTemplate(dta));
									//
								}
							}
						});
					}else{
						$("#tableList-zl").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
					}

			}else
			if(layId==2){
				var tableHeaderdw=['排名','编号','头像','昵称'];
				var tableHeaderTemplate = Handlebars.compile($("#table-header-template").html());
					$("#table-header-dw").html(tableHeaderTemplate(tableHeaderdw));	
				var dwData={page:0,size:10};
				//段位榜
				cjhd.json('/api-admin/ranking/grade', dwData, function (res) {
					dta = res.data.data;
					count = res.data.total;
					form.render();
				}, { type: 'post' });
				if(dta.length>0){
					$("#tableList-dw").empty();
					var dwTemplate = Handlebars.compile($("#table-dw-template").html());
					$("#tableList-dw").html(dwTemplate(dta));
					$("#page-template-dw").html('<div id="page-dw" style="float:right;"></div>');
					laypage.render({
						elem: 'page-dw' //注意，这里的 test1 是 ID，不用加 # 号
						, count: count //数据总数，从服务端得到
						, limit: 10
						, layout: ['prev', 'page', 'next', 'count']
						, jump: function (obj, first) {
							dwData.page = obj.curr - 1;
							//首次不执行
							if (!first) {
								// console.log(data);
								cjhd.json('/api-admin/ranking/grade', dwData, function (res) {
									dta = res.data.data;
									count = res.data.total;
								}, { type: 'post' });
								$("#tableList-dw").empty();
								var zlTemplate = Handlebars.compile($("#table-dw-template").html());
								$("#tableList-dw").html(zlTemplate(dta));		
								//
							}
						}
					});
				}else{
					$("#tableList-dw").html("<tr class='tbody' style='height:40px;'><td colspan='4'>暂无数据</td></tr>");
				}	
			}else
			if(layId==3){
				var tableHeaderKda=['排名','编号','头像','昵称'];
				var tableHeaderTemplate = Handlebars.compile($("#table-header-template").html());
				$("#table-header-kda").html(tableHeaderTemplate(tableHeaderKda));	
			}else 
			if(layId==4){
				//积分榜
				var tableHeaderJf=['排名','编号','头像','昵称','游戏','比赛次数','积分','是否关注'];
				var tableHeaderTemplate = Handlebars.compile($("#table-header-template").html());
				$("#table-header-jf").html(tableHeaderTemplate(tableHeaderJf));	
				var jfData={page:0,size:10};
				cjhd.json('/api-admin/ranking/point', jfData, function (res) {
					dta = res.data.data;
					count = res.data.total;
					form.render();
				}, { type: 'post' });
				if(dta.length>0){
					var jfTemplate = Handlebars.compile($("#table-jf-template").html());
					$("#tableList-jf").html(jfTemplate(dta));
					$("#page-template-jf").html('<div id="page-jf" style="float:right;"></div>');
					laypage.render({
					elem: 'page-jf' //注意，这里的 test1 是 ID，不用加 # 号
					, count: count //数据总数，从服务端得到
					, limit: 10
					, layout: ['prev', 'page', 'next', 'count']
					, jump: function (obj, first) {
						jfData.page = obj.curr - 1;
						//首次不执行
						if (!first) {
							cjhd.json('/api-admin/ranking/point', jfData, function (res) {
								dta = res.data.data;
								count = res.data.total;
							}, { type: 'post' });
								$("#tableList-jf").empty();
								var jfTemplate = Handlebars.compile($("#table-jf-template").html());
								$("#tableList-jf").html(jfTemplate(dta));	
							}
						}
					});
				}else{
					$("#tableList-jf").html("<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
				}
			}else 
			if(layId==5){
				//财富榜
				var tableHeaderCf=['排名','编号','头像','昵称','财富'];
				var tableHeaderTemplate = Handlebars.compile($("#table-header-template").html());
				$("#table-header-cf").html(tableHeaderTemplate(tableHeaderCf));
				var wealthData={page:0,size:10};	
				cjhd.json('/api-admin/ranking/wealth', wealthData, function (res) {
					dta = res.data.data;
					count = res.data.total;
					form.render();
				}, { type: 'post' });
				if(dta.length>0){
					var cfTemplate = Handlebars.compile($("#table-cf-template").html());
					$("#tableList-cf").html(cfTemplate(dta));
					$("#page-template-cf").html('<div id="page-cf" style="float:right;"></div>');
					laypage.render({
						elem: 'page-cf' //注意，这里的 test1 是 ID，不用加 # 号
						, count: count //数据总数，从服务端得到
						, limit: 10
						, layout: ['prev', 'page', 'next', 'count']
						, jump: function (obj, first) {
							wealthData.page = obj.curr - 1;
							//首次不执行
							if (!first) {
								cjhd.json('/api-admin/ranking/wealth', wealthData, function (res) {
									$("#tableList-cf").empty();
									dta = res.data.data;
									count = res.data.total;
									var cfTemplate = Handlebars.compile($("#table-cf-template").html());
									$("#tableList-cf").html(cfTemplate(dta));
								}, { type: 'post' });
								//
							}
						}
					});
				}else{
					$("#tableList-cf").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
				}
				
			}
		});	
	//资历榜
	$("#table-header-zl").empty();
	var tableHeaderZl=['排名','编号','头像','昵称'];
	var tableHeaderTemplate = Handlebars.compile($("#table-header-template").html());
		$("#table-header-zl").html(tableHeaderTemplate(tableHeaderZl));	
	var ziData={page:0,size:10};		
	cjhd.json('/api-admin/ranking/find/fundsFlow', ziData, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
	}, { type: 'post' });
	if(dta.length>0){
		var zlTemplate = Handlebars.compile($("#table-zl-template").html());
		$("#tableList-zl").html(zlTemplate(dta));
		$("#page-template-zl").html('<div id="page"></div>');
		laypage.render({
			elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
			, count: count //数据总数，从服务端得到
			, limit: 10
			, layout: ['prev', 'page', 'next', 'count']
			, jump: function (obj, first) {
				ziData.page = obj.curr - 1;
				//首次不执行
				if (!first) {
					cjhd.json('/api-admin/ranking/find/fundsFlow', ziData, function (res) {
						dta = res.data.data;
						count = res.data.total;
					}, { type: 'post' });
					$("#tableList-zl").empty();
					var zlTemplate = Handlebars.compile($("#table-zl-template").html());
					$("#tableList-zl").html(zlTemplate(dta));
				}
			}
		});
	}else{
		$("#tableList-zl").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
	}
	// //执行一个laypage实例
	
	//资历userID查询
	var userIdData={page:0,size:10};
	form.on('submit(search)',function(){
		$("#table-header-zl").empty();
		$("#tableList-zl").empty();
		$("#page-template-zl").empty();
		var tableHeaderZl=['排名','编号','头像','昵称'];
		var tableHeaderTemplate = Handlebars.compile($("#table-header-template").html());
		$("#table-header-zl").html(tableHeaderTemplate(tableHeaderZl));	
		var userId = $("input[name=userId]").val();
		if(userId!=""){
			userIdData.userId = userId;
		}else{
			delete userIdData.userId;
		}
		console.log(JSON.stringify(userIdData));
		cjhd.json('/api-admin/ranking/find/fundsFlow', userIdData, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length>0){
			var zlTemplate = Handlebars.compile($("#table-zl-template").html());
			$("#tableList-zl").html(zlTemplate(dta));
			$("#page-template-zl").html('<div id="page"></div>');
			laypage.render({
				elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					userIdData.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						cjhd.json('/api-admin/ranking/find/fundsFlow', userIdData, function (res) {
							dta = res.data.data;
							count = res.data.total;
						}, { type: 'post' });
						$("#tableList-zl").empty();
						var zlTemplate = Handlebars.compile($("#table-zl-template").html());
						$("#tableList-zl").html(zlTemplate(dta));
						//
					}
				}
			});
		}else{
			$("#tableList-zl").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
			
		}
		form.render();
		return false;
	});
	
	//段位查询
	var dwData={size:10,page:0};
	form.on('submit(search_duan)',function(){
		$("#tableList-dw").empty();
		$("#page-template-dw").empty();
		dwData.userId=$("input[name=userId_dw]").val();
		dwData.gameId=$("input[name='gameId_dw']").val()
		cjhd.json('/api-admin/ranking/grade', dwData, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length>0){
			$("#tableList-dw").empty();
			var dwTemplate = Handlebars.compile($("#table-dw-template").html());
			$("#tableList-dw").html(dwTemplate(dta));
			$("#page-template-dw").html('<div id="page-dw" style="float:right;"></div>');
			laypage.render({
				elem: 'page-dw' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					dwData.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						// console.log(data);
						cjhd.json('/api-admin/ranking/grade', dwData, function (res) {
							dta = res.data.data;
							count = res.data.total;
						}, { type: 'post' });
						$("#tableList-dw").empty();
						var zlTemplate = Handlebars.compile($("#table-dw-template").html());
						$("#tableList-dw").html(zlTemplate(dta));		
						//
					}
				}
			});	
		}else{
			$("#tableList-dw").html("<tr class='tbody' style='height:40px;'><td colspan='4'>暂无数据</td></tr>");
		}	
		return false;	
	});
	//kda查询
	var kdaData={size:10,page:0};
	form.on('submit(search_kda)',function(){
		//KDA榜
		kdaData.userId =$("input[name='KDAId_kda']").val();
		kdaData.gameId =$("input[name='gameId_kda']").val(); 
		kdaData.KDAId=$("input[name='userId_kda']").val();
		cjhd.json('/api-admin/ranking/kda', kdaData, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		form.render();
		if(dta.length>0){
			$("#tableList-kda").empty();
			console.log(JSON.stringify(dta));
			var dwTemplate = Handlebars.compile($("#table-kda-template").html());
			$("#tableList-kda").html(dwTemplate(dta));
			$("#page-template-kda").html('<div id="page-kda" style="float:right;"></div>');
			laypage.render({
				elem: 'page-kda' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					kdaData.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						// console.log(data);
						cjhd.json('/api-admin/ranking/kda', kdaData, function (res) {
							dta = res.data.data;
							count = res.data.total;
						}, { type: 'post' });
						$("#tableList-kda").empty();
						var kdaTemplate = Handlebars.compile($("#table-kda-template").html());
						$("#tableList-kda").html(kdaTemplate(dta));		
						//
					}
				}
			});
		}else{
			$("#tableList-kda").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
		}	
		return false;
	});
	
	
	//积分查询
	var pointData={size:10,page:0};
	form.on('submit(search_jf)',function(){
		$("#tableList-jf").empty();
		$("#page-template-jf").empty();
		pointData.userId=$("input[name='userId_jf']").val();
		cjhd.json('/api-admin/ranking/point', pointData, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length>0){
			$("#tableList-jf").empty();
			console.log(JSON.stringify(dta));
			var jfTemplate = Handlebars.compile($("#table-jf-template").html());
			$("#tableList-jf").html(jfTemplate(dta));
			$("#page-template-jf").html('<div id="page-jf" style="float:right;"></div>');
			laypage.render({
				elem: 'page-jf' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					pointData.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						// console.log(data);
						cjhd.json('/api-admin/ranking/point', pointData, function (res) {
							dta = res.data.data;
							count = res.data.total;
						}, { type: 'post' });
						$("#tableList-jf").empty();
						var jfTemplate = Handlebars.compile($("#table-jf-template").html());
						$("#tableList-jf").html(jfTemplate(dta));		
						//
					}
				}
			});
		}else{
			$("#tableList-jf").html("<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
		}	
		form.render();
		return false;
	});
	//财富榜
	var cfData={size:10,page:0};
	form.on('submit(search_cf)',function(){
		cfData.userId=$("input[name='userId_cf']").val();
		cjhd.json('/api-admin/ranking/wealth', cfData, function (res) {
			dta = res.data.data;
			count = res.data.total;
		}, { type: 'post' });
		if(dta.length>0){
			var cfTemplate = Handlebars.compile($("#table-cf-template").html());
			$("#tableList-cf").html(cfTemplate(dta));
			$("#page-template-cf").html('<div id="page-cf" style="float:right;"></div>');
			// //执行一个laypage实例
			laypage.render({
				elem: 'page-cf' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					cfData.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						console.log(cfData);
						cjhd.json('/api-admin/ranking/wealth', cfData, function (res) {
							$("#tableList-cf").empty();
							dta = res.data.data;
							count = res.data.total;
							var cfTemplate = Handlebars.compile($("#table-cf-template").html());
							$("#tableList-cf").html(cfTemplate(dta));
						}, { type: 'post' });
						//
					}
				}
			});
		}else{
			$("#tableList-cf").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
		}
			form.render();
			return false;
	})
	exports('rankinglist',{});
	
});