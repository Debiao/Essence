var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
        table = layui.table,
        util = layui.util,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size: 10, sort: 'DESC', sortBy: 'id',enable:true };
        Handlebars.registerHelper('formatDate',function(v1,opts){
               if(v1>0){
                return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
               } 
                return ""; 
        });
        Handlebars.registerHelper('if_eq',function(v1 ,v2 ,opts){
            if(v1 == v2)
                return opts.fn(this);
            else 
                return opts.inverse(this);    
        });
        cjhd.json('/api-admin/carousel/find/enable', data, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
           var template = Handlebars.compile($("#table-template").html());
           $("#tableList").html(template(dta));
           $("#page-template").html('<div id="page"></div>');
           laypage.render({
               elem:'page',
               count:count,
               limit:data.size,
               layout:['prev','page','next','count'],
               jump:function(obj,first){
                    data.page = obj.curr - 1;
                    if(!first){
                         cjhd.json('/api-admin/carousel/find/enable',data,function(res){
                            dta = res.data.data;
                            count = res.data.total;
                         },{type:'post'});
                         $("#tableList").empty();
                         var template = Handlebars.copile($("#table-template").html());
                         $("#tableList").html(template(dta));
                    }
               }    
           });
        }else{
           $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
        }
	
    //启用状态查询
    var enableData = { size: 10, sort: 'DESC', sortBy: 'id',enable:true };
    form.on('submit(searchByEnable)',function(){
        $("#tableList").empty();
        var enable=$('select[name="enable"]').val();
            if(enable==1){
                enable='true';  
            }else if(enable==2){
                enable='false';  
            }
            enableData.enable=enable;
        cjhd.json('/api-admin/carousel/find/enable',enableData,function(res){
            dta=res.data.data;
            count = res.data.total;
        },{type:'post'});
        if(dta.length>0){
            var template = Handlebars.compile($("#table-template").html());
            $("#tableList").html(template(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:enableData.size,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    enableData.page = obj.curr - 1;
                    cjhd.json('/api-admin/carousel/find/enable',enableData,function(res){
                        dta = res.data.data;
                        count = res.data.total;
                    },{type:'post'});
                      $("#tableList").empty();  
                    var template = Handlebars.compile($("#table-template").html());
                      $("#tableList").html(template(dta));  
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
        }
        form.render(); 
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','60%'],
                content:'page/rotationchart/addrotationchart.html'
        });
        return false;
    });
   
   
    //删除
    form.on('submit(deleteRotationchart)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/carousel/delete/id',{id:id},function(res){
            if(res.code==0){
               location.reload();
            }else{
               layer.msg('服务器出错了...');
            }
        },{type:'post'});
        return false;
    });
    //编辑
    form.on('submit(editRotationchart)',function(data){
        var id=$(data.elem).parents('tr').find('.id').text(),
        img=$(data.elem).parents('tr').find('.img').attr("src"),
        title=$(data.elem).parents('tr').find('.title').text(),
        details=$(data.elem).parents('tr').find('.details').text(),
        enable=$(data.elem).parents('tr').find('.enable').text(),
         carouselTime=$(data.elem).parents('tr').find('.carouselTime').text();
        if(enable=='禁用'){
            enable = false;
        }else if(enable=='启用'){
            enable = true;
        }
         var formData={
                    id:id,
                    img:img,
                    title:title,
                    details:details,
                    enable:enable,
                    carouselTime:carouselTime
                };    
        cjhd.edit(formData);  
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['400px','40%'],
                content:'page/rotationchart/editrotationchart.html' 
        });
        return false;
    });
     //禁启用状态编辑
    form.on('submit(prohibitRotationchart)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text(),
        enable=$(data.elem).parents('tr').find('.enable').text();
        form.render();
            if(enable=='禁用'){
                enable=true;
            }else if(enable=='启用'){
                enable=false;
            }
        cjhd.json('/api-admin/carousel/change/id',{id:id,enable:enable},function(res){
            if(res.code==0){
               location.reload();
            }else{
                layer.msg('服务器出错了...');
            }
        },{type:'post'});
        return false;
    });
   
	exports('rotationchart', {});
	
});