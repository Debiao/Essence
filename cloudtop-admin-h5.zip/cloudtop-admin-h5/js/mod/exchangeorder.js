var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		util = layui.util,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false };
		Handlebars.registerHelper('if_eq',function(v1, v2, opts){
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);
		});
		Handlebars.registerHelper('formatDate',function(v1, opts){
			if(v1>0)
				return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
			else
				return "";	
		});
		cjhd.json('/api-admin/redeemorder/find/list', data, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length>0){
			var myTemplate = Handlebars.compile($("#table-template").html()); 
				 $("#tableList").html(myTemplate(dta));	
				 $("#page-template").html('<div id="page"></div>');
				 laypage.render({
					 elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
					 , count: count //数据总数，从服务端得到
					 , limit: 10
					 , layout: ['prev', 'page', 'next', 'count']
					 , jump: function (obj, first) {
						 data.page = obj.curr - 1;
						 //首次不执行
						 if (!first) {
							 console.log(data);
							 cjhd.json('/api-admin/redeemorder/find/list', data, function (res) {
								 dta = res.data.data;
								 count = res.data.total;
								 $("#tableList").empty();
								 var myTemplate = Handlebars.compile($("#table-template").html()); 
								 $("#tableList").html(myTemplate(dta));	
							 }, { type: 'post' });
						 }
					 }
				 });
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='12'>暂无数据</td></tr>");

		}
	//订单全查
	var allData={page:0,deleted:false,size:10,sort:'DESC',sortBy:'id'}
	form.on('submit(searchOrderAll)',function(){
		$("#tableList").empty();
		$("#page-template").empty();
		cjhd.json('/api-admin/redeemorder/find/list',allData,function(res){
			dta=res.data.data;
			count=res.data.total;
		},{type:'post'});
		if(dta.length>0){
			var myTemplate=Handlebars.compile($("#table-template").html());
				$("#tableList").html(myTemplate(dta));
				$("#page-template").html('<div id="page"></div>');
				laypage.render({
					elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
					, count: count //数据总数，从服务端得到
					, limit: 10
					, layout: ['prev', 'page', 'next', 'count']
					, jump: function (obj, first) {
						allData.page = obj.curr - 1;
						//首次不执行
						if (!first) {
							console.log(allData);
							cjhd.json('/api-admin/redeemorder/find/list', allData, function (res) {
								dta = res.data.data;
								count = res.data.total;
								$("#tableList").empty();
								var myTemplate = Handlebars.compile($("#table-template").html()); 
								$("#tableList").html(myTemplate(dta));	
							}, { type: 'post' });
							//
						}
					}
				});
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='12'>暂无数据</td></tr>");
		}	
		return false;
	});
	//用户id查询
	var userIdData={page:0,size:10,sort:'DESC',sortBy:'id'};
	form.on('submit(searchByUserId)', function(){
		$("#tableList").empty();
		$("#page-template").empty();
		var userId = $('input[name="userId"]').val();
		userIdData.userId=userId;
				cjhd.json('/api-admin/redeemorder/find/user',userIdData, function (res) {
					dta = res.data.data;
					count =res.data.total;
					form.render();
				}, { type: 'post' });
				if(dta.length>0){
					var myTemplate=Handlebars.compile($("#table-template").html());
						$("#tableList").html(myTemplate(dta));
						$("#page-template").html('<div id="page"></div>');
						laypage.render({
							elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
							, count: count //数据总数，从服务端得到
							, limit: 10
							, layout: ['prev', 'page', 'next', 'count']
							, jump: function (obj, first) {
								userIdData.page = obj.curr - 1;
								//首次不执行
								if (!first) {
									console.log(userIdData);
									cjhd.json('/api-admin/redeemorder/find/user', userIdData, function (res) {
										dta = res.data.data;
										count = res.data.total;
										$("#tableList").empty();
										var myTemplate = Handlebars.compile($("#table-template").html()); 
										$("#tableList").html(myTemplate(dta));	
									}, { type: 'post' });
									//
								}
							}
						});
					}else{
						$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='12'>暂无数据</td></tr>");
				}	
		return false;	
	});
	//订单签收
	form.on('submit(searchByOrderSigin)',function(){
		var roId=$('input[name="roId"]').val();
		cjhd.json('/api-admin/redeemorder/received/id', {roId:roId}, function (res) {
			if(res.code==0){
                layer.msg("签收成功");
            }
			form.render();
		}, { type: 'post' });
		return false;
	});
	//发货订单
	form.on('submit(searchOrderShipment)',function(){
        cjhd.add("0");
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '40%'],
			content: 'page/exchangeorder/editExchangeorder.html' //iframe的url
        });
        return false;
	});
	
	//过滤查询
	form.on('submit(search)', function () {

		var tt = { id: $("#id").val() };
		cjhd.json('/api-admin/datadicts/find/id', tt, function (res) {

		}, { type: 'post' });
	});
	// 		数据处理
	function dataprocess(data) {
		dta.length = 0;
		if (data.length != 0) {
			for (var i in data) {
				dta = dta.concat(data[i]);
				if (data[i].children != 0) {
					dta = dta.concat(data[i].children);
				}
			}
		} else {
			console.log(data);
		}

	}

	//全选
	form.on('checkbox(allChoose)', function (data) {
		console.log(data);
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
		child.each(function (index, item) {
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	})
	//订单地址编辑保存
	form.on('submit(saveOrderShipment)',function (data) {	
         cjhd.deladd();
		var formData = data.field;
		cjhd.json('/api-admin/redeemorder/shipped/id',formData,function(res) {
			if (res.code == 0) {
				parent.layer.close(inx);
				parent.location.reload();
			} else {
				layer.msg("服务器出错了...");
				parent.layer.close(inx);
			}
		}, { type: 'post' });	

	});
	
	
	//添加
	form.on('submit(add)', function (data) {
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '40%'],
			content: 'page/blacklist/addBlacklist.html' //iframe的url
		});
	})
	//删除
	form.on('submit(deleteBlacklist)', function (data) {
		var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.json('/api-admin/blacklist/deleted', { id: id }, function (res) {
			if (res.code == 0) {
				layer.msg("删除成功");
				parent.location.reload();
			} else {
				layer.msg("服务器出错了");
			}
		}, { type: 'post' });
	});
	//编辑
	form.on('submit(editDic)', function (data) {
		var id = $(data.elem).parents('tr').find('.userId').text();
		cjhd.edit(id);
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '63%'],
			content: 'page/exchangeorder/editExchangeorder.html' //iframe的url
		});

	});
	//批量删除
	form.on('submit(delete)', function () {
		var $checkbok = $('news_list tbody input[type="checkbox"][name="checked"]'),
			$checked = $('news_list tbody input[type="checkbox"][name="checked"]:checked'),
			id = "";
		if ($checkbok.is(":checked")) {
			for (var i = 0; i < $checked.length; i++) {
				for (var j = 0; j < dta.length; j++) {
					if (dta[j].id == $checked.eq(i).attr('data-id')) {
						var my = dta[i].id;
						console.log(my);
						if (id == "") {
							id += my;
						} else {
							id += "," + my;
						}
						form.render();
					}
				}
			}
		}
	});
	function findLimit(dta, curr, nums) {
		var dd = [];
		return dd.concat(dta).splice(curr * nums - nums, nums);
	}
	exports('exchangeorder', {});
	
});