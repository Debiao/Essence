var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
	data = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false,page:0};
	cjhd.json('/api-admin/address/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
	}, { type: 'post' });
	if(dta.length>0){
		var myTemplate=Handlebars.compile($("#table-template").html());
		$("#tableList").html(myTemplate(dta));	
		$("#page-template").html('<div id="page"></div>');
	//执行一个laypage实例
		laypage.render({
			elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
			, count: count //数据总数，从服务端得到
			, limit: 10
			, layout: ['prev', 'page', 'next', 'count']
			, jump: function (obj, first) {
				data.page = obj.curr - 1;
				//首次不执行
				if (!first) {
					console.log(JSON.stringify(data));
					cjhd.json('/api-admin/address/find/all', data, function (res) {
						dta = res.data.data;
						count = res.data.total;
						console.log(res.data);
						$("#tableList").empty();
						var myTemplate=Handlebars.compile($("#table-template").html());
						$("#tableList").html(myTemplate(dta));			
					}, { type:'post'});
					//
				}
			}
		});
	}else{
		$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
	}

	//全查
	var allData = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false,page:0};
	form.on('submit(searchAll)',function(){
		$("#tableList").empty();
		$("#page-template").empty();
		cjhd.json('/api-admin/address/find/all',allData,function(res){
			dta=res.data.data;
			count=res.data.total;
			form.render();
		},{type:'post'});
		if(dta.length>0){
			var myTemplate=Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));
			$("#page-template").html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				count:count,
				limit:10,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					allData.page=obj.curr-1;
					if(!first){
						cjhd.json('/api-admin/address/find/all',allData,function(res){
							dta=res.data.data;
							count=res.data.total;
							$("#tableList").empty();
							var myTemplate=Handlebars.compile($("#table-template").html());
								$("#tableList").html(myTemplate(dta));
						},{type:'post'});
					}
				}
			});
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
		}
		
		return false;
	});
	//地址id查询
	form.on('submit(searchByAddressId)', function(){
		$("#tableList").empty();
		$("#page-template").empty();
		var id = $('input[name="id"]').val();
				cjhd.json('/api-admin/address/find/id', {addressId:id}, function (res) {
					if(res.data==""){
						dta=[];
					}
					dta = [res.data];
					form.render();
				}, { type: 'post' });
		if(dta.length>0){
			var myTemplate=Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));		
		}else{
			$("#tableList").html("<tr class='tbody'><td colspan='5'>暂无数据</td></tr>");
		}
		return false;	
	});
	//用户id查询
	var useridData={page:0,size:10,sort:'DESC',sortBy:'id',deleted:false}
	form.on('submit(searchByByUserId)',function(){
		$("#tableList").empty();
		$("#page-template").empty();
		var userId=$('input[name="userId"]').val();
		useridData.userId=userId;
		cjhd.json('/api-admin/address/find/user',useridData, function (res) {
			dta = res.data.data;
			count=res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length>0){
			var myTemplate=Handlebars.compile($("#table-template").html());
				$("#tableList").html(myTemplate(dta));
				$("#page-template").html('<div id="page"></div>');
				laypage.render({
					elem:'page',
					count:count,
					limit:10,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						useridData.page=obj.curr-1;
						if(!first){
							cjhd.json('/api-admin/address/find/user',useridData,function(res){
								dta=res.data.data;
								count=res.data.total;
								var myTemplate=Handlebars.compile($("#table-template").html());
									$("#tableList").html(myTemplate(dta));
							},{type:'post'});
						}
					}
				});	
			}else{
				$("#tableList").html("<tr class='tbody'><td colspan='5'>暂无数据</td></tr>");
		}
		return false;
	});
	


	
	//添加
	form.on('submit(add)', function (data) {
		cjhd.add("0");
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '40%'],
			content: 'page/blacklist/addBlacklist.html' //iframe的url
		});
	})
	//删除
	form.on('submit(deleteBlacklist)', function (data) {
		var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.json('/api-admin/blacklist/deleted', { id: id }, function (res) {
			if (res.code == 0) {
				layer.msg("删除成功");
				parent.location.reload();
			} else {
				layer.msg("服务器出错了");
			}
		}, { type: 'post' });
	});
	//编辑
	form.on('submit(editDic)', function (data) {
		var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.edit(id);
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['500px', '63%'],
			content: 'page/blacklist/editBlacklist.html' //iframe的url
		});

	});
	//批量删除
	form.on('submit(delete)', function () {
		var $checkbok = $('news_list tbody input[type="checkbox"][name="checked"]'),
			$checked = $('news_list tbody input[type="checkbox"][name="checked"]:checked'),
			id = "";
		if ($checkbok.is(":checked")) {
			for (var i = 0; i < $checked.length; i++) {
				for (var j = 0; j < dta.length; j++) {
					if (dta[j].id == $checked.eq(i).attr('data-id')) {
						var my = dta[i].id;
						if (id == "") {
							id += my;
						} else {
							id += "," + my;
						}
						form.render();
					}
				}
			}
		}
	});
	exports('haverstaddress', {});
	
});