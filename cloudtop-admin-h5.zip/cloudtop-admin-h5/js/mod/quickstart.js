var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size: 15, sort: 'DESC', sortBy: 'id',deleted:false };
        Handlebars.registerHelper('if_eq',function(v1, v2, opts){
            if(v1 == v2)
                return opts.fn(this);
            else
                return opts.inverse(this);
        });
        cjhd.json('/api-admin/quickstart/find/all', data, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:10,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    data.page=obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/quickstart/find/all', data, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                        }, { type: 'post' });
                        $("#tableList").empty(); 
                        var myTemplate = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(myTemplate(dta));
                    } 
                }
            });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");    
        }
     //全查
    var allData = { size: 15, sort: 'DESC', sortBy: 'id',deleted:false };
    form.on('submit(searchAll)',function(){
            $("#tableList").empty();
            $("#page-template").empty();
            cjhd.json('/api-admin/quickstart/find/all',allData,function(res){
                dta=res.data.data;
                count=res.data.total;
            },{type:'post'});
            if(dta.length>0){
                var myTemplate=Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));  
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        allData.page=obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/quickstart/find/all', allData, function (res) {
                                dta = res.data.data;
                                count = res.data.total;
                            }, { type: 'post' });
                            $("#tableList").empty(); 
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $("#tableList").html(myTemplate(dta));
                        } 
                    }
                });
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
            }
        return false;
    });
    //id查询
    form.on('submit(searchById)',function(data){
        $("#tableList").empty();
        $("#page-template").empty();
        var qsId=$('input[name="qsId"]').val();
        cjhd.json('/api-admin/quickstart/find/id',{qsId:qsId},function(res){
                dta=[res.data];
            },{type:'post'});
            if(dta.length==0||dta[0]==""){
                $("#tableList").html("<tr class='tbody'><td colspan='11'>暂无数据</td></tr>");
            }else{
                $("#tableList").empty(); 
                var myTemplate = Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
            }
        return false;
    });
    //序列查
  form.on('submit(searchBySequence)',function(data){
    $("#tableList").empty();
    $("#page-template").empty();
    var sequence=$('input[name="sequence"]').val();
    cjhd.json('/api-admin/quickstart/find/sequence',{sequence:sequence},function(res){
        dta=[res.data];
    },{type:'post'});
    if(dta.length>0){
        var myTemplate = Handlebars.compile($("#table-template").html());
        $("#tableList").html(myTemplate(dta));
    }else{
        $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
    }
    return false;
  });
    
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','50%'],
                content:'page/quickstart/addQuickstart.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteQuickstart)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/quickstart/remove',{qsId:id},function(res){
            if(res.code==0){
                location.reload();
            }else{
                layer.msg('服务器出错了...');
            }
        },{type:'post'});
    });
    //编辑
    form.on('submit(editQuickstart)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','55%'],
                content:'page/quickstart/editQuickstart.html' 
        });
        return false;
    });
    //修改序列
    form.on('submit(editQuickstartSequence)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','35%'],
                content:'page/quickstart/editQuickstartSequence.html' 
        });
        return false;
    });
	exports('quickstart', {});
	
});