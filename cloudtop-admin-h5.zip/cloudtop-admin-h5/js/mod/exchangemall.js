var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size:10, sort: 'DESC', sortBy: 'id',deleted:false };
        Handlebars.registerHelper('if_eq',function(v1, v2, opts){
            if(v1 == v2)
                return opts.fn(this);
            else
                return opts.inverse(this);     
        });
            cjhd.json('/api-admin/redeemitem/find/list', data, function (res) {
                dta = res.data.data;
                count = res.data.total;
                form.render();
            }, { type: 'post' });
            if(dta.length>0){
                var myTemplate = Handlebars.compile($("#table-template").html());
                    $("#tableList").html(myTemplate(dta));
                    $("#page-template").html('<div id="page"></div>');

                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count //数据总数，从服务端得到
                        , limit: 10
                        , layout: ['prev', 'page', 'next', 'count']
                        , jump: function (obj, first) {
                            data.page = obj.curr - 1;
                            //首次不执行
                            if (!first) {
                                // console.log(data);
                                cjhd.json('/api-admin/redeemitem/find/list', data, function (res) {
                                    dta = res.data.data;
                                    count = res.data.total;
                                }, { type: 'post' });
                                $("#tableList").empty();
                                var myTemplate = Handlebars.compile($("#table-template").html());
                                $("#tableList").html(myTemplate(dta));
                            }
                        }
                    });
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
            }
    //启用状态查询
    var enableData =  { size:10, sort:'DESC',sortBy:'id',deleted:false,enable:true};
          form.on('submit(searchByAll)',function(data){
                $("#tableList").empty();
                $("#page-template").empty();
                $.extend(enableData,data.field);
                cjhd.json('/api-admin/redeemitem/find/list', enableData, function (res) {
                    dta = res.data.data;
                    count = res.data.total;
                    form.render();
                }, { type: 'post' });
                if(dta.length>0){
                    var myTemplate = Handlebars.compile($("#table-template").html());
                    $("#tableList").html(myTemplate(dta));
                    $("#page-template").html('<div id="page"></div>');
                    laypage.render({
                        elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                        , count: count //数据总数，从服务端得到
                        , limit: 10
                        , layout: ['prev', 'page', 'next', 'count']
                        , jump: function (obj, first) {
                            enableData.page = obj.curr - 1;
                            //首次不执行
                            if (!first) {
                                // console.log(data);
                                cjhd.json('/api-admin/redeemitem/find/list', enableData, function (res) {
                                    dta = res.data.data;
                                    count = res.data.total;
                                }, { type: 'post' });
                                $("#tableList").empty();
                                var myTemplate = Handlebars.compile($("#table-template").html());
                                $("#tableList").html(myTemplate(dta));
                            }
                        }
                    });
                }else{
                    $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
                }
            return false;
          });  
    //ID查询
    form.on('submit(searchById)',function(data){ 
        $("#tableList").empty();
        $("#page-template").empty();
        cjhd.json('/api-admin/redeemitem/find/id',data.field,function(res){
            dta=[res.data];
        },{type:'post'});
           form.render();
          if(dta.length==0||dta[0]==""){
            $("#tableList").html("<tr class='tbody'><td colspan='8'>暂无数据</td></tr>");
          }else{
            var myTemplate = Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
          }  
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['650px','70%'],
                content:'page/exchangemall/addExchangemall.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteExchangemall)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/redeemitem/remove/id',{id:id},function(res){
            if(res.code==0){
                parent.layer.close(inx);
                parent.location.reload();
            }else{
                layer.msg('服务器出错了...');
                parent.layer.close();
            }
        },{type:'post'});
    });
    //编辑
    form.on('submit(editExchangemall)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['650px','70%'],
                content:'page/exchangemall/editExchangemall.html' 
        });
        return false;
    });
	exports('exchangemall', {});
	
});