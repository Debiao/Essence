var dta = [], count;
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery;
	data = { size: 10, sort: 'ASC', sortBy: 'id',page:0 };
	Handlebars.registerHelper('exchange',function(v1,opts){
		if(v1.length>0){
			var str = "";
			for(var i in v1){
				if(v1[i]=="ROLE_USER"){
					if(str == ""){
						str += "普通用户";
					}else{
						str += ",普通用户";
					}
				}else
				if(v1[i]=="ROLE_ADMIN"){
					if(str == ""){
						str += "管理员";
					}else{
						str += ",管理员";
					}
				 }else
				if(v1[i]=="ROLE_SUPERADMIN"){
					if(str == ""){
						str += "超级管理员";
					}else{
						str += ",超级管理员";
					}
				}else
				if(v1[i]=="ROLE_STAFF"){
					if(str == ""){
						str += "客服";
					}else{
						str += ",客服";
					}
				}else
				if(v1[i]=="ROLE_OPERATE"){
					if(str == ""){
						str += "运维";
					}else{
						str += ",运维";
					}
				}
			}
			return str
		}
		return "";
	});
	cjhd.json('/api-admin/user/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
	}, { type: 'post' });
	if(dta.length>0){
		var myTemplate=Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));
			$("#page-template").html('<div id="page"></div>');
			laypage.render({
					elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
					, count: count //数据总数，从服务端得到
					, limit: 10
					, layout: ['prev', 'page', 'next', 'count']
					, jump: function (obj, first) {
						//obj包含了当前分页的所有参数，比如：
						// 				console.log(obj.curr+":&&&&&&&"); //得到当前页，以便向服务端请求对应页的数据。
						// 				console.log(obj.limit+":*******"); //得到每页显示的条数
						data.page = obj.curr - 1;
						//首次不执行
						if (!first) {
							console.log(data);
							cjhd.json('/api-admin/user/find/all', data, function (res) {
								dta = res.data.data;
								count = res.data.total;
								var myTemplate=Handlebars.compile($("#table-template").html());
								$("#tableList").html(myTemplate(dta));
							}, { type: 'post' });
							//
						}
					}
				});
	}else{
		$("#tableList").html("<tr class='tbody'><td colspan='4'>暂无数据</td></tr>");
	}
//添加
	form.on('submit(add)',function(){
		layer.open({
			type:2,
			title:'',
			shadeClose:true,
			shade:0.8,
			area:['500px','50%'],
			content:'page/user/addUser.html'
		})
		return false;
	});	
//删除
	
form.on('submit(delUser)',function(data){
	var id = $(data.elem).parents('tr').find('.id').text();
	cjhd.json('/api-admin/user/remove',{id:id},function(res){
		if(res.code == 0){
			location.reload();
		}else{
			layer.msg("服务器出错了..");
		}
	},{type:'post'});
	return false;
});	
//编辑
form.on('submit(editUser)',function(data){
	var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.edit(id);
		layer.open({
			type:2,
			title:'',
			shadeClose:true,
			area:['500px','30%'],
			content:'page/user/editMoney.html'
		});
	return false;
});	
// 充值
form.on('submit(payMoney)',function(data){
	var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.edit(id);
		layer.open({
			type:2,
			title:'',
			shadeClose:true,
			area:['500px','30%'],
			content:'page/user/payMoney.html'
		});
	return false;	
});			

	exports('userList', {});
});
