var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { size: 10, sort: 'ASC', sortBy: 'id',deleted:false };
		Handlebars.registerHelper('if_eq',function(v1, v2, opts){
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);	
		});
	cjhd.json('/api-admin/mail/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
	}, { type: 'post' });
	if(dta.length>0){
		var emailTemplate = Handlebars.compile($("#table-template").html());
			$("#tableList").html(emailTemplate(dta));
			$("#page-template").html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				count:count,
				limit:10,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					data.page=obj.curr-1;
					if(!first){
						cjhd.json('/api-admin/mail/find/all',data,function(res){
							dta=res.data.data;
							count=res.data.total;
						},{type:'post'});
							$("#tableList").empty();
							var emailTemplate = Handlebars.compile($("#table-template").html());
							$("#tableList").html(emailTemplate(dta));	
					}
				}
			});
	}else{
		$("#tableList").html('<tr style="height:40px;"><td colspan="5"></td></tr>');
	}

	
	
	//id查询
	form.on('submit(searchById)', function(){
			$("#tableList").empty();
			$("#page-template").empty();
			var id = $('input[name="id"]').val();
			cjhd.json('/api-admin/mail/find/id', {mailId:id}, function (res) {
				dta = [res.data];
				form.render();
			}, { type: 'post' });
			if(dta.length>0){
				var template = Handlebars.compile($("#table-template").html());
					$("#tableList").html(template(dta));
			}else{
				$('#tableList').html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
			}
		return false;	
	});
	
	//全查询
	form.on('submit(searchAll)',function(){

	});
	
	//添加
	form.on('submit(add)', function (data) {
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['650px', '37%'],
			content: 'page/email/addEmail.html' //iframe的url
		});
	})
	//删除
	form.on('submit(deleteEmail)',function(data){
		var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.json('/api-admin/mail/remove/id', { mailId : id }, function (res) {
			if (res.code == 0) {
				layer.msg("删除成功");
				parent.location.reload();
			} else {
				layer.msg("服务器出错了");
			}
		}, { type: 'post' });
		return false;
	});
	
	//发送邮电
	form.on('submit(sendEmail)',function(data){
		var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.edit(id);
		layer.open({
			type: 2,
			title: '',
			shadeClose: true,
			shade: 0.8,
			area: ['650px', '47%'],
			content: 'page/email/sendEmail.html' //iframe的url
		});
		return false;
	});
	
	exports('email', {});
	
});