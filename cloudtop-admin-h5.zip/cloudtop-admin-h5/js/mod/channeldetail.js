layui.define(['form','jquery','laypage','laydate','util','element','cjhd'],function(exports){
    var form = layui.form,
        $ = layui.jquery,
        laypage = layui.laypage,
        laydate = layui.laydate,
        util = layui.util,
        element = layui.element,
        cjhd  = layui.cjhd;
        //获取传值参数
        var formData = layui.data('author').edit; 
        laydate.render({
            elem:'#date',
            type:'date',
            range: '~',
            value:util.toDateString(new Date(new Date()-1000*24*60*60*30),'yyyy-MM-dd')+' ~ '+ util.toDateString(new Date(),'yyyy-MM-dd'),
            btn:'confirm',
            done:function(value){
                if(value!=""){
                    var startTime = value.split(' ~ ')[0],
                        endTime = value.split(' ~ ')[1],
                        data = {start:startTime,end:endTime,channelId:formData.channelId};
                        overviewMode(data);
                        $("#tableList").empty();
                        $("#page-template").empty();
                        dataDetailMode(data);
                }  
            }
        });			
        form.render('checkbox');
    
        
          //数据详情
          function dataDetailMode(data){
              var dta = [];
               cjhd.json('/api-admin/channelanalysis/get/channel/trend/details',data,function(res){
                if(res.code == 0){
                    dta = res.data.dataList;
                }
               },{type:'post'}); 
               if(dta.length>0){
                    var table_Template = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(table_Template(pageProce(dta,1,5))); 
                        $("#page-template").html('<div id="page"></div>');
                        laypage.render({
                            elem:'page',
                            count:dta.length,
                            limit:5,
                            layout:['prev','page','next','count'],
                            jump:function(obj,first){
                                if(!first){
                                    $("#tableList").html(table_Template(pageProce(dta,obj.curr,5)));
                                }
                            }
                        });
                }else{
                    $("#tableList").html('<tr><td conspan="6">暂无数据</td></tr>'); 
    
                }
          }
          dataDetailMode(formData);   
        //渠道信息橄榄
       function  overviewMode(data){
           $.ajax({
               type:'post',
               url:'/api-admin/channelanalysis/get/channel/details/overview',
               data:data,
               dataType:'json',
               beforeSend:function(request){
                   request.setRequestHeader('Authorization',layui.data('author').Authorization);
               },
               success:function(res){
                   var data = null;
                   if(res.code == 0){
                       data = res.data;
                   }
                   if(data!=null){
                       $("#channelDetail").text(data.channelName);
                       $("#channelTotalCount").text(data.channelTotalCount);
                       $("#weekIncrease").text(data.weekIncrease+"%");
                       $("#weekActive").text(data.weekActive+"%");
                       $("#monthIncrease").text(data.monthIncrease+"%");
                       $("#monthActive").text(data.monthActive+"%");
                       var hour = parseInt(data.channelUseTime/(1000*60*60)),
                           fen =parseInt((data.channelUseTime/(1000*60*60) - hour)*60),
                           miao = parseInt(((data.channelUseTime/(1000*60*60) - hour)*60 - fen)*60);
                           if(hour<10)
                               hour = "0" + hour;
                           if(fen<10)
                               fen = "0" + fen;
                            if(miao<10)
                               miao = "0" + miao;      
                       $("#channelUseTime").text(hour+":"+fen+":"+miao);
                   }else{
   
                   }
               }
           });
       }
       overviewMode(formData);
        //时长模板
        function userTineMode(time){
            var hour = parseInt(time/(1000*60*60)),
            fen =parseInt((time/(1000*60*60) - hour)*60),
            miao = parseInt(((time/(1000*60*60) - hour)*60 - fen)*60);
            if(hour<10)
                hour = "0" + hour;
            if(fen<10)
                fen = "0" + fen;
             if(miao<10)
                miao = "0" + miao; 
               return hour + ":" + fen + ":" + miao; 
        }
        //图表模板
        function chartModel(type,labels,datasets,responsive,title,tooltips,hover,scales){
            var config ={
                type:type,
                data: {
                    labels:labels,
                    datasets:datasets
                },
                options: {
                 responsive: responsive,
                 title:title,
                 tooltips:tooltips,
                 hover:hover,
                 scales:scales
                 }
             }
             return config;
         } 
        //数据趋势
       //1.新增设备
       var url = '/api-admin/channelanalysis/get/channel/trend/new';
       chartfuc(url,formData,'新增设备','日','数量','new');
       //新增设备
       var flag_device = 0;
       $("#sjqs_newDevice").on('click',function(){
            flag_device = 0;
            var time = $("#date").val(),
                startTime = time.split(' ~ ')[0],
                endTime = time.split(' ~ ')[1],
                data = {start:startTime,end:endTime,channelId:formData.channelId},
                url = '/api-admin/channelanalysis/get/channel/trend/new';
                chartfuc(url,data,'新增设备','日','数量','new');
       });
        //活跃设备
        $("#sjqs_activeDevice").on('click',function(){
            flag_device = 1;
            $("#dataRetention").empty();
            $("#dataRetention").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
            var time = $("#date").val(),
            startTime = time.split(' ~ ')[0],
            endTime = time.split(' ~ ')[1],
            data = {start:startTime,end:endTime,channelId:formData.channelId},
            url = '/api-admin/channelanalysis/get/channel/trend/active';
            chartfuc(url,data,'活跃设备','日','数量','active');
        });
         //启动次数
       $("#sjqs_statNumber").on('click',function(){
            flag_device = 2;
            $("#dataRetention").empty();
            $("#dataRetention").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
            var time = $("#date").val(),
            startTime = time.split(' ~ ')[0],
            endTime = time.split(' ~ ')[1],
            data = {start:startTime,end:endTime,channelId:formData.channelId},
            url = '/api-admin/channelanalysis/get/channel/trend/start';
            chartfuc(url,data,'启动次数','日','数量','start');
        });
        //人均启动次数
        $("#sjqs_perstatNumber").on('click',function(){
            flag_device = 3;
            $("#dataRetention").empty();
            $("#dataRetention").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
            var time = $("#date").val(),
            startTime = time.split(' ~ ')[0],
            endTime = time.split(' ~ ')[1],
            data = {start:startTime,end:endTime,channelId:formData.channelId},
            url = '/api-admin/channelanalysis/get/channel/trend/mane';
            chartfuc(url,data,'人均启动次数','日','数量','mane');
        });
        //单次使用时长
        $("#sjqs_useTime").on('click',function(){
            flag_device = 4 ;
            $("#dataRetention").empty();
            $("#dataRetention").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
            var time = $("#date").val(),
            startTime = time.split(' ~ ')[0],
            endTime = time.split(' ~ ')[1],
            data = {start:startTime,end:endTime,channelId:formData.channelId},
            url = '/api-admin/channelanalysis/get/channel/trend/usetime';
            chartfuc(url,data,'单次使用时长','日','小时','usertime');
        });
        //图表函数
       function chartfuc(url,data,label,labelStringx,labelStringy,flag_tab){

           $.ajax({
               type:'post',
               url:url,
               data:data,
               dataType:'json',
               beforeSend:function(request){
                   request.setRequestHeader('Authorization',layui.data('author').Authorization);
               },
               success:function(res){
                   var dta = [],time=[],dat=[];
                   if(res.code == 0){
                       dta = res.data.dataList;
                       if(flag_tab=='new'){
                           $("#count").html('合计 <sapn>'+res.data.channelTotalCount+'</sapn>');
                           $("#avg").html('均值 <span>'+res.data.channelMeanCount+'</span>');
                       }else 
                       if(flag_tab=='active'){
                        $("#count").html('活跃(排重) <sapn>'+res.data.channelTotalCount+'</sapn>');
                        $("#avg").html('均值 <span>'+res.data.channelMeanCount+'</span>');
                       }else 
                       if(flag_tab == 'start'){
                        $("#count").html('合计 <sapn>'+res.data.channelTotalCount+'</sapn>');
                        $("#avg").html('均值 <span>'+res.data.channelMeanCount+'</span>');
                       }else 
                       if(flag_tab == 'mane'){
                        $("#count").html('');
                        $("#avg").html('均值 <span>'+res.data.channelMeanCount+'</span>');
                       }else 
                       if(flag_tab == 'usertime'){
                        $("#count").html('');
                        $("#avg").html('均值 <span>'+userTineMode(res.data.channelMeanCount)+'</span>');
                        
                       }
                      
                   }
                   if(dta.length>0){
                       for(var i in dta){
                           if(flag_tab=='new'){
                                time.push(dta[i].time);
                                dat.push(dta[i].newCount);
                           }else 
                           if(flag_tab=='active'){
                            time.push(dta[i].time);
                            dat.push(dta[i].activeCount);
                           }else 
                           if(flag_tab == 'start'){
                            time.push(dta[i].time);
                            dat.push(dta[i].startAmount);
                           }else 
                           if(flag_tab == 'mane'){
                                time.push(dta[i].time);
                                dat.push(dta[i].startMean);
                           }else 
                           if(flag_tab == 'usertime'){
                                time.push(dta[i].time);
                                dat.push(parseInt(dta[i].useTime/(1000*60*60)));
                           }
                       }
                     var  datasets = [{
                           label:label,
                           borderColor: '#1495eb',
                           backgroundColor: 'rgba(195,203,214)',
                           data:dat
                       }],
                       title = {
                           display: true,
                           text: ''
                       },
                       tooltips =  {
                           mode: 'index',
                           intersect: false
                       },
                       hover = {
                           mode: 'nearest',
                           intersect: true
                       },
                       scales = {
                           xAxes: [{
                               display:true,
                               scaleLabel: {
                                   display: true,
                                   labelString:labelStringx
                               }
                           }],
                           yAxes: [{
                               display:true,
                               scaleLabel: {
                                   display: true,
                                   labelString:labelStringy
                               }
                           }]
                       };
                       var config = chartModel('line',time,datasets,true,title,tooltips,hover,scales);
                       var ctx = document.getElementById('canvas').getContext('2d');
                       window.myLine = new Chart(ctx, config);
                   }
               }
           });//ajax
       }  
        // console.log(JSON.stringify(formData));
      
        //分页处理
        function pageProce(data,curr,nums){
            var dt = [];
            return dt.concat(data).splice(curr*nums - nums,nums);
        }
        //数据详情下载
        $("#sjxq_updown").on('click',function(){
            alert('数据详情下载：439');
        });	
        //数据详情help
        $("#sjxq_help").on('mouseover',function(){
            $("#sjxq_movechange").css('display','block');
        });
        $('#sjxq_help').on('mouseout',function(){
            $("#sjxq_movechange").css('display','none');
        });
        //对比时段
        var sd_f = 0;
        form.on('checkbox(checkbox_sd)',function(data){
            if(sd_f==0){
                var str = '';
                    str += '<li class="icon icon-calendar" style="float:left; margin-top: 2px;"></li>';
                    str += '<div style="float:left;margin-top: -10px;">';
                    str += '<input type="text" name="sd_date" id="sd_date" class="layui-input" style="border:none;"/>';
                    str += '</div>';
                    str += '<li class="icon icon-angle-down" style="float:left; margin-left: -5px;"></li>';
                $('.tab_sd_date').html(str);
                    laydate.render({
                    elem:'#sd_date',
                    type:'date',
                    range:'~',
                    value:util.toDateString(new Date(new Date()-1000*24*60*60*30),'yyyy-MM-dd')+' ~ '+ util.toDateString(new Date(),'yyyy-MM-dd'),
                    btn:'confirm',
                    done:function(value){
                        if(value!=""){
                            var start = value.split(' ~ ')[0],
                                end = value.split(' ~ ')[1],
                                data = {start:start,end:end,channelId:formData.channelId};
                                $("#dataRetention").empty();
                                $("#dataRetention").html('<canvas id="canvas" style="width: 100%; height: 300px;"></canvas>');
                                if(flag_device == 0){
                                    url = '/api-admin/channelanalysis/get/channel/trend/new';
                                    chartfuc(url,data,'新增设备','日','数量','new');
                                }else 
                                if(flag_device == 1){
                                    url = '/api-admin/channelanalysis/get/channel/trend/active';
                                    chartfuc(url,data,'活跃设备','日','数量','active');
                                }else 
                                if(flag_device == 2){
                                    url = '/api-admin/channelanalysis/get/channel/trend/start';
                                    chartfuc(url,data,'启动次数','日','数量','start');
                                }else 
                                if(flag_device == 3){
                                    url = '/api-admin/channelanalysis/get/channel/trend/mane';
                                    chartfuc(url,data,'人均启动次数','日','数量','mane');
                                }else 
                                if(flag_device == 4){
                                    url = '/api-admin/channelanalysis/get/channel/trend/usetime';
                                    chartfuc(url,data,'单次使用时长','日','小时','usertime');
                                }
                        }
                    }
                    });
                form.render();
                sd_f = 1;
            }else{
                $('.tab_sd_date').empty();
                sd_f = 0;
                window.location.reload();
            }
            return false;
        });
    
        //阻止时间冒泡
        function stopPropagation(e) {
            var ev = e || window.event;
            if (ev.stopPropagation) {
                ev.stopPropagation();
            }
            else if (window.event) {
                window.event.cancelBubble = true;//兼容IE
            }
        }
        $(".filter").on('click',function(e){
            $(".dropdown-content").show();
            // $(".dropdown-content").slideDown('slow');
            stopPropagation(e);
        });
        $(document).bind('click',function(){
            $(".dropdown-content").hide();
            // $(".dropdown-content").slideUp('slow');
        });
        $(".dropdown-content").click(function (e) {
            stopPropagation(e);
        });
        $("#filter").on('click',function(){
            
        });
        $("#reback").on('click',function(){
            $(".dropdown-content").hide();
        });
        // 筛选
        var flag =0 ;
        $("#btn_screen").on('click',function(e){
            if(flag==0){
                $(".shaixuankuang").show();
                flag = 1;
                stopPropagation(e);
            }else{
                $(".shaixuankuang").hide();
                flag = 0;
                stopPropagation(e);
                
            }
        });
        $(document).bind('click',function(e){
            $(".shaixuankuang").hide();
        });
        $(".shaixuankuang").on('click',function(e){
            stopPropagation(e);
        });
        $("#shaixuankuang_down_qx").on('click',function(){
            $(".shaixuankuang").hide();
        });
    exports('channeldetail',{});
});