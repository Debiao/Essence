<script id="table-template" type="text/x-handlebars-template"> 
<div class="layui-card-body">
<table id="table" class="layui-table" lay-filter="test">
	<colgroup>
	</colgroup>	
	<thead>
		<tr>
			<th>#</th>
			<th>创建时间</th>
			<th>是否启用</th>
			<th>参与人数</th>
			<th>总奖金</th>
		</tr>
	</thead>
	<tbody class="news_content"></tbody>
</table>
<div id="page"></div>
</div>
 </script>
