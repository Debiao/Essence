var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
        data = { size: 10, sort: 'DESC', sortBy: 'id',enable:true,page:0};
        Handlebars.registerHelper('if_eq',function(v1, v2, opts){
            if(v1 == v2)
                return opts.fn(this);
             else
                return opts.inverse(this);   
        }); 
        var tableHeader=['编号','游戏','图片','类型','价格','售量','使用时长','库存','状态','操作'];
        var mytableHeaderTemplate = Handlebars.compile($("#tableHeader-template").html());
            $("#tableHeader").html(mytableHeaderTemplate(tableHeader));   
        cjhd.json('/api-admin/item/find/all', data, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    data.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        // console.log(data);
                        cjhd.json('/api-admin/item/find/all',data, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                        }, { type: 'post' });
                        $("#tableList").empty();
                        var myTemplate = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(myTemplate(dta));
                    }
                }
	        });
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='10'>暂无数据</td></tr>");
        }
	//执行一个laypage实例
    //通过启用状态查询
    var enableData={ size: 10, sort: 'DESC', sortBy: 'id',enable:true,page:0};
    form.on('submit(searchByEnable)',function(data){
        $("#tableHeader").empty();
        $("#tableList").empty();
        $("#page-template").empty();
        var tableHeader=['#','游戏','图片','类型','价格','售量','使用时长','库存','状态','操作'];
        var mytableHeaderTemplate = Handlebars.compile($("#tableHeader-template").html());
        $("#tableHeader").html(mytableHeaderTemplate(tableHeader));   
        $.extend(enableData,data.field);
        cjhd.json('/api-admin/item/find/all', enableData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length==0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    enableData.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        // console.log(data);
                        cjhd.json('/api-admin/item/find/all',enableData, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                        }, { type: 'post' });
                        $("#tableList").empty();
                        $("#tableHeader").empty();
                        var tableHeader=['编号','游戏','图片','类型','价格','售量','使用时长','库存','状态','操作'];
                        var mytableHeaderTemplate = Handlebars.compile($("#tableHeader-template").html());
                        $("#tableHeader").html(mytableHeaderTemplate(tableHeader)); 
                        var myTemplate = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(myTemplate(dta));
                    }
                }
            });   
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='10'>暂无数据</td></tr>");
        } 
        return false;
    });
    //查询已删除道具
    var delDate={page:0,size:10,sort:'DESC',sortBy:'id'}
    form.on('submit(searchByDeleted)',function(data){ 
        $("#tableHeader").empty();
        $("#tableList").empty();
        $("#page-template").empty();
        var tableHeader=['编号','游戏','图片','类型','价格','售量','使用时长','库存'];
        var mytableHeaderTemplate = Handlebars.compile($("#tableHeader-template").html());
        $("#tableHeader").html(mytableHeaderTemplate(tableHeader));  
        cjhd.json('/api-admin/item/find/deleted', delDate, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
            if(dta.length>0){
                var myTemplateTableHeader = Handlebars.compile($("#table-template-del").html());
                 $("#tableList").html(myTemplateTableHeader(dta));
                 $("#page-template").html('<div id="page"></div>');
                     laypage.render({
                         elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                         , count: count //数据总数，从服务端得到
                         , limit: 10
                         , layout: ['prev', 'page', 'next', 'count']
                         , jump: function (obj, first) {
                             delDate.page = obj.curr - 1;
                             //首次不执行
                             if (!first) {
                                 // console.log(data);
                                 cjhd.json('/api-admin/item/find/deleted',delDate, function (res) {
                                     dta = res.data.data;
                                     count = res.data.total;
                                 }, { type: 'post' });
                                 $("#tableList").empty();
                                 var mytableHeaderTemplate = Handlebars.compile($("#tableHeader-template").html());
                                 $("#tableHeader").html(mytableHeaderTemplate(tableHeader)); 
                             }
                         }
                     }); 
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
            }
       
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','70%'],
                content:'page/commodity/addCommodity.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteCommondity)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/item/remove/id',{id:id},function(res){
            if(res.code==0){
                parent.layer.close(inx);
                parent.location.reload();
            }else{
                layer.msg('服务器出错了...');
                parent.layer.close();
            }
        },{type:'post'});
        return false;
    });
    //编辑
    form.on('submit(editCommodity)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','70%'],
                content:'page/commodity/editCommodity.html' 
        });
        return false;
    });
    //禁用
    form.on('submit(prohibitCommodity)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text(),
        enable=$(data.elem).parents('tr').find('.enable').text();
        if(enable=='启用'){
            enable=1;
        }else 
        if(enable=='未启用'){
            enable=2;
        }
        var dt={
            id:id,
            enable:enable
        }
        // console.log(JSON.stringify(formData));
        cjhd.edit(dt);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['400px','40%'],
                content:'page/commodity/prohibitCommodity.html' 
        });
        return false;
    });
   
	exports('commodity', {});
	
});