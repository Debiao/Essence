
layui.define(['form','jquery','element','layer','cjhd','util','laypage'],function(exports){
	var form  = layui.form,
	$ = layui.jquery,
	element = layui.element,
	layer = layui.layer,
	cjhd = layui.cjhd,
	util = layui.util,
	laypage = layui.laypage;	
	Handlebars.registerHelper('fomatDate',function(v1,opts){
		if(v1<10){
			return '0'+v1 +':00';
		}else{
			return v1+':00';
		}
	});
	Handlebars.registerHelper('tochange',function(v1,opts){
		return v1 + '%';
	});
	// var data = {};
	// cjhd.savePlateForm(data);
	var plateForm = layui.data('author').plateForm;
	if(JSON.stringify(plateForm)=="{}"){					  
		var str = "";
		str += '<div class="filter_icon" id="android">';
		str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		str += '<div class="filter_icon" id="iOS">';
		str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);
	}else 
	if(plateForm.platfrom=='iOS'){
	
		var str = "";
		str += '<div class="filter_icon" id="iOS">';
		str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);

		var checkbox = $('input[name="checkbox"]');
		checkbox.each(function(i,v){
			if(v.value ==plateForm.platfrom){

			}else{
				$(this).prop('checked',false);
			}
		});
		
	}else 
	if(plateForm.platfrom=='android'){

		var str = "";
		str += '<div class="filter_icon" id="android">';
		str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
		str += '</div>';
		$('.filter_left').html(str);
		var checkbox = $('input[name="checkbox"]');
		checkbox.each(function(i,v){
			if(v.value ==plateForm.platfrom){

			}else{
				$(this).prop('checked',false);
			}
		});
		
		
	}
	//时长模板
	function userTineMode(time){
		var hour = parseInt(time/(1000*60*60)),
		fen =parseInt((time/(1000*60*60) - hour)*60),
		miao = parseInt(((time/(1000*60*60) - hour)*60 - fen)*60);
		if(hour<10)
			hour = "0" + hour;
		if(fen<10)
			fen = "0" + fen;
		 if(miao<10)
			miao = "0" + miao; 
		   return hour + ":" + fen + ":" + miao; 
	}
	//平台选定
	var checked = $('input[name="checkbox"]:checked');
					checked.each(function(i,v){
						$(this).click(function(){
							var check = $('input[name="checkbox"]:not(:checked)');
							
							var _this = this.checked;
							if(_this == false){
								var ve = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var checked1 = $('input[name="checkbox"]:checked');
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(ve == idvalue){
										if(checked1.length<1){
											layer.msg("至少需选一种平台信息");
										}else{
											$("#"+idvalue).remove();
										}
										
									}
								});
							}else{	
								var vu = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(idvalue == vu){
										
									}else{
										if(check.length<=1){
											check.each(function(){
												$(this).prop('checked','checked');
											});
										}
										if(vu=='iOS'){
											var str = '';
												str += '<div class="filter_icon" id="iOS">';
												str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
												str += '</div>';
												$(".filter_left").append(str);
										}else
										if(vu == 'android'){
											var str = '';
												str += '<div class="filter_icon" id="android">';
												str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
												str += '</div>';
												$(".filter_left").append(str);
										}
										
									}
									
								});
							}
							
							
						});
					});	
	var check  = $('input[name="checkbox"]:not(checked)');
		check.each(function(i,v){
			$(this).click(function(){
				var _this = this.checked;
				if(_this == true){
					var ve = this.value;
					var len = $(".filter_left").children(".filter_icon").size();
						var arr =[];
						for(var i=0;i<=len-1;i++){
							arr[i] = i;
						}
						$.each(arr,function(i){
							var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
							// alert();
							if(ve == idvalue){
								
							}else{
								if(ve=='iOS'){
									var str = '';
										str += '<div class="filter_icon" id="iOS">';
										str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
										str += '</div>';
										$(".filter_left").append(str);
								}else
								if(ve == 'android'){
									var str = '';
										str += '<div class="filter_icon" id="android">';
										str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
										str += '</div>';
										$(".filter_left").append(str);
								}	
							}
						});
					}else{
							var vu = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
								var arr =[];
								for(var i=0;i<=len-1;i++){
									arr[i] = i;
								}
								$.each(arr,function(i){
									var checke = $('input[name="checkbox"]:not(checked)');
									var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
									if(vu == idvalue){
										if(checke.length<1){
											layer.msg("至少需选一种平台信息");
										}else{
											$("#"+idvalue).remove();
										}
										
									}
								});
				}
			});
		});	
	//应用概览
	var config = {
		type: 'line',
		data: {
			labels:[], 
			datasets: [{
				label: '今日新增',
				backgroundColor: '#4bc0c0',
				borderColor: '#4bc0c0',
				data:[],
				fill: false,
			}, {
				label: '昨日新增',
				fill: false,
				backgroundColor:'#1495eb',
				borderColor: '#1495eb',
				data:[],
			}]
		},
		options: {
			responsive: true,
			title: {
				display: true,
				text: '时段分布'
			},
			tooltips: {
				mode: 'index',
				intersect: false,
			},
			hover: {
				mode: 'nearest',
				intersect: true
			},
			scales: {
				xAxes: [{
					display: true,
					scaleLabel: {
						display: true,
						labelString: 'today'
					}
				}],
				yAxes: [{
					display: true,
					scaleLabel: {
						display: true,
						labelString: 'Value'
					}
				}]
			}
		}
	};
	$(function(){
		var ctx = document.getElementById('sd_canvas').getContext('2d');
		window.myLine = new Chart(ctx, config);
	});
		
	//折线图分装

	function mycharts(type,labels,datasets,title,tooltips,hover,scales){
		var rqs_config = {
			type:type,
			data: {
				labels:labels,
				datasets:datasets,
			},
			options: {
				responsive: true,
				title:title,
				tooltips:tooltips,
				hover:hover,
				scales:scales
				
			}
		};
		return rqs_config;
	}

	
	console.log();
	//统计用户总数
	// $.ajax({
	// 	type:'post',
	// 	url:'/api-admin/appview/get/count/user',
	// 	data:plateForm,
	// 	dataType:'json',
	// 	beforeSend:function(request){
	// 		request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 	},
	// 	success:function(res){
	// 		console.log('统计用户总数');
	// 		console.log(res);
	// 		if(res.code == 0){
	// 			$("#gailan_ljyh").html(res.data.dataCount);
	// 		}else{
	// 			layer.msg('系统出错了...');
	// 		}
	// 	}
	// });
	//统计近7日活跃用户
	// $.ajax({
	// 	type:'post',
	// 	url:'/api-admin/appview/get/count/week',
	// 	data:plateForm,
	// 	dataType:'json',
	// 	beforeSend:function(request){
	// 		request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 	},
	// 	success:function(res){
	// 		console.log('统计近7日活跃用户');
	// 		console.log(res);
	// 		if(res.code == 0){
	// 			$("#user_qrhyyh").html(res.data.dataCount);
	// 		}
	// 	}
	// });
	//统计近30日活跃用户
	// $.ajax({
	// 	type:'post',
	// 	url:'/api-admin/appview/get/count/month',
	// 	data:plateForm,
	// 	dataType:'json',
	// 	beforeSend:function(request){
	// 		request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 	},
	// 	success:function(res){
	// 		console.log('统计近30日活跃用户');
	// 		console.log(res);
	// 		if(res.code == 0){
	// 			$("#user_ssrhyyh").html(res.data.dataCount);
	// 		}
	// 	}
	// });
	//近7日均使用时长
	// $.ajax({
	// 	type:'post',
	// 	url:'/api-admin/appview/get/online/week',
	// 	data:plateForm,
	// 	dataType:'json',
	// 	beforeSend:function(request){
	// 		request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 	},
	// 	success:function(res){
	// 		console.log('近7日均使用时长');
	// 		console.log(res);
	// 		if(res.code == 0){
	// 			$("#user_onlinetime").html(userTineMode(res.data.dataCount));
	// 		}
	// 	}
	// });
	//新增数据时段详情
	// var add_sd_today=[],add_sd_yestoday=[],time=[],data=[];
	// $.ajax({
	// 	type:'post',
	// 	url:'/api-admin/appview/get/time/now/data',
	// 	data:plateForm,
	// 	dataType:'json',
	// 	async:false,
	// 	beforeSend:function(request){
	// 		request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 	},
	// 	success:function(res){
	// 		console.log('新增数据时段详情');
	// 		console.log(res);
	// 		if(res.code == 0){
	// 			data = res.data.eachPeriodData;
	// 		}
	// 	}
	// });
	//  if(data.length>0){
	// 	for(var i=0;i<data.length;i++){
	// 		add_sd_yestoday.push(data[i].yesterdayNowData);
	// 		add_sd_today.push(data[i].todayNowData);
	// 		if(data[i].time<10){
	// 			time.push("0"+data[i].time+":00");
	// 		}else{
	// 			time.push(data[i].time+":00");
	// 		}
			
	// 	}
	// 	config.data.labels = time;
	// 	config.data.datasets[0].data = add_sd_today;
	// 	config.data.datasets[1].data = add_sd_yestoday;
	// 	config.options.scales.yAxes[0].scaleLabel.labelString = '数量';
	// 	window.myLine.update();
	//  }	
	 //30日趋势新增用户
	//  var ssrqs_add_user=[],ssrqs_time=[],ssrqs_data=[];
	//  $.ajax({
	// 		type:'post',
	// 		url:'/api-admin/appview/get/month/new/data',
	// 		data:plateForm,
	// 		dataType:'json',
	// 		async:false,
	// 		beforeSend:function(request){
	// 			request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 		},
	// 		success:function(res){
	// 			console.log('30日趋势新增用户');
	// 			console.log(res);
	// 			ssrqs_data = res.data.dayData;
	// 		}
	//  });
	//  if(ssrqs_data.length>0){
	// 	for(var i=0;i<ssrqs_data.length;i++){
	// 		ssrqs_add_user.push(ssrqs_data[i].dayData);
	// 		ssrqs_time.push(ssrqs_data[i].time);
	// 	}
		
	// 	var datasets = [{
	// 		label: '新增用户',
	// 		borderColor: '#1495eb',
	// 		backgroundColor: 'rgba(195,203,214)',
	// 		data:ssrqs_add_user
	// 	}],
	// 	title = {
	// 		display: true,
	// 		text: '新增用户'
	// 	},
		
	// 	tooltips = {
	// 		mode: 'index',
	// 	},
	// 	hover = {
	// 		mode: 'nearest'
	// 	},
	// 	scales = {
	// 		xAxes:[{
	// 			scaleLabel: {
	// 				display: true,
	// 				labelString: '30日'
	// 			}
	// 		}],
	// 		yAxes:[{
	// 			stacked: true,
	// 			scaleLabel: {
	// 				display: true,
	// 				labelString: '数量'
	// 			}
	// 		}]
	// 	}
	
	// 	var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
	// 	var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
	// 	window.myLine_rqs = new Chart(rqs_ctx, config_all);
	//  }

				
	//时段查看详情
	$("#sd_ckxq").on('click',function(){
		alert('sd_ckxq查看详情');
	});	

	//时段新增设备
	var flag_tab = 0,flag_chart=0;
	$('#sd_chart').on('click',function(){
		$(this).css('color','#8EB2E8');
		$('#sd_table').css('color','#CCCCCC');
		$("#sd_chart_show").css('display','block');
		$('#sd_table_show').css('display','none');
		flag_tab = 0;
		if(flag_chart == 0){
			//
			config.data.labels = time;
			config.data.datasets[0].data = add_sd_today;
			config.data.datasets[1].data = add_sd_yestoday;
			window.myLine.update();
			//
		}else 
		if(flag_chart == 1){
			//
			var sd_hysb_data = [],sd_hysb_today = [],sd_hysb_yestoday = [],sd_time=[];
			cjhd.json('/api-admin/appview/get/time/active/data',plateForm,function(res){
				sd_hysb_data = res.data.eachPeriodData;
			},{type:'post'});
			if(sd_hysb_data.length>0){
			
			//图表
				for(var i in sd_hysb_data){
					sd_hysb_today.push(sd_hysb_data[i].todayNowData);	
					sd_hysb_yestoday.push(sd_hysb_data[i].yesterdayNowData);
					if(sd_hysb_data[i].time<10){
						sd_time.push("0"+sd_hysb_data[i].time+":00");
					}else{
						sd_time.push(sd_hysb_data[i].time+":00");
					}
				}
				config.data.datasets[0].data = sd_hysb_today;
				config.data.datasets[1].data = sd_hysb_yestoday;
				config.data.labels = sd_time;
				window.myLine.update();
				}
			//
		}	
	});
	$('#sd_table').on('click',function(){
		$(this).css('color','#8EB2E8');
		$('#sd_chart').css('color','#CCCCCC');
		$("#sd_chart_show").css('display','none');
		$('#sd_table_show').css('display','block');
		flag_tab = 1;
		if(flag_chart ==0 ){
		//
		var sd_xzyh_data=[],sd_xzyh_today=[],sd_xzyh_yestoday=[];
		$("#thead_list").empty();
		$("#tbody_list").empty();
		$("#page_template").empty()
		cjhd.json('/api-admin/appview/get/time/now/data',plateForm,function(res){
			if(res.code == 0){
				sd_xzyh_data = res.data.eachPeriodData;
			}
		},{type:'post'});
		if(sd_xzyh_data.length>0){
			var sd__xzyh_head = ['时段','今日新增(数量)','昨日新增(数量)'];
			var sd_template_xzyh_head = Handlebars.compile($("#template_thead").html());
			$("#thead_list").html(sd_template_xzyh_head(sd__xzyh_head));
			var sd_zxyh_template_body = Handlebars.compile($("#template_tbody").html());
			var dta = laypageTable(sd_xzyh_data,1,5);
			$("#tbody_list").html(sd_zxyh_template_body(dta));
			$("#page_template").html('<div id="page"></div>');
			laypage.render({
				elem:'page',
				theme:'#1E9FFF',
				count:sd_xzyh_data.length,
				limit:5,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					if(!first){
						dta = laypageTable(sd_xzyh_data,obj.curr,5);
						$("#tbody_list").html(sd_zxyh_template_body(dta));
					}
				}
			});
		}
		//	
		}else 
		if(flag_chart == 1){
		//
		$("#tbody_list").empty();
		var sd_hysb_data = [],sd_hysb_today = [],sd_hysb_yestoday = [],sd_time=[];
		cjhd.json('/api-admin/appview/get/time/active/data',plateForm,function(res){
			sd_hysb_data = res.data.eachPeriodData;
		},{type:'post'});
		if(sd_hysb_data.length>0){
			//表格
			var sd_header_data = ['时间段','今日活跃(数量)','昨日活跃(数量)'];
			var sd_template_head = Handlebars.compile($("#template_thead").html());
				$("#thead_list").html(sd_template_head(sd_header_data));
			var sd_template_body = Handlebars.compile($("#template_tbody").html());
				var dta = laypageTable(sd_hysb_data,1,5);
				$("#tbody_list").html(sd_template_body(dta));
				$("#page_template").html('<div id="page"></div>');
				laypage.render({
					elem:'page',
					theme:'#1E9FFF',
					count:sd_hysb_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(sd_hysb_data,obj.curr,5);
							$("#tbody_list").html(sd_template_body(dta));
						}
					}
				});	
		}
		//
		}
	});
	$("#sd_xzsb").on('click',function(){
		flag_chart=0;
		if(flag_tab == 0){
			config.data.labels = time;
			config.data.datasets[0].data = add_sd_today;
			config.data.datasets[1].data = add_sd_yestoday;
			window.myLine.update();
		}else
		if(flag_tab == 1){
			var sd_xzyh_data=[],sd_xzyh_today=[],sd_xzyh_yestoday=[];
			$("#thead_list").empty();
			$("#tbody_list").empty();
			$("#page_template").empty()
			cjhd.json('/api-admin/appview/get/time/now/data',plateForm,function(res){
				if(res.code == 0){
					sd_xzyh_data = res.data.eachPeriodData;
				}
			},{type:'post'});
			if(sd_xzyh_data.length>0){
				var sd__xzyh_head = ['时段','今日新增(数量)','昨日新增(数量)'];
				var sd_template_xzyh_head = Handlebars.compile($("#template_thead").html());
				$("#thead_list").html(sd_template_xzyh_head(sd__xzyh_head));
				var sd_zxyh_template_body = Handlebars.compile($("#template_tbody").html());
				var dta = laypageTable(sd_xzyh_data,1,5);
				$("#tbody_list").html(sd_zxyh_template_body(dta));
				$("#page_template").html('<div id="page"></div>');
				laypage.render({
					elem:'page',
					theme:'#1E9FFF',
					count:sd_xzyh_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(sd_xzyh_data,obj.curr,5);
							$("#tbody_list").html(sd_zxyh_template_body(dta));
						}
					}
				});
			}
		}	 	
	});
	//时段活跃设备
	$("#sd_hysb").on('click',function(){
		flag_chart = 1;
		if(flag_tab == 0){
			var sd_hysb_data = [],sd_hysb_today = [],sd_hysb_yestoday = [],sd_time=[];
				cjhd.json('/api-admin/appview/get/time/active/data',plateForm,function(res){
					sd_hysb_data = res.data.eachPeriodData;
				},{type:'post'});
				if(sd_hysb_data.length>0){
				
				//图表
					for(var i in sd_hysb_data){
						sd_hysb_today.push(sd_hysb_data[i].todayNowData);	
						sd_hysb_yestoday.push(sd_hysb_data[i].yesterdayNowData);
						if(sd_hysb_data[i].time<10){
							sd_time.push("0"+sd_hysb_data[i].time+":00");
						}else{
							sd_time.push(sd_hysb_data[i].time+":00");
						}
					}
					config.data.datasets[0].data = sd_hysb_today;
					config.data.datasets[1].data = sd_hysb_yestoday;
					config.data.labels = sd_time;
					window.myLine.update();
					}
		}else
		if(flag_tab == 1){
			$("#tbody_list").empty();
			var sd_hysb_data = [],sd_hysb_today = [],sd_hysb_yestoday = [],sd_time=[];
			cjhd.json('/api-admin/appview/get/time/active/data',plateForm,function(res){
				sd_hysb_data = res.data.eachPeriodData;
			},{type:'post'});
			if(sd_hysb_data.length>0){
				//表格
				var sd_header_data = ['时间段','今日活跃(数量)','昨日活跃(数量)'];
				var sd_template_head = Handlebars.compile($("#template_thead").html());
					$("#thead_list").html(sd_template_head(sd_header_data));
				var sd_template_body = Handlebars.compile($("#template_tbody").html());
					var dta = laypageTable(sd_hysb_data,1,5);
					$("#tbody_list").html(sd_template_body(dta));
					$("#page_template").html('<div id="page"></div>');
					laypage.render({
						elem:'page',
						theme:'#1E9FFF',
						count:sd_hysb_data.length,
						limit:5,
						layout:['prev','page','next','count'],
						jump:function(obj,first){
							if(!first){
								dta = laypageTable(sd_hysb_data,obj.curr,5);
								$("#tbody_list").html(sd_template_body(dta));
							}
						}
					});	
			}
		//end else if	
		}
		

	});
	//前端分页处理
	function laypageTable(data,curr,nums){
		var da = [];
		return da.concat(data).splice(curr*nums-nums,nums);
	}
	//时段启动次数
	// $("#sd_qdcs").on('click',function(){
	// 	var sd_qdcs_data=[],sd_qdcs_today=[],sd_qdcs_yestoday=[],sd_time=[];
	// });
	//30日趋势查看详情
	$("#rqs_ckxq").on('click',function(){
		alert('rqs_ckxq查看详情');
	});
	var flag_rqs_tab=0,flag_rqs_chart=0;
	$('#rqs_chart').on('click',function(){
		$(this).css('color','#8EB2E8');
		$('#rqs_table').css('color','#CCCCCC');
		$("#mid_out_rqs_chart").css('display','block');
		$("#mid_out_rqs_table").css('display','none');
		flag_rqs_tab = 0;
		if(flag_rqs_chart==0){
			var ssrqs_add_user=[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/month/new/data',plateForm,function(res){
				ssrqs_data = res.data.dayData;
			},{type:'post'});
			if(ssrqs_data.length>0){
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i=0;i<ssrqs_data.length;i++){
					ssrqs_add_user.push(ssrqs_data[i].dayData);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [{
					label: '新增用户',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:ssrqs_add_user
				}],
				title = {
					display: true,
					text: '新增用户'
				},
				
				tooltips = {
					mode: 'index',
				},
				hover = {
					mode: 'nearest'
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						display: true,
						scaleLabel: {
							display: true,
							labelString: '数量'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			 }
		}else 
		if(flag_rqs_chart==1){
			var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/month/active/data',plateForm,function(res){
				if(res.code == 0){
					ssrqs_data = res.data.dayData;
				}
			},{type:'post'});
			if(ssrqs_data.length>0){
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i in ssrqs_data){
					ssrqs_dta.push(ssrqs_data[i].dayData);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [{
					label: '活跃用户',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:ssrqs_dta
				}],
				title = {
					display: true,
					text: '活跃用户'
				},
				
				tooltips = {
					mode: 'index',
				},
				hover = {
					mode: 'nearest'
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						stacked: true,
						scaleLabel: {
							display: true,
							labelString: '数量'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			}
		}else 
		if(flag_rqs_chart==2){
			var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/month/duration/data',plateForm,function(res){
				if(res.code == 0){
					ssrqs_data = res.data.dayData;
				}
			},{type:'post'});
			if(ssrqs_data.length>0){
				for(var i in ssrqs_data){
					ssrqs_data[i].dayData  =  parseInt(ssrqs_data[i].dayData/1000/60/60) ;
				}
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i in ssrqs_data){
					ssrqs_dta.push(ssrqs_data[i].dayData);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [{
					label: '在线时长',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:ssrqs_dta
				}],
				title = {
					display: true,
					text: '在线时长'
				},
				
				tooltips = {
					mode: 'index',
				},
				hover = {
					mode: 'nearest'
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						stacked: true,
						scaleLabel: {
							display: true,
							labelString: '小时'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			
			}
		}else 
		if(flag_rqs_chart==3){
			var ssrqs_day_clv =[],ssrqs_week_clv =[],ssrqs_month_clv =[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/retention/data',plateForm,function(res){
				if(res.code == 0){
					ssrqs_data = res.data.retentionList;
				}
			},{type:'post'});
			if(ssrqs_data.length>0){
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i in ssrqs_data){
					ssrqs_day_clv.push(ssrqs_data[i].dayRetention);
					ssrqs_week_clv.push(ssrqs_data[i].weekRetention);
					ssrqs_month_clv.push(ssrqs_data[i].monthRetention);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [
					{
						label: '日存留率',
						borderColor: '#4bc0c0',
						backgroundColor: '#4bc0c0',
						data:ssrqs_day_clv,
						fill:false
					},
					{
						label: '周存留率',
						borderColor: '#ff6348',
						backgroundColor: '#ff6348',
						data:ssrqs_week_clv,
						fill:false
					},
					{
						label: '月存留率',
						borderColor: '#36a2eb',
						backgroundColor: '#36a2eb',
						data:ssrqs_month_clv,
						fill:false
						}	
				],
				title = {
					display: true,
					text: '存留率'
				},
				
				tooltips = {
					mode: 'index',
					intersect: false
				},
				hover = {
					mode: 'nearest',
					intersect:true
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						display: true,
						scaleLabel: {
							display: true,
							labelString: '百分比%'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			
			}
		}
	});
	$('#rqs_table').on('click',function(){
		$(this).css('color','#8EB2E8');
		$('#rqs_chart').css('color','#CCCCCC');
		$('#mid_out_rqs_table').css('display','block');
		$('#mid_out_rqs_chart').css('display','none');
		flag_rqs_tab = 1;
		if(flag_rqs_chart==0){
			var ssrqs_add_user=[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/month/new/data',plateForm,function(res){
				ssrqs_data = res.data.dayData;
			},{type:'post'});
			if(ssrqs_data.length>0){
				$("#rqs_thead_list").empty();
				$("#rqs_tbody_list").empty();
				$("#rqs_page_template").empty();
				var rqs_head = ['日期','新增用戶(数量)'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_tbody").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
		}else 
		if(flag_rqs_chart==1){
			var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/month/active/data',plateForm,function(res){
				if(res.code == 0){
					ssrqs_data = res.data.dayData;
				}
			},{type:'post'});
			$("#rqs_thead_list").empty();
			$("#rqs_tbody_list").empty();
			$("#rqs_page_template").empty();
			if(ssrqs_data.length>0){
				var rqs_head = ['日期','活跃用户(数量)'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_tbody").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
		}else
		if(flag_rqs_chart==2){
			var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/month/duration/data',plateForm,function(res){
				if(res.code == 0){
					ssrqs_data = res.data.dayData;
				}
			},{type:'post'});
			$("#rqs_thead_list").empty();
			$("#rqs_tbody_list").empty();
			$("#rqs_page_template").empty();
			if(ssrqs_data.length>0){
				for(var i in ssrqs_data){
					ssrqs_data[i].dayData  =  parseInt(ssrqs_data[i].dayData/1000/60/60) ;
				}
				var rqs_head = ['日期','在线时长(小时)'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_tbody").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
		}else 
		if(flag_rqs_chart==3){
			//
			var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
			cjhd.json('/api-admin/appview/get/retention/data',plateForm,function(res){
				if(res.code == 0){
					ssrqs_data = res.data.retentionList;
				}
			},{type:'post'});
				$("#rqs_thead_list").empty();
				$("#rqs_tbody_list").empty();
				$("#rqs_page_template").empty();
				if(ssrqs_data.length>0){
					var rqs_head = ['日期','日存留率','周存留率','月存留率'];
					var rqs_head_template = Handlebars.compile($("#template_thead").html());	
					$("#rqs_thead_list").html(rqs_head_template(rqs_head));
					var rqs_tbody = Handlebars.compile($("#rqs_template_clv").html());
					var dta = laypageTable(ssrqs_data,1,5);
					$("#rqs_tbody_list").html(rqs_tbody(dta));
					$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
					laypage.render({
						elem:'rqs_page',
						theme:'#1E9FFF',
						count:ssrqs_data.length,
						limit:5,
						layout:['prev','page','next','count'],
						jump:function(obj,first){
							if(!first){
								dta = laypageTable(ssrqs_data,obj.curr,5);
								$("#rqs_tbody_list").html(rqs_tbody(dta));
							}
						}
					});
				}
				//
				
			//
		}
	});
	//30日趋势新增设备
	$("#rqs_xzsb").on('click',function(){
		var ssrqs_add_user=[],ssrqs_time=[],ssrqs_data=[];
		cjhd.json('/api-admin/appview/get/month/new/data',plateForm,function(res){
			ssrqs_data = res.data.dayData;
		},{type:'post'});
		flag_rqs_chart=0
		if(flag_rqs_tab == 0){
			//
			if(ssrqs_data.length>0){
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i=0;i<ssrqs_data.length;i++){
					ssrqs_add_user.push(ssrqs_data[i].dayData);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [{
					label: '新增用户',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:ssrqs_add_user
				}],
				title = {
					display: true,
					text: '新增用户'
				},
				
				tooltips = {
					mode: 'index',
				},
				hover = {
					mode: 'nearest'
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						stacked: true,
						scaleLabel: {
							display: true,
							labelString: '数量'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			}
			//
		}else 
		if(flag_rqs_tab == 1){
			if(ssrqs_data.length>0){
				$("#rqs_thead_list").empty();
				$("#rqs_tbody_list").empty();
				$("#rqs_page_template").empty();
				var rqs_head = ['日期','新增用戶(数量)'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_tbody").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
		}
	});
	//30日趋势活跃用户
	$("#rqs_hysb").on('click',function(){
		var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
		cjhd.json('/api-admin/appview/get/month/active/data',plateForm,function(res){
			if(res.code == 0){
				ssrqs_data = res.data.dayData;
			}
		},{type:'post'});
		flag_rqs_chart=1;
		if(flag_rqs_tab == 0){
			if(ssrqs_data.length>0){
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i in ssrqs_data){
					ssrqs_dta.push(ssrqs_data[i].dayData);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [{
					label: '活跃用户',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:ssrqs_dta
				}],
				title = {
					display: true,
					text: '活跃用户'
				},
				
				tooltips = {
					mode: 'index',
				},
				hover = {
					mode: 'nearest'
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						stacked: true,
						scaleLabel: {
							display: true,
							labelString: '数量'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			}
		}else 
		if(flag_rqs_tab == 1){
			$("#rqs_thead_list").empty();
			$("#rqs_tbody_list").empty();
			$("#rqs_page_template").empty();
			if(ssrqs_data.length>0){
				var rqs_head = ['日期','活跃用戶(数量)'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_tbody").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
		}
	});
	
	//30日趋势在线时长
	$("#rqs_dsbsysc").on('click',function(){
		var ssrqs_dta =[],ssrqs_time=[],ssrqs_data=[];
		cjhd.json('/api-admin/appview/get/month/duration/data',plateForm,function(res){
			if(res.code == 0){
				ssrqs_data = res.data.dayData;
			}
		},{type:'post'});
		flag_rqs_chart=2;
		if(flag_rqs_tab == 0){
			if(ssrqs_data.length>0){
				for(var i in ssrqs_data){
					ssrqs_data[i].dayData  =  parseInt(ssrqs_data[i].dayData/1000/60/60) ;
				}
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i in ssrqs_data){
					ssrqs_dta.push(ssrqs_data[i].dayData);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [{
					label: '在线时长',
					borderColor: '#1495eb',
					backgroundColor: 'rgba(195,203,214)',
					data:ssrqs_dta
				}],
				title = {
					display: true,
					text: '在线时长'
				},
				
				tooltips = {
					mode: 'index',
				},
				hover = {
					mode: 'nearest'
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						stacked: true,
						scaleLabel: {
							display: true,
							labelString: '小时'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			}	
		}else 
		if(flag_rqs_tab == 1){
			//
			$("#rqs_thead_list").empty();
			$("#rqs_tbody_list").empty();
			$("#rqs_page_template").empty();
			if(ssrqs_data.length>0){
				for(var i in ssrqs_data){
					ssrqs_data[i].dayData  =  parseInt(ssrqs_data[i].dayData/1000/60/60) ;
				}
				var rqs_head = ['日期','在线时长(小时)'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_tbody").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
			//
		}
	});
	//30日趋势存留率
	$("#rqs_cll").on('click',function(){
		var ssrqs_day_clv =[],ssrqs_week_clv =[],ssrqs_month_clv =[],ssrqs_time=[],ssrqs_data=[];
		cjhd.json('/api-admin/appview/get/retention/data',plateForm,function(res){
			if(res.code == 0){
				ssrqs_data = res.data.retentionList;
			}
		},{type:'post'});
		flag_rqs_chart=3;
		if(flag_rqs_tab == 0){
			if(ssrqs_data.length>0){
				$("#mid_out_rqs_chart").empty();
				$("#mid_out_rqs_chart").html('<canvas id="rqs_canvas" style="width: 100%; height: 300px;"></canvas>');
				for(var i in ssrqs_data){
					ssrqs_day_clv.push(ssrqs_data[i].dayRetention);
					ssrqs_week_clv.push(ssrqs_data[i].weekRetention);
					ssrqs_month_clv.push(ssrqs_data[i].monthRetention);
					ssrqs_time.push(ssrqs_data[i].time);
				}
				var datasets = [
					{
						label: '日存留率',
						borderColor: '#4bc0c0',
						backgroundColor: '#4bc0c0',
						data:ssrqs_day_clv,
						fill:false
					},
					{
						label: '周存留率',
						borderColor: '#ff6348',
						backgroundColor: '#ff6348',
						data:ssrqs_week_clv,
						fill:false
					},
					{
						label: '月存留率',
						borderColor: '#36a2eb',
						backgroundColor: '#36a2eb',
						data:ssrqs_month_clv,
						fill:false
						}	
				],
				title = {
					display: true,
					text: '存留率'
				},
				
				tooltips = {
					mode: 'index',
					intersect: false
				},
				hover = {
					mode: 'nearest',
					intersect:true
				},
				scales = {
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: '30日'
						}
					}],
					yAxes:[{
						display: true,
						scaleLabel: {
							display: true,
							labelString: '百分比%'
						}
					}]
				}
			
				var config_all = mycharts('line',ssrqs_time,datasets,title,tooltips,hover,scales);
				var rqs_ctx = document.getElementById('rqs_canvas').getContext('2d');
				window.myLine_rqs = new Chart(rqs_ctx, config_all);
			}
		}else 
		if(flag_rqs_tab == 1){
			//
			$("#rqs_thead_list").empty();
			$("#rqs_tbody_list").empty();
			$("#rqs_page_template").empty();
			if(ssrqs_data.length>0){
				var rqs_head = ['日期','日存留率','周存留率','月存留率'];
				var rqs_head_template = Handlebars.compile($("#template_thead").html());	
				$("#rqs_thead_list").html(rqs_head_template(rqs_head));
				var rqs_tbody = Handlebars.compile($("#rqs_template_clv").html());
				var dta = laypageTable(ssrqs_data,1,5);
				$("#rqs_tbody_list").html(rqs_tbody(dta));
				$("#rqs_page_template").html('<div id="rqs_page" style="float:right;"></div>');
				laypage.render({
					elem:'rqs_page',
					theme:'#1E9FFF',
					count:ssrqs_data.length,
					limit:5,
					layout:['prev','page','next','count'],
					jump:function(obj,first){
						if(!first){
							dta = laypageTable(ssrqs_data,obj.curr,5);
							$("#rqs_tbody_list").html(rqs_tbody(dta));
						}
					}
				});
			}
			//
		}
	});
	//时段下载
	$("#sd_updown").on('click',function(){
		alert('sd_updown时段下载');
	});
	//30日趋势下载
	$("#rqs_updown").on('click',function(){
		alert('rqs_updown30日趋势下载');
	});
	//时段分布移进移出cunliu_help
	$("#sd_help").on('mouseover',function(){
		$("#movechange").css('display','block');
	});
	$("#sd_help").on('mouseout',function(){
		$("#movechange").css('display','none');
	});
	//30日趋势鼠标移入移出事件
	$("#rqs_help").on('mouseover',function(){
		console.log('onmouseover');
		$("#rqs_movechange").css('display','block');
	});
	$("#rqs_help").on('mouseout',function(){
		$("#rqs_movechange").css('display','none');
		console.log('rqs_movechange');
	});

	
	//阻止时间冒泡
	function stopPropagation(e) {
		var ev = e || window.event;
		if (ev.stopPropagation) {
			ev.stopPropagation();
		}
		else if (window.event) {
			window.event.cancelBubble = true;//兼容IE
		}
	}
	$(".filter").on('click',function(e){
		$(".dropdown-content").show();
		// $(".dropdown-content").slideDown('slow');
		stopPropagation(e);
	});
	$(document).bind('click',function(){
		$(".dropdown-content").hide();
		// $(".dropdown-content").slideUp('slow');
	});
	$(".dropdown-content").click(function (e) {
		stopPropagation(e);
	});
	//平台事件	
	$("#filter").on('click',function(){
		$(".dropdown-content").hide();
		var len = $(".filter_left").children(".filter_icon").size();
			if(len>1){
				cjhd.savePlateForm({});
				window.location.reload();
				return; 
			}else{
			var plate = $(".filter_left").children(".filter_icon").attr("id");
				//**** 平台查询*/

				cjhd.savePlateForm({platfrom:plate});
				window.location.reload();
				return;

				//*****end */
			}
	});
$("#reback").on('click',function(){
	$(".dropdown-content").hide();
});
exports('applicationoverview',{});
});

