var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
        cjhd = layui.cjhd,
        util = layui.util,
		$ = layui.jquery,
		num = 10,
        data = { size: 15, sort: 'DESC', sortBy: 'id',deleted:false };
        Handlebars.registerHelper('if_eq', function(v1, v2, opts){
            if(v1 == v2)
                return opts.fn(this);
            else
                return opts.inverse(this);   
        });
       Handlebars.registerHelper('formatDate',function(v1,opts){

            if(v1>0){
                return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
            }
            return "";
       });
        
	cjhd.json('/api-admin/rechargecards/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
    }, { type: 'post' });
        if(dta.length>0){
            var myTemplate=Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        data.page=obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/rechargecards/find/all',data,function(res){
                                dta = res.data.data;
                                count=res.data.total;
                            },{type:'post'}); 
                            $("#tableList").empty();
                            var myTemplate=Handlebars.compile($("#table-template").html());
                            $("#tableList").html(myTemplate(dta));
                        }
                    }
                });
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='7'>暂无数据</td></tr>");
        }
    //全查
    var allData={ size: 15, sort: 'DESC', sortBy: 'id',deleted:false };
    form.on('submit(searchByAll)',function(data){
        $("#tableList").empty();
        $("#page-template").empty();
        cjhd.json('/api-admin/rechargecards/find/all', allData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate=Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        allData.page=obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/rechargecards/find/all',allData,function(res){
                                dta = res.data.data;
                                count=res.data.total;
                            },{type:'post'}); 
                            $("#tableList").empty();
                            var myTemplate=Handlebars.compile($("#table-template").html());
                            $("#tableList").html(myTemplate(dta));
                        }
                    }
                });
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='7'>暂无数据</td></tr>");
        }
        return false;
    });
    //ID查询
    form.on('submit(searchByById)',function(){
        $("#tableList").empty();
        $("#page-template").empty();
        var id=$('input[name="id"]').val();
        cjhd.json('/api-admin/rechargecards/find/id',{id:id},function(res){
            if(res.code==0){
                dta=[res.data];
            }else{
                dta=[]; 
            }
        },{type:'post'});
        if(dta.length>0){
            var myTemplate=Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='7'>暂无数据</td></tr>");
        }
        form.render(); 
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','60%'],
                content:'page/rachragecard/addRachragecard.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteRachrageCard)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/rechargecards/remove',{id:id},function(res){
            if(res.code==0){
                parent.layer.close(inx);
                parent.location.reload();
            }else{
                layer.msg('服务器出错了...');
                parent.layer.close();
            }
        },{type:'post'});
    });
    //编辑
    form.on('submit(editRachrageCard)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['400px','40%'],
                content:'page/rachragecard/editRachragecare.html' 
        });
        return false;
    });
	exports('racheagecard', {});
	
});