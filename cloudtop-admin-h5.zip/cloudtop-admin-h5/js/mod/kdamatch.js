var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		util = layui.util,
 		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		data = { size: 10, sort: 'DESC', sortBy: 'id',page:0},
		dataAll = { size: 10, sort: 'DESC', sortBy: 'id',page:0},
		dataDay = { size: 10,page:0},
		dt ={size:15};
		Handlebars.registerHelper('if_eq', function(v1, v2, opts) {
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);
		});
		Handlebars.registerHelper('formatDate',function(v1,opts){
			if(v1>0)
				return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
			else 	
				return opts.fn("");
		});
		
	cjhd.json('/api-admin/kda/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
	}, { type: 'post' });
	if(dta.length>0){
		var myTemplate = Handlebars.compile($("#table-template").html());
			$('#tableList').html(myTemplate(dta));
			$('#page-template').html('<div id="page"></div>');		
			laypage.render({
					elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
					, count: count //数据总数，从服务端得到
					, limit: data.size
					, layout: ['prev', 'page', 'next', 'count']
					, jump: function (obj, first) {
						data.page = obj.curr - 1;
						//首次不执行
						if (!first) {
							cjhd.json('/api-admin/kda/find/all', data, function (res) {
								dta = res.data.data;
								count = res.data.total;
								var myTemplate = Handlebars.compile($("#table-template").html());
								$('#tableList').html(myTemplate(dta));
							}, { type: 'post' });
						}
					}
				});	
	}else{
		$('#tableList').html('<tr style="height:40px;"><td colspan="5"></td></tr>');
	}
		
		form.on('submit(searchKDAAll)',function(){
			$('#page-template').empty();
			$("#tableList").empty();
			cjhd.json('/api-admin/kda/find/all', dataAll, function (res) {
				dta = res.data.data;
				count = res.data.total;
				form.render();
			}, { type: 'post' });
			if(dta.length>0){
				dataAll.page=0;
				var myTemplate = Handlebars.compile($("#table-template").html());
				$('#tableList').html(myTemplate(dta));
				$('#page-template').html('<div id="page"></div>');	
			
				laypage.render({
					elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
					, count: count //数据总数，从服务端得到
					, limit: dataAll.size
					, layout: ['prev', 'page', 'next', 'count']
					, jump: function (obj, first) {
						dataAll.page = obj.curr - 1;
						//首次不执行
						if (!first) {
							console.log(data);
							cjhd.json('/api-admin/kda/find/all', dataAll, function (res) {
								dta = res.data.data;
								count = res.data.total;
								console.log(dta);
								// console.log(res);
								var myTemplate = Handlebars.compile($("#table-template").html());
								$('#tableList').html(myTemplate(dta));
							}, { type: 'post' });
							//
						}
					}
				});	
			}else{
				$('#tableList').html('<tr style="height:40px;"><td colspan="5"></td></tr>');
			}
			return false;
		});
	//当天查
	form.on('submit(searchKDAOneday)',function(res){
		$('#page-template').empty();
		$("#tableList").empty();
		cjhd.json('/api-admin/kda/find/day',dataDay,function(res){
			dta=res.data.data;
			count=res.data.total;
		},{type:'post'});
		if(dta.length>0){
			var myTemplate = Handlebars.compile($("#table-template").html());
				$('#tableList').html(myTemplate(dta));
				$('#page-template').html('<div id="page"></div>');	
				laypage.render({
							elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
							, count: count //数据总数，从服务端得到
							, limit: dataDay.size
							, layout: ['prev', 'page', 'next', 'count']
							, jump: function (obj, first) {
								dataDay.page = obj.curr - 1;
								//首次不执行
								if (!first) {
									console.log(data);
									cjhd.json('/api-admin/kda/find/day', dataDay, function (res) {
										dta = res.data.data;
										count = res.data.total;
										console.log(dta);
										// console.log(res);
										var myTemplate = Handlebars.compile($("#table-template").html());
										$('#tableList').html(myTemplate(dta));
									}, { type: 'post' });
									//
								}
							}
						});	
		}else{
			$('#tableList').html('<tr style="height:40px;"><td colspan="5"></td></tr>');
		}
		return false;
	});	
	
	exports('kdamatch', {});
	
});