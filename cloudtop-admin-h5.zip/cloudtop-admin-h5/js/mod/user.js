layui.define(['jquery','form','cjhd'],function(exports){ 
	var $ = layui.jquery,
		form = layui.form,
		cjhd=layui.cjhd;
		 layui.cache.page == 'user';
		 form.on('submit(login)', function(data){
			$.ajax({
				type:'post',
				// url:'http://www.idoubi.top/api-passport/login/staff',
				// url:'https://pay.gaaa8.com/api-passport/login/login',
				// url:'http://47.56.24.152:18050/login/login',
                url:'http://127.0.0.1:18050/login/login',
				dataType:'json',
				data:data.field,
				success:function(res){
					console.log(res);					
					if(res.code==0){
						console.log(JSON.stringify(res));
						cjhd.saveAuthorHeader(res.data.token);
						cjhd.saveAuthorUser(res.data);
						cjhd.saveAuthorUsername(data.field.username);
						cjhd.saveAuthorPsw(data.field.password);
						cjhd.saveAuthorRoleName(res.data.roleNames);
						window.location.href='../../index.html';
					}else{
						alert('fail', {icon: 6});
						window.location.reload();
					}	
				}
			});	
		return false;
	});
	 
	exports('user',{});
}); 