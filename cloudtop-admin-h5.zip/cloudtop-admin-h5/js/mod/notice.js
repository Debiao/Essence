var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size: 10, sort: 'DESC', sortBy: 'id',page:0};
        Handlebars.registerHelper('if_eq',function(v1, v2, opts){
               if(v1 == v2)
                    return opts.fn(this);
               else
                    return opts.inverse(this);
        });
        cjhd.json('/api-admin/notice/find/deleted', data, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var template = Handlebars.compile($("#table-template").html());
            $("#tableList").html(template(dta));
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:data.size,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    data.page = obj.curr - 1;
                    if(!first){
                        cjhd.json('/api-admin/notice/find/deleted',data,function(){
                            dta = res.data.data;
                            count = res.data.total;
                        },{type:'post'});
                        $("#tableList").empty();
                        var template = Handlebars.compile($("#table-template").html());
                        $("#tableList").html(template(dta));
                    }
                }    
            });   
        }else{
            $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
        }
	
    //全查
    form.on('submit(searchAll)',function(){

    });
    //删除状态查询
    delData = { size: 10, sort: 'DESC', sortBy: 'id',page:0};
    form.on('submit(searchByByDeleted)',function(data){
        $("#tableList").empty();
        $("#page-template").empty();
         var deleted=$("select[name='deleted']").val();
            delData.deleted=deleted;
            console.log(JSON.stringify(delData));
            cjhd.json('/api-admin/notice/find/deleted',delData,function(res){
                dta = res.data.data;
                count = res.data.total;
            },{type:'post'});
            if(dta.length>0){
            var template = Handlebars.compile($("#table-template").html());
                $("#tableList").html(template(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:delData.size,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        delData.page = obj.curr - 1;
                        if(!first){
                            cjhd.json('/api-admin/notice/find/deleted',delData,function(){
                                dta = res.data.data;
                                count = res.data.total;
                            },{type:'post'});
                            $("#tableList").empty();
                            var template = Handlebars.compile($("#table-template").html());
                            $("#tableList").html(template(dta));
                        }
                    }    
                });   
            }else{
                $("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='5'>暂无数据</td></tr>");
            }
        return false;
    });
    //ID查询
    form.on('submint(searchById)',function(){
        var name=$('input[name="id"]').val();
        cjhd.json('/api-admin/cardbags/find/id',{id:id},function(res){
            dta=[res.data];
            $('.news_content').html(tbody(dta));
        },{type:'post'});
           form.render(); 
        return false;
    });
    //用户id查询
    form.on('submit(searchByByuserId)',function(){
        var userId=$('input[name="userId"]').val();
        cjhd.json('/api-admin/cardbags/find/user',{userId:userId},function(res){
            dta=res.data.data;
            $('.news_content').html(tbody(dta));
        },{type:'post'});
        form.render(); 
        return false;
    });
    //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','48%'],
                content:'page/notice/addNotice.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteNotice)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/notice/delete',{id:id},function(res){
            if(res.code==0){
                location.reload();
            }else{
                layer.msg('服务器出错了...');
                location.reload();
            }
        },{type:'post'});
    });
    //编辑
    form.on('submit(editNotice)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text(),
        deleted = $(data.elem).parents('tr').find('.deleted').text();
        if(deleted == '已删除'){
            layer.confirm('删除状态数据不能修改', {
                btn: ['关闭'] 
              })
        }else{
            cjhd.edit(id);
            layer.open({
                    type:2,
                    title:'',
                    shadeClose:true,
                    shade:0.8,
                    area:['400px','40%'],
                    content:'page/notice/editNotice.html' 
            });
        }
        return false;
    });
	exports('notice', {});
	
});