layui.define(['form','jquery','element','layer','laydate','laypage','util','cjhd'],function(exports){

    var form  = layui.form,
				$ = layui.jquery,
				element = layui.element,
				layer = layui.layer,
				laydate = layui.laydate,
                laypage = layui.laypage,
				util = layui.util,
				cjhd = layui.cjhd;
				var plateForm = layui.data('author').plateForm;
				if(JSON.stringify(plateForm)=="{}"){					  
					var str = "";
					str += '<div class="filter_icon" id="android">';
					str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					str += '<div class="filter_icon" id="iOS">';
					str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					$('.filter_left').html(str);
				}else 
				if(plateForm.platfrom=='iOS'){
				
					var str = "";
					str += '<div class="filter_icon" id="iOS">';
					str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					$('.filter_left').html(str);
			
					var checkbox = $('input[name="checkbox"]');
					checkbox.each(function(i,v){
						if(v.value ==plateForm.platfrom){
			
						}else{
							$(this).prop('checked',false);
						}
					});
					
				}else 
				if(plateForm.platfrom=='android'){
			
					var str = "";
					str += '<div class="filter_icon" id="android">';
					str += ' <li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
					str += '</div>';
					$('.filter_left').html(str);
					var checkbox = $('input[name="checkbox"]');
					checkbox.each(function(i,v){
						if(v.value ==plateForm.platfrom){
			
						}else{
							$(this).prop('checked',false);
						}
					});
					
					
				}
			
				//平台选定
				var checked = $('input[name="checkbox"]:checked');
								checked.each(function(i,v){
									$(this).click(function(){
										var check = $('input[name="checkbox"]:not(:checked)');
										
										var _this = this.checked;
										if(_this == false){
											var ve = this.value;
											var len = $(".filter_left").children(".filter_icon").size();
											var arr =[];
											for(var i=0;i<=len-1;i++){
												arr[i] = i;
											}
											$.each(arr,function(i){
												var checked1 = $('input[name="checkbox"]:checked');
												var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
												if(ve == idvalue){
													if(checked1.length<1){
														layer.msg("至少需选一种平台信息");
													}else{
														$("#"+idvalue).remove();
													}
													
												}
											});
										}else{	
											var vu = this.value;
											var len = $(".filter_left").children(".filter_icon").size();
											var arr =[];
											for(var i=0;i<=len-1;i++){
												arr[i] = i;
											}
											$.each(arr,function(i){
												var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
												if(idvalue == vu){
													
												}else{
													if(check.length<=1){
														check.each(function(){
															$(this).prop('checked','checked');
														});
													}
													if(vu=='iOS'){
														var str = '';
															str += '<div class="filter_icon" id="iOS">';
															str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
															str += '</div>';
															$(".filter_left").append(str);
													}else
													if(vu == 'android'){
														var str = '';
															str += '<div class="filter_icon" id="android">';
															str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
															str += '</div>';
															$(".filter_left").append(str);
													}
													
												}
												
											});
										}
										
										
									});
								});	
				var check  = $('input[name="checkbox"]:not(checked)');
					check.each(function(i,v){
						$(this).click(function(){
							var _this = this.checked;
							if(_this == true){
								var ve = this.value;
								var len = $(".filter_left").children(".filter_icon").size();
									var arr =[];
									for(var i=0;i<=len-1;i++){
										arr[i] = i;
									}
									$.each(arr,function(i){
										var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
										// alert();
										if(ve == idvalue){
											
										}else{
											if(ve=='iOS'){
												var str = '';
													str += '<div class="filter_icon" id="iOS">';
													str += '<li class="icon icon-apple" style="margin-left: 8px; margin-top:8px;"></li>';
													str += '</div>';
													$(".filter_left").append(str);
											}else
											if(ve == 'android'){
												var str = '';
													str += '<div class="filter_icon" id="android">';
													str += '<li class="icon icon-android" style="margin-left: 8px; margin-top:8px;"></li>';
													str += '</div>';
													$(".filter_left").append(str);
											}	
										}
									});
								}else{
										var vu = this.value;
											var len = $(".filter_left").children(".filter_icon").size();
											var arr =[];
											for(var i=0;i<=len-1;i++){
												arr[i] = i;
											}
											$.each(arr,function(i){
												var checke = $('input[name="checkbox"]:not(checked)');
												var idvalue = $(".filter_left").children(".filter_icon").eq(i).attr("id");
												if(vu == idvalue){
													if(checke.length<1){
														layer.msg("至少需选一种平台信息");
													}else{
														$("#"+idvalue).remove();
													}
													
												}
											});
							}
						});
					});	
				laydate.render({
					elem:'#date',
					type:'date',
					range: '~',
					value:util.toDateString(new Date(new Date()-30*24*60*60*1000),'yyyy-MM-dd') + ' ~ ' + util.toDateString(new Date(),'yyyy-MM-dd'),
					btn:'confirm',
					done:function(value){
						if(value!=""){
							var startTime = value.split(' ~ ')[0],
								endTime = value.split(' ~ ')[1],
								qltData = {start:startTime,end:endTime,platfrom:plateForm.platfrom};
								$("#user_mychart").empty();
								$("#user_mychart").html('<canvas id="zlpg_canvas" style="width: 100%; height: 300px;"></canvas>');
								$.ajax({
									type:'post',
									url:'/api-admin/userqualityassessment/get/overview',
									data:qltData,
									dataType:'json',
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Authorization);
									},
									success:function(res){
										var dta = [];
										if(res.code == 0){
											dta = res.data;
										}
										$("#user_total").text(dta.userTotalCount);
										$("#normal_user").text(dta.userNormalCount);
										$("#user_dubious").text(dta.userDubiousCount);
										if(dta.userDetailsList.length>0){
											var labels = [],dataUserTotalCount=[],dataUserNormalCount=[],dataUserDubiousCount=[];
											for(var i in dta.userDetailsList){
												labels.push(dta.userDetailsList[i].time);
												dataUserTotalCount.push(dta.userDetailsList[i].userTotalCount);
												dataUserNormalCount.push(dta.userDetailsList[i].userNormalCount);
												dataUserDubiousCount.push(dta.userDetailsList[i].userDubiousCount);
											}
											var datasets = [
												{
													label: '总用户',
													borderColor: '#FFbF40',
													backgroundColor: 'rgba(195,203,214)',
													data: dataUserTotalCount
												},
												{
													label: '正常用户',
													borderColor: '#84AAE1',
													backgroundColor: 'rgba(195,203,214)',
													data:dataUserNormalCount
												},
												{
													label: '可疑用户',
													borderColor: '#9966ff',
													backgroundColor: 'rgba(195,203,214)',
													data:dataUserDubiousCount
												}
											];
										var title = {
												display: true,
												text: ''
											},
											tooltips= {
												mode: 'index',
												intersect: false
											},
											hover={
												mode: 'index',
												intersect: false
											},
											scales = {
												xAxes:[{
													scaleLabel: {
														display: true,
														labelString: ''
													}
												}],
												yAxes:[{
													display: true,
													scaleLabel: {
														display: true,
														labelString: ''
													}
												}]
											}
										var zlpg_config = config_chart('line',labels,datasets,true,title,tooltips,hover,scales);
										var zlpg_ctx = document.getElementById('zlpg_canvas').getContext('2d');
										window.myLine = new Chart(zlpg_ctx, zlpg_config);
										}		
									}
								});
								//静默用户折线图
								$("#jm_user_mychart").empty();
								$("#jm_user_mychart").html('<canvas id="jmyh_canvas" style="width: 100%; height: 300px;"></canvas>');
								$.ajax({
									type:'post',
									url:'/api-admin/userqualityassessment/get/silence',
									data:qltData,
									dataType:'json',
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Authorization);
									},
									success:function(res){
										var dta = [];
										if(res.code == 0){
											dta = res.data;
										}
										$("#dubious_user").html(dta.userSilenceCount);
										$("#dubious_userzb").html(dta.silence_totalProportion+"%");
										if(dta.userDetailsList.length>0){
											var userSilenceCount =[],silence_dubiousProportion =[],labels=[];
											for(var i in dta.userDetailsList){
												labels.push(dta.userDetailsList[i].time);
												userSilenceCount.push(dta.userDetailsList[i].userSilenceCount);
												silence_dubiousProportion.push(dta.userDetailsList[i].silence_dubiousProportion);
											}
											var datasets = [
												{
													label: '静默用户',
													borderColor: '#FFbF40',
													backgroundColor: 'rgba(195,203,214)',
													data: userSilenceCount
												},
												{
													label: '静默用户占比',
													borderColor: '#84AAE1',
													backgroundColor: 'rgba(195,203,214)',
													data:silence_dubiousProportion
												}
											];
										var title = {
												display: true,
												text: ''
											},
											tooltips= {
												mode: 'index',
												intersect: false
											},
											hover={
												mode: 'index',
												intersect: false
											},
											scales = {
												xAxes:[{
													scaleLabel: {
														display: true,
														labelString: ''
													}
												}],
												yAxes:[{
													display: true,
													scaleLabel: {
														display: true,
														labelString: ''
													}
												}]
											}
										var jmyh_config = config_chart('line',labels,datasets,true,title,tooltips,hover,scales);
										var jmyh_ctx = document.getElementById('jmyh_canvas').getContext('2d');
										window.myLine = new Chart(jmyh_ctx, jmyh_config);
										}
									}
								});
								//静默用户表格
								$("#thead_list_jmyh").empty();
								$("#tbody_list_jmyh").empty();
								$("#page_template_jmyh").empty();
								$.ajax({
									type:'post',
									url:'/api-admin/userqualityassessment/get/silence',
									data:qltData,
									dataType:'json',
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Authorization);
									},
									success:function(res){
									var data = [],count=0;
										if(res.code == 0){
											data = res.data.userDetailsList;
											count = data.length;
										}
										if(data.length>0){
											var head_temp = Handlebars.compile($("#head_template").html());
											$("#thead_list_jmyh").html(head_temp(['日期','静默用户','占总用户比例','占可疑用户比例']));
											var tableList_temp = Handlebars.compile($("#table_jmyh_template").html());
											$("#tbody_list_jmyh").html(tableList_temp(dealData(data,1,5)));
											$("#page_template_jmyh").html('<div id="page_jmyh"></div>');
											laypage.render({
												elem:'page_jmyh',
												theme:'#1E9FFF',
												count:count,
												limit:5,
												layout:['prev','page','next','count'],
												jump:function(obj,first){
													if(!first){
														$("#tbody_list_jmyh").html(tableList_temp(dealData(data,obj.curr,5)));
													}
												}
											});		
										}else{
											$("#tbody_list_jmyh").html('<tr><td colspan="4">暂无数据</td></tr>');
										}
									}
								});
								//分渠道质量对比
								$("#tableList").empty();
								$("#page_zldb").empty();
								$.ajax({
									type:'post',
									url:'/api-admin/userqualityassessment/get/channle',
									data:qltData,
									dataType:'json',
									beforeSend:function(request){
										request.setRequestHeader('Authorization',layui.data('author').Authorization);
									},
									success:function(res){
										var dta = [];
										if(res.code == 0){
											dta = res.data;
										}
										if(dta.length>0){
											var duibi_template = Handlebars.compile($("#duibi_template").html());
											$("#tableList").html(duibi_template(dealData(dta,1,5)));
											$("#page_zldb").html('<div id="page"></div>');
											laypage.render({
												elem:'page',
												theme:'#1E9FFF',
												count:dta.length,
												limit:5,
												layout:['prev','page','next','count'],
												jump:function(obj,first){
													if(!first){
														$("#tableList").html(duibi_template(dealData(dta,obj.curr,5)));
													}
												}
											});						
										}else{
											$("#tableList").html('<tr><td colspan="8" style="height:40px;">暂无数据</td></tr>')
										}
									}
								});
						}
					}
				});
				form.render('checkbox');
		
				//百分比值转换
				Handlebars.registerHelper('formatData',function(v1,opts){
					
					return v1 + ".00%";
				});
			
				//图表分装	
				function config_chart(type,labels,datasets,responsive,title,tooltips,hover,scales){
					var config={
						type:type,
						data:{
							labels:labels,
							datasets:datasets
						},
						options:{
							responsive:responsive,
							title:title,
							tooltips:tooltips,
							hover:hover,
							scales:scales

						}
					}
					return config;
				}
				//用户质量评估
				var time_sq_start = util.toDateString(new Date(new Date()-30*24*60*60*1000),'yyyy-MM-dd'),
					time_sq_end = util.toDateString(new Date(),'yyyy-MM-dd'),
					qltData = {start:time_sq_start,end:time_sq_end,platfrom:plateForm.platfrom};
				$.ajax({
					type:'post',
					url:'/api-admin/userqualityassessment/get/overview',
					data:qltData,
					dataType:'json',
					beforeSend:function(request){
						request.setRequestHeader('Authorization',layui.data('author').Authorization);
					},
					success:function(res){
						var dta = [];
						if(res.code == 0){
							dta = res.data;
						}
						$("#user_total").text(dta.userTotalCount);
						$("#normal_user").text(dta.userNormalCount);
						$("#user_dubious").text(dta.userDubiousCount);
						if(dta.userDetailsList.length>0){
							var labels = [],dataUserTotalCount=[],dataUserNormalCount=[],dataUserDubiousCount=[];
							for(var i in dta.userDetailsList){
								labels.push(dta.userDetailsList[i].time);
								dataUserTotalCount.push(dta.userDetailsList[i].userTotalCount);
								dataUserNormalCount.push(dta.userDetailsList[i].userNormalCount);
								dataUserDubiousCount.push(dta.userDetailsList[i].userDubiousCount);
							}
							var datasets = [
								{
									label: '总用户',
									borderColor: '#FFbF40',
									backgroundColor: 'rgba(195,203,214)',
									data: dataUserTotalCount
								},
								{
									label: '正常用户',
									borderColor: '#84AAE1',
									backgroundColor: 'rgba(195,203,214)',
									data:dataUserNormalCount
								},
								{
									label: '可疑用户',
									borderColor: '#9966ff',
									backgroundColor: 'rgba(195,203,214)',
									data:dataUserDubiousCount
								}
							];
						var title = {
								display: true,
								text: ''
							},
							tooltips= {
								mode: 'index',
								intersect: false
							},
							hover={
								mode: 'index',
								intersect: false
							},
							scales = {
								xAxes:[{
									scaleLabel: {
										display: true,
										labelString: ''
									}
								}],
								yAxes:[{
									display: true,
									scaleLabel: {
										display: true,
										labelString: ''
									}
								}]
							}
						var zlpg_config = config_chart('line',labels,datasets,true,title,tooltips,hover,scales);
						var zlpg_ctx = document.getElementById('zlpg_canvas').getContext('2d');
						window.myLine = new Chart(zlpg_ctx, zlpg_config);
						}		
					}
				});
				//静默用户折线图
				$.ajax({
					type:'post',
					url:'/api-admin/userqualityassessment/get/silence',
					data:qltData,
					dataType:'json',
					beforeSend:function(request){
						request.setRequestHeader('Authorization',layui.data('author').Authorization);
					},
					success:function(res){
						var dta = [];
						if(res.code == 0){
							dta = res.data;
						}
						$("#dubious_user").html(dta.userSilenceCount);
						$("#dubious_userzb").html(dta.silence_totalProportion+"%");
						if(dta.userDetailsList.length>0){
							var userSilenceCount =[],silence_dubiousProportion =[],labels=[];
							for(var i in dta.userDetailsList){
								labels.push(dta.userDetailsList[i].time);
								userSilenceCount.push(dta.userDetailsList[i].userSilenceCount);
								silence_dubiousProportion.push(dta.userDetailsList[i].silence_dubiousProportion);
							}
							var datasets = [
								{
									label: '静默用户',
									borderColor: '#FFbF40',
									backgroundColor: 'rgba(195,203,214)',
									data: userSilenceCount
								},
								{
									label: '静默用户占比',
									borderColor: '#84AAE1',
									backgroundColor: 'rgba(195,203,214)',
									data:silence_dubiousProportion
								}
							];
						var title = {
								display: true,
								text: ''
							},
							tooltips= {
								mode: 'index',
								intersect: false
							},
							hover={
								mode: 'index',
								intersect: false
							},
							scales = {
								xAxes:[{
									scaleLabel: {
										display: true,
										labelString: ''
									}
								}],
								yAxes:[{
									display: true,
									scaleLabel: {
										display: true,
										labelString: ''
									}
								}]
							}
						var jmyh_config = config_chart('line',labels,datasets,true,title,tooltips,hover,scales);
						var jmyh_ctx = document.getElementById('jmyh_canvas').getContext('2d');
						window.myLine = new Chart(jmyh_ctx, jmyh_config);
						}
					}
				});
				//静默用户表格
				$.ajax({
					type:'post',
					url:'/api-admin/userqualityassessment/get/silence',
					data:qltData,
					dataType:'json',
					beforeSend:function(request){
						request.setRequestHeader('Authorization',layui.data('author').Authorization);
					},
					success:function(res){
					var data = [],count=0;
						if(res.code == 0){
							data = res.data.userDetailsList;
							count = data.length;
						}
						if(data.length>0){
							var head_temp = Handlebars.compile($("#head_template").html());
							$("#thead_list_jmyh").html(head_temp(['日期','静默用户','占总用户比例','占可疑用户比例']));
							var tableList_temp = Handlebars.compile($("#table_jmyh_template").html());
							$("#tbody_list_jmyh").html(tableList_temp(dealData(data,1,5)));
							$("#page_template_jmyh").html('<div id="page_jmyh"></div>');
							laypage.render({
								elem:'page_jmyh',
								theme:'#1E9FFF',
								count:count,
								limit:5,
								layout:['prev','page','next','count'],
								jump:function(obj,first){
									if(!first){
										$("#tbody_list_jmyh").html(tableList_temp(dealData(data,obj.curr,5)));
									}
								}
							});		
						}else{
							$("#tbody_list_jmyh").html('<tr><td colspan="4">暂无数据</td></tr>');
						}
					}
				});
				//分渠道质量对比
				$.ajax({
					type:'post',
					url:'/api-admin/userqualityassessment/get/channle',
					data:qltData,
					dataType:'json',
					beforeSend:function(request){
						request.setRequestHeader('Authorization',layui.data('author').Authorization);
					},
					success:function(res){
						var dta = [];
						if(res.code == 0){
							dta = res.data;
						}
						if(dta.length>0){
							var duibi_template = Handlebars.compile($("#duibi_template").html());
							$("#tableList").html(duibi_template(dealData(dta,1,5)));
							$("#page_zldb").html('<div id="page"></div>');
							laypage.render({
								elem:'page',
								count:dta.length,
								limit:5,
								layout:['prev','page','next','count'],
								jump:function(obj,first){
									if(!first){
										$("#tableList").html(duibi_template(dealData(dta,obj.curr,5)));
									}
								}
							});						
						}else{
							$("#tableList").html('<tr><td colspan="8" style="height:40px;">暂无数据</td></tr>')
						}
					}
				});
				//用户质量评估概览图表	
				$('#user_chart').on('click',function(){
					$("#user_mychart").empty();
					$(this).css('color','#8EB2E8');
					$('#user_table').css('color','#CCCCCC');
					$('#user_mychart').css('display','block');
					$('#user_mytable').css('display','none');
					$("#user_mychart").html('<canvas id="zlpg_canvas" style="width: 100%; height: 300px;"></canvas>');
					var times_qs_slot = $('#date').val(),
					time_sq_start = times_qs_slot.split(' ~ ')[0],
					time_sq_end = times_qs_slot.split(' ~ ')[1],
					 qltData = {start:time_sq_start,end:time_sq_end,platfrom:plateForm.platfrom},dta=[]; 
					 cjhd.json('/api-admin/userqualityassessment/get/overview',qltData,function(res){
						 if(res.code == 0){
							dta = res.data;
						 }
					 },{type:'post'});
						$("#user_total").text(dta.userTotalCount);
						$("#normal_user").text(dta.userNormalCount);
						$("#user_dubious").text(dta.userDubiousCount);
					 if(dta.userDetailsList.length>0){
						var labels = [],dataUserTotalCount=[],dataUserNormalCount=[],dataUserDubiousCount=[];
							for(var i in dta.userDetailsList){
								labels.push(dta.userDetailsList[i].time);
								dataUserTotalCount.push(dta.userDetailsList[i].userTotalCount);
								dataUserNormalCount.push(dta.userDetailsList[i].userNormalCount);
								dataUserDubiousCount.push(dta.userDetailsList[i].userDubiousCount);
							}
							var datasets = [
								{
									label: '总用户',
									borderColor: '#FFbF40',
									backgroundColor: 'rgba(195,203,214)',
									data: dataUserTotalCount
								},
								{
									label: '正常用户',
									borderColor: '#84AAE1',
									backgroundColor: 'rgba(195,203,214)',
									data:dataUserNormalCount
								},
								{
									label: '可疑用户',
									borderColor: '#9966ff',
									backgroundColor: 'rgba(195,203,214)',
									data:dataUserDubiousCount
								}
							];
						var title = {
								display: true,
								text: ''
							},
							tooltips= {
								mode: 'index',
								intersect: false
							},
							hover={
								mode: 'index',
								intersect: false
							},
							scales = {
								xAxes:[{
									scaleLabel: {
										display: true,
										labelString: ''
									}
								}],
								yAxes:[{
									display: true,
									scaleLabel: {
										display: true,
										labelString: ''
									}
								}]
							}
						var zlpg_config = config_chart('line',labels,datasets,true,title,tooltips,hover,scales);
						var zlpg_ctx = document.getElementById('zlpg_canvas').getContext('2d');
						window.myLine = new Chart(zlpg_ctx, zlpg_config);
					 }
				});
				$('#user_table').on('click',function(){
					$("#user_mychart").empty();
					$(this).css('color','#8EB2E8');
					$('#user_chart').css('color','#CCCCCC');
					$('#user_mychart').css('display','none');
					$('#user_mytable').css('display','block');
					var times_qs_slot = $('#date').val(),
					time_sq_start = times_qs_slot.split(' ~ ')[0],
					time_sq_end = times_qs_slot.split(' ~ ')[1],
					qltData = {start:time_sq_start,end:time_sq_end,platfrom:plateForm.platfrom},dta=[];
					cjhd.json('/api-admin/userqualityassessment/get/overview',qltData,function(res){
						dta = res.data;
					},{type:'post'});
					var head_list = ['日期','总用户','正常用户','正常用户占比','可疑用户','可疑用户占比'];
					var head_template = Handlebars.compile($("#head_template").html());	
					$("#thead_list").html(head_template(head_list));  
					if(dta.userDetailsList.length>0){
						var tableList_template = Handlebars.compile($("#table_quality_template").html());
						$("#tbody_list").html(tableList_template(dealData(dta.userDetailsList,1,5)));
						$("#page_template").html('<div id="page"></div>');
						laypage.render({
							elem:'page',
							theme:'#1E9FFF',
							count:dta.userDetailsList.length,
							limit:5,
							layout:['prev','page','next','count'],
							jump:function(obj,first){
								if(!first){
									$("#tbody_list").html(tableList_template(dealData(dta.userDetailsList,obj.curr,5)));	
								}
							}
						});

					}else{
						$("#tbody_list").html('<tr><td colspan="6">暂无数据</td></tr>')					
					}
				});
				//数据处理
				function dealData(data,curr,num){
					var dta = [];
					return dta.concat(data).splice(curr*num-num,num);
				}
				//质量评估数据下载
				$('#zlpg_updown').on('click',function(){
					alert('质量评估数据下载：421');
				});
				//静默用户质量评估概览图表
				$('#jm_user_chart').on('click',function(){
					$(this).css('color','#8EB2E8');
					$('#jm_user_table').css('color','#CCCCCC');
					$('#jm_user_mychart').css('display','block');
					$('#jm_user_mytable').css('display','none');

				});
				$('#jm_user_table').on('click',function(){
					$(this).css('color','#8EB2E8');
					$('#jm_user_chart').css('color','#CCCCCC');
					$('#jm_user_mychart').css('display','none');
					$('#jm_user_mytable').css('display','block');
				});
				//静默用户数据下载
				$('#jm_user_updown').on('click',function(){
					alert('静默用户数据下载：430');
				});
				//质量对比查询
				$('#zldb_seach').on('click',function(){
					alert('zldb_seach');
				});
				//质量对比下载
				$('#zldb_updown').on('click',function(){
					alert('zldb_updown:442');
				});
				var sd_f = 0;
				form.on('checkbox(checkbox_sd)',function(data){
					if(sd_f==0){
						var str = '';
							str += '<li class="icon icon-calendar" style="float:left; margin-top: 2px;"></li>';
							str += '<div style="float:left;margin-top: -10px;">';
							str += '<input type="text" name="sd_date" id="sd_date" class="layui-input" style="border:none;"/>';
							str += '</div>';
							str += '<li class="icon icon-angle-down" style="float:left; margin-left: -5px;"></li>';
						$('.tab_sd_date').html(str);
							laydate.render({
							elem:'#sd_date',
							type:'date',
							range:'~',
							value:'2018-10-1 ~ 2019-03-21'
								});
						form.render();
						sd_f = 1;
					}else{
						$('.tab_sd_date').empty();
						sd_f = 0;
					}
					return false;
				});
			
				//阻止时间冒泡
				function stopPropagation(e) {
				    var ev = e || window.event;
				    if (ev.stopPropagation) {
				        ev.stopPropagation();
				    }
				    else if (window.event) {
				        window.event.cancelBubble = true;//兼容IE
				    }
				}
				$(".filter").on('click',function(e){
					$(".dropdown-content").show();
					// $(".dropdown-content").slideDown('slow');
					stopPropagation(e);
				});
				$(document).bind('click',function(){
					$(".dropdown-content").hide();
					// $(".dropdown-content").slideUp('slow');
				});
				$(".dropdown-content").click(function (e) {
				    stopPropagation(e);
				});
				//平台事件	
				$("#filter").on('click',function(){
					$(".dropdown-content").hide();
					var len = $(".filter_left").children(".filter_icon").size();
						if(len>1){
							cjhd.savePlateForm({});
							window.location.reload();
							return; 
						}else{
						var plate = $(".filter_left").children(".filter_icon").attr("id");
							//**** 平台查询*/

							cjhd.savePlateForm({platfrom:plate});
							window.location.reload();
							return;

							//*****end */
						}
				});
				$("#reback").on('click',function(){
					$(".dropdown-content").hide();
				});
				// 筛选
				var flag =0 ;
				$("#btn_screen").on('click',function(e){
					if(flag==0){
						$(".shaixuankuang").show();
						flag = 1;
						stopPropagation(e);
					}else{
						$(".shaixuankuang").hide();
						flag = 0;
						stopPropagation(e);
						
					}
				});
				$(document).bind('click',function(e){
					$(".shaixuankuang").hide();
				});
				$(".shaixuankuang").on('click',function(e){
					stopPropagation(e);
				});
				$("#shaixuankuang_down_qx").on('click',function(){
					$(".shaixuankuang").hide();
				});
    exports('qualityasesment',{});
});