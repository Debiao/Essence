var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
		data = { size: 10, sort: 'DESC', sortBy: 'id',page:0};
		Handlebars.registerHelper('if_eq', function(v1, v2, opts) {
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);
		});
	cjhd.json('/api-admin/cardbags/find/all', data, function (res) {
		dta = res.data.data;
		count = res.data.total;
		form.render();
	}, { type: 'post' });
	if(dta.length>0){
		
		var myTemplate=	Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));
			$("#page-template").html('<div id="page"></div>');
		//执行一个laypage实例
		laypage.render({
			elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
			, count: count //数据总数，从服务端得到
			, limit: 10
			, layout: ['prev', 'page', 'next', 'count']
			, jump: function (obj, first) {
				data.page = obj.curr - 1;
				//首次不执行
				if (!first) {
					// console.log(data);
					cjhd.json('/api-admin/cardbags/find/all', data, function (res) {
						dta = res.data.data;
						count = res.data.total;
						$("#tableList").empty();
						var myTemplate=	Handlebars.compile($("#table-template").html());
						$("#tableList").html(myTemplate(dta));
					}, { type: 'post' });
					//
				}
			}
		});
	}else{
		$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='12'>暂无数据</td></tr>");
	}	
	//全查
	form.on('submit(searchAll)',function(){
		$("#tableList").empty();
		$("#page-template").empty();
		data.page=0;
		cjhd.json('/api-admin/cardbags/find/all', data, function (res) {
			dta = res.data.data;
			count = res.data.total;
			form.render();
		}, { type: 'post' });
		if(dta.length==0){
			var myTemplate=	Handlebars.compile($("#table-template").html());
				$("#tableList").html(myTemplate(dta));
				$("#page-template").html('<div id="page"></div>');
			//执行一个laypage实例
			laypage.render({
				elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					data.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						// console.log(data);
						cjhd.json('/api-admin/cardbags/find/all', data, function (res) {
							dta = res.data.data;
							count = res.data.total;
							$("#tableList").empty();
							var myTemplate=	Handlebars.compile($("#table-template").html());
							$("#tableList").html(myTemplate(dta));
						}, { type: 'post' });
						//
					}
				}
			});
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='12'>暂无数据</td></tr>");
		}
		return false;
	});
    //ID查询
    form.on('submit(searchById)',function(){
		$("#tableList").empty();
		$("#page-template").empty();
        var id=$('input[name="id"]').val();
        cjhd.json('/api-admin/cardbags/find/id',{id:id},function(res){
            dta=[res.data];
			form.render(); 
		},{type:'post'});
		if(dta.length>0){
			var myTemplate=	Handlebars.compile($("#table-template").html());
			$("#tableList").html(myTemplate(dta));
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
		}
        return false;
    });
	//用户id查询
	var userIdData={page:0,size:10,sort:'DESC',sortBy:'id'};
    form.on('submit(searchByByuserId)',function(){
		var userId=$('input[name="userId"]').val();
		userIdData.userId=userId;
        cjhd.json('/api-admin/cardbags/find/user',userIdData,function(res){
            dta=res.data.data;
            count=res.data.total;
			form.render(); 
		},{type:'post'});
		if(dta.length>0){
			var myTemplate=	Handlebars.compile($("#table-template").html());
				$("#tableList").html(myTemplate(dta));
				$("#page-template").html('<div id="page"></div>');
			//执行一个laypage实例
			laypage.render({
				elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
				, count: count //数据总数，从服务端得到
				, limit: 10
				, layout: ['prev', 'page', 'next', 'count']
				, jump: function (obj, first) {
					userIdData.page = obj.curr - 1;
					//首次不执行
					if (!first) {
						// console.log(data);
						cjhd.json('/api-admin/cardbags/find/user', userIdData, function (res) {
							dta = res.data.data;
							count = res.data.total;
							$("#tableList").empty();
							var myTemplate=	Handlebars.compile($("#table-template").html());
							$("#tableList").html(myTemplate(dta));
						}, { type: 'post' });
						//
					}
				}
			});
		}else{
			$("#tableList").html("<tr class='tbody' style='height:40px;'><td colspan='11'>暂无数据</td></tr>");
		}
        return false;
    });
 
	exports('cardbag', {});
	
});