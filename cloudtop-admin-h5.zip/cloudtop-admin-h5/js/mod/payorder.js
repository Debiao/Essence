var dta=[],count,countToday,countThisWeek;
layui.define(['form','layer','jquery','cjhd','laydate','laypage','element','util'],function(exports){
    var form = layui.form,
    $= layui.jquery,
    layer=layui.layer,
    laydate=layui.laydate,
    laypage=layui.laypage,
    util=layui.util,
    cjhd=layui.cjhd,
    id;
    laydate.render({
        elem:'#year',
        type:'year'
    });	
    laydate.render({
        elem:'#month',
        type:'month'
    });	
    laydate.render({
        elem:'#year_stat',
        type:'year'
    });
    laydate.render({
        elem:"#month_star",
        type:"month"
    });
    form.verify({
        year:[/^(\d{4})$/, "日期格式不正确"]
      }); 
    form.verify({
        year_stat:[/^(\d{4})$/, "日期格式不正确"]
    });   
    form.verify({
        month:[/^(\d{4})[-\/](\d{1}|0\d{1}|1[0-2])*$/, "日期格式不正确"]
    }); 
    form.verify({
        month_star:[/^(\d{4})[-\/](\d{1}|0\d{1}|1[0-2])*$/, "日期格式不正确"]
    }); 
var chart = document.getElementById('myechart');    
var echart = echarts.init(chart); 
var	option = {
        title : {
            text: '订单统计',
            subtext: '年'
        },
        tooltip : {
            trigger: 'axis'
        },
        legend: {
            data:['订单统计']
        },
        toolbox: {
            show : true,
            feature : {
                mark : {show: true},
                dataView : {show: true, readOnly: false},
                magicType : {show: true, type: ['line', 'bar']},
                restore : {show: true},
                saveAsImage : {show: true}
            }
        },
        calculable : true,
        xAxis : [
            {
                type : 'category',
                data : ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']
            }
        ],
        yAxis : [
            {
                type : 'value'
            }
        ],
        series : [
            {
                name:'订单统计',
                type:'bar',
                data:[],
                markPoint : {
                    data : [
                        {type : 'max', name: '最大值'},
                        {type : 'min', name: '最小值'}
                    ]
                },
                markLine : {
                    data : [
                        {type : 'average', name: '平均值'}
                    ]
                }
            }
        ]
    };
  
    echart.setOption(option);	
    //年统计
    form.on('submit(searchYear_stat)',function(data){
        var year = $('input[name="year_stat"]').val();
           cjhd.json('/api-admin/payorder/stat/year/other',{year:year},function(res){
                dta = res.data.dataList; 
           },{type:'post'}); 
           var x_data = [],series_data = []; 
           if(dta.length>0){
                for(var i in dta){
                    x_data.push(dta[i].paramName+"月");
                    series_data.push(dta[i].paramCount);
                }
                var chart = document.getElementById('myechart'); 
                var echart = echarts.init(chart); 
                var	option = {
                    title : {
                        text: '订单统计',
                        subtext: year+'年'
                    },
                    tooltip : {
                        trigger: 'axis'
                    },
                    legend: {
                        data:['订单统计']
                    },
                    toolbox: {
                        show : true,
                        feature : {
                            mark : {show: true},
                            dataView : {show: true, readOnly: false},
                            magicType : {show: true, type: ['line', 'bar']},
                            restore : {show: true},
                            saveAsImage : {show: true}
                        }
                    },
                    calculable : true,
                    xAxis : [
                        {
                            type : 'category',
                            data : x_data
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value'
                        }
                    ],
                    series : [
                        {
                            name:'订单统计',
                            type:'bar',
                            data:series_data,
                            markPoint : {
                                data : [
                                    {type : 'max', name: '最大值'},
                                    {type : 'min', name: '最小值'}
                                ]
                            },
                            markLine : {
                                data : [
                                    {type : 'average', name: '平均值'}
                                ]
                            }
                        }
                    ]
                };
                echart.setOption(option);   
           }
        return false;
    });
    form.on('submit(searchMoth_stat)',function(data){
        var yearAndmonth = $('input[name="month_star"]').val();
            var year = yearAndmonth.split('-')[0],month = yearAndmonth.split('-')[1];
            cjhd.json('/api-admin/payorder/stat/month/other',{year:year,month:month},function(res){
                dta = res.data.dataList;
            },{type:'post'});
            var x_data = [],series_data = []; 
            if(dta.length>0){
                for(var i in dta){
                    x_data.push(dta[i].paramName+"天"); 
                    series_data.push(dta[i].paramCount);
                }
               //数字处理 
              if(month.charAt(0)<=0){
                month = month.substring(1);  
              }
                var chart = document.getElementById('myechart'); 
                var echart = echarts.init(chart); 
                var	option = {
                    title : {
                        text: '订单统计',
                        subtext: month+'月'
                    },
                    tooltip : {
                        trigger: 'axis'
                    },
                    legend: {
                        data:['订单统计']
                    },
                    toolbox: {
                        show : true,
                        feature : {
                            mark : {show: true},
                            dataView : {show: true, readOnly: false},
                            magicType : {show: true, type: ['line', 'bar']},
                            restore : {show: true},
                            saveAsImage : {show: true}
                        }
                    },
                    calculable : true,
                    xAxis : [
                        {
                            type : 'category',
                            data : x_data
                        }
                    ],
                    yAxis : [
                        {
                            type : 'value'
                        }
                    ],
                    series : [
                        {
                            name:'订单统计',
                            type:'bar',
                            data:series_data,
                            markPoint : {
                                data : [
                                    {type : 'max', name: '最大值'},
                                    {type : 'min', name: '最小值'}
                                ]
                            },
                            markLine : {
                                data : [
                                    {type : 'average', name: '平均值'}
                                ]
                            }
                        }
                    ]
                };
                echart.setOption(option);     
            }
        return false;
    });
    //全查
    Handlebars.registerHelper('formatDate',function(v1,opts){
        if(v1>0)
            return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
         else
            return "";   
    });
    var  data={size:10,sort:'DESC',page:0,sortBy:id};
    cjhd.json('/api-admin/payorder/find/all',data,function(res){
        dta = res.data.data;
        count=res.data.total;
    },{type:'post'});
    if(dta.length>0){   
        var myTemplate = Handlebars.compile($("#table-template").html());
        $("#tableList").html(myTemplate(dta));
        $("#page-template").html('<div id="page"></div>');
        laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        data.page=obj.curr-1;
                        if(!first){
                                cjhd.json('/api-admin/payorder/find/all',data,function(res){
                                    dta = res.data.data;
                                    count = res.data.count;
                                    $("#tableList").empty();  
                                    var myTemplate = Handlebars.compile($("#table-template").html());
                                    $("#tableList").html(myTemplate(dta));
                                },{type:'post'});     
                            }
                    }
             });
    }else{
        $("#tableList").html( "<tr class='tbody'><td colspan='8'>暂无数据</td></tr>"); 
    }
    var  dataAll={size:10,sort:'DESC',page:0,sortBy:id};
    $("#searchAll").click(function(){
        $('#page-template').empty();
        $("#tableList").empty();
        cjhd.json('/api-admin/payorder/find/all', dataAll, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        dataAll.page=0;
         if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $('#tableList').html(myTemplate(dta));
            $('#page-template').html('<div id="page"></div>');	   
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    dataAll.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        console.log(data);
                        cjhd.json('/api-admin/payorder/find/all', dataAll, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            console.log(dta);
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $('#tableList').html(myTemplate(dta));
                        }, { type: 'post' });
                        //
                    }
                }
            });	
         }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>"); 
         }   
        return false;
    });
     //今天订单
     var dataToday={size:15,sort:'DESC',page:0};
     $("#searchDayOrder").click(function(){
        $("#tableList").empty();
        $("#page-template").empty();
        cjhd.json('/api-admin/payorder/find/all/day',dataToday,function(res){
            dta = res.data.data;
            count = res.data.count;
        },{type:'post'});
        if(dta.length>0){
            var myTemplate=Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));  
            $("#page-template").html('<div id="page"></div>');
           laypage.render({
               elem:'page',
               count:count,
               limit:10,
               layout:['prev','page','next','count'],
               jump:function(obj,first){
                    dataToday.page=obj.curr-1;
                    if(!first){
                        cjhd.json('/api-admin/payorder/find/all/day',dataToday,function(res){
                            dta = res.data.data;
                            count = res.data.count;
                            $('#tableList').empty();
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $('#tableList').html(myTemplate(dta));
                        },{type:'post'});
                    }

               }
           });
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
        }
        
    });
   
     //本周订单
     dataThisWeek={size:15,sort:'DESC',page:0};
     $("#searchWeekOrder").click(function(){
        $("#tableList").empty();
        $("#page-template").empty();
        cjhd.json('/api-admin/payorder/find/all/week',dataThisWeek,function(res){
            dta = res.data.data;
            count = res.data.count;
        },{type:'post'}); 
        if(dta.length>0){
            var myTemplate=Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta)); 
            $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem:'page',
                count:count,
                limit:10,
                layout:['prev','page','next','count'],
                jump:function(obj,first){
                    dataThisWeek.page=obj.curr-1;
                     if(!first){
                         cjhd.json('/api-admin/payorder/find/all/week',dataThisWeek,function(res){
                             dta = res.data.data;
                             count = res.data.count;
                             $('#tableList').empty();
                             var myTemplate = Handlebars.compile($("#table-template").html());
                             $('#tableList').html(myTemplate(dta));
                         },{type:'post'});
                     }
    
                }
            });
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
        }
       
    });
     //本月订单
     var monthData={page:0,size:10,sort:'DESC'}
     $("#searchMothOrder").click(function(){
        $('#page-template').empty();
        $("#tableList").empty();
        cjhd.json('/api-admin/payorder/find/all/month', monthData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        monthData.page=0;
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $('#tableList').html(myTemplate(dta));
            $('#page-template').html('<div id="page"></div>');	
            
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    //obj包含了当前分页的所有参数，比如：
                    // 				console.log(obj.curr+":&&&&&&&"); //得到当前页，以便向服务端请求对应页的数据。
                    // 				console.log(obj.limit+":*******"); //得到每页显示的条数
                    monthData.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        console.log(data);
                        cjhd.json('/api-admin/payorder/find/all/month', monthData, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            console.log(dta);
                            // console.log(res);
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $('#tableList').html(myTemplate(dta));
                        }, { type: 'post' });
                        //
                    }
                }
            });	
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
        }
        return false;
    });
     //今年订单
     var yearData={page:0,size:10,sort:'DESC'}
     $("#searchYearOrder").click(function(){
        $('#page-template').empty();
        $("#tableList").empty();
        cjhd.json('/api-admin/payorder/find/all/year', yearData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        yearData.page=0;
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $('#tableList').html(myTemplate(dta));
            $('#page-template').html('<div id="page"></div>');	
            
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    yearData.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        console.log(data);
                        cjhd.json('/api-admin/payorder/find/all/year', yearData, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            console.log(dta);
                            // console.log(res);
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $('#tableList').html(myTemplate(dta));
                        }, { type: 'post' });
                        //
                    }
                }
            });	
           
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
        }
        return false;
    });

   
     //按年查
     var searchYearData={page:0,size:10,sort:'DESC'};
      form.on('submit(searchYear)',function(){
        var year= $('input[name="year"]').val();
        $('#page-template').empty();
        $("#tableList").empty();
        searchYearData.year= year;
        console.log(JSON.stringify(searchYearData));
        cjhd.json('/api-admin/payorder/find/all/year/other', searchYearData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        searchYearData.page=0;
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $('#tableList').html(myTemplate(dta));
            $('#page-template').html('<div id="page"></div>');	
            
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    searchYearData.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        console.log(data);
                        cjhd.json('/api-admin/payorder/find/all/year/other', searchYearData, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            console.log(dta);
                            // console.log(res);
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $('#tableList').html(myTemplate(dta));
                        }, { type: 'post' });
                        //
                    }
                }
            });	
          
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
        }
          return false;
      });
 
      
//按月查
var searchMoth={page:0,size:10,sort:'DESC'};
    form.on('submit(searchMoth)',function(){
        var yearAndMoth=$('input[name="month"]').val();
        var yam=yearAndMoth.split("-");
         var year=yam[0],moth=yam[1];
         searchMoth.year=year;
         searchMoth.month= moth;
        $('#page-template').empty();
        $("#tableList").empty();
        cjhd.json('/api-admin/payorder/find/all/month/other', searchMoth, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        searchMoth.page=0;
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $('#tableList').html(myTemplate(dta));
            $('#page-template').html('<div id="page"></div>');	
                laypage.render({
                    elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                    , count: count //数据总数，从服务端得到
                    , limit: 10
                    , layout: ['prev', 'page', 'next', 'count']
                    , jump: function (obj, first) {
                        searchMoth.page = obj.curr - 1;
                        //首次不执行
                        if (!first) {
                            console.log(data);
                            cjhd.json('/api-admin/payorder/find/all/month/other', searchMoth, function (res) {
                                dta = res.data.data;
                                count = res.data.total;
                                console.log(dta);
                                // console.log(res);
                                var myTemplate = Handlebars.compile($("#table-template").html());
                                $('#tableList').html(myTemplate(dta));
                            }, { type: 'post' });
                            //
                        }
                    }
                });	
          
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>");
    }
        return false;
});
   
    //按订单号
    form.on('submit(serchByOrder)',function(){
        $('#page-template').empty();
        $("#tableList").empty();
        var orderNo=$('input[name="outTradeNo"]').val();
        cjhd.json('/api-admin/payorder/find/outTradeNo',{outTradeNo:orderNo},function(res){
            dta = [res.data];
        },{type:'post'});
          if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $('#tableList').html(myTemplate(dta));
        }else{
            $("#tableList").html( "<tr class='tbody' style='height:40px;'><td colspan='8'>暂无数据</td></tr>"); 
          }  
       return false; 
    });
   

    exports('payorder',{})
});