var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
        table = layui.table,
        util=layui.util,
		laydate = layui.laydate,
		cjhd = layui.cjhd,
		$ = layui.jquery,
		num = 10,
        data = { size: 15, sort: 'DESC', sortBy: 'id',deleted:false };
        Handlebars.registerHelper('if_eq',function(v1, v2, opts){
            if(v1 == v2)
                    return opts.fn(this);
            else 
                    return opts.inverse(this);
        });
        Handlebars.registerHelper('formatDate',function(v1,optis){
            if(v1>0)
                return util.toDateString(v1,'yyyy-MM-dd HH:mm:ss');
            else    
                return "";
        });
        cjhd.json('/api-admin/whitelist/find/all', data, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate= Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
                $("#page-template").html('<div id="page"></div>');
            laypage.render({
                elem: 'page' //注意，这里的 test1 是 ID，不用加 # 号
                , count: count //数据总数，从服务端得到
                , limit: 10
                , layout: ['prev', 'page', 'next', 'count']
                , jump: function (obj, first) {
                    data.page = obj.curr - 1;
                    //首次不执行
                    if (!first) {
                        // console.log(data);
                        cjhd.json('/api-admin/whitelist/find/all', data, function (res) {
                            dta = res.data.data;
                            count = res.data.total;
                            var myTemplate = Handlebars.compile($("#table-template").html());
                            $("#tableList").html(myTemplate(dta));
                        }, { type: 'post' });
                        //
                    }
                }
            });
        }else{
            $("#tableList").html("<tr style='height:40px; text-align:center;'><td colspan='8'>暂无数据</td></tr>");
        }
    //全查
    var searchData={size: 15, sort: 'DESC', sortBy: 'id',deleted:false};
    form.on('submit(search)',function(){
        $("#tableList").empty();
        $("page-template").empty();
        cjhd.json('/api-admin/whitelist/find/all', searchData, function (res) {
            dta = res.data.data;
            count = res.data.total;
            form.render();
        }, { type: 'post' });
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        searchData.page=obj.curr-1; 
                        if(!first){
                            cjhd.json('/api-admin/whitelist/find/all', searchData, function (res) {
                                dta = res.data.data;
                                count = res.data.total;
                                var myTemplate = Handlebars.compile($("#table-template").html());
                                $("#page-template").html(myTemplate(dta));
                            }, { type: 'post' });
                        }
                    }
                });
        }else{
            $("#tableList").html("<tr style='height:40px; text-align:center;'><td colspan='8'>暂无数据</td></tr>");
        }
        return false;
    });
    //ID查询
    form.on('submit(searchByID)',function(){
        $("#tableList").empty();
        $("#page-template").empty();
        var id=$('input[name="id"]').val();
        cjhd.json('/api-admin/whitelist/find/id',{id:id},function(res){
            dta=[res.data];
        },{type:'post'});
        if(dta.length>0){
            var myTemplate = Handlebars.compile($("#table-template").html());
            $("#tableList").html(myTemplate(dta));
            form.render(); 
        }else{
            $("#tableList").html("<tr style='height:40px; text-align:center;'><td colspan='8'>暂无数据</td></tr>");
        }
        return false;
    });
    //value值查詢
    var vleData={size: 15, sort: 'DESC', sortBy: 'id',deleted:false,page:0};
    form.on('submit(searchByValue)',function(){
         $("#tableList").empty();
         $("#page-template").empty();   
        var vle=$('input[name="value"]').val();
        vleData.value=vle;
        cjhd.json('/api-admin/whitelist/find/vlaue',vleData,function(res){
            dta=res.data.data;
            count = res.data.total;
        },{type:'post'});
        if(dta.length>0){
            var myTemplate= Handlebars.compile($("#table-template").html());
                $("#tableList").html(myTemplate(dta));
                $("#page-template").html('<div id="page"></div>');
                laypage.render({
                    elem:'page',
                    count:count,
                    limit:10,
                    layout:['prev','page','next','count'],
                    jump:function(obj,first){
                        vleData.page=obj.curr-1
                        if(!first){
                            cjhd.json('/api-admin/whitelist/find/vlaue',vleData,function(res){
                                 dta=res.data.data;
                                 count=res.data.total;   
                            },{type:'post'});
                         var myTemplate = Handlebars.compile($("#table-template").html());
                            $("#tableList").html(myTemplate(dta));   
                        } 
                    }
                });
        }else{
            $("#tableList").html("<tr style='height:40px; text-align:center;'><td colspan='8'>暂无数据</td></tr>");
        }
        form.render(); 
        return false;
    });
   //添加
    form.on('submit(add)',function(){
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['500px','60%'],
                content:'page/whitelist/addWhitelist.html'
        });
        return false;
    });
    //删除
    form.on('submit(deleteWhiltelist)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.json('/api-admin/whitelist/deleted',{id:id},function(res){
            if(res.code==0){
                parent.layer.close(inx);
                parent.location.reload();
            }else{
                layer.msg('服务器出错了...');
                parent.layer.close();
            }
        },{type:'post'});
        return false;
    });
    //编辑
    form.on('submit(editWhiltelist)',function(data){
        var id = $(data.elem).parents('tr').find('.id').text();
        cjhd.edit(id);
        layer.open({
                type:2,
                title:'',
                shadeClose:true,
                shade:0.8,
                area:['400px','40%'],
                content:'page/whitelist/editWhitelist.html' 
        });
        return false;
    });
   
	exports('whiltelist', {});
	
});