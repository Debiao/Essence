var dta = [], count, data = [], tt = [], index = 0, td = [], checks = [],inx = parent.layer.getFrameIndex(window.name);
layui.define(['form', 'layer', 'jquery', 'table', 'laypage', 'laydate', 'cjhd','util'], function (exports) {
	// console.log("*****************************************")
	var form = layui.form,
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
		table = layui.table,
		laydate = layui.laydate,
		util=layui.util,
		cjhd = layui.cjhd,
		$ = layui.jquery;
		// data = { size: 10, sort: 'DESC', sortBy: 'id',deleted:false,page:0};
		Handlebars.registerHelper('if_eq', function(v1, v2, opts) {
			if(v1 == v2)
				return opts.fn(this);
			else
				return opts.inverse(this);
		});
		Handlebars.registerHelper("formatDate", function(intoTime, opts) {
			if(intoTime>0)
				return	util.toDateString(intoTime,'yyyy-MM-dd HH:mm:ss');
			else
				return 	"";
		});	
		
		//全查
		var allData = {page:0,size:10,sort:'ASC',sortBy:'id'}
		cjhd.json('/api-admin/rolepermission/find/all',allData,function(res){
			dta =res.data.data;
			count = res.data.total;
		},{type:'post'});
		if(dta.length>0){
			var template = Handlebars.compile($("#table-template").html());
			$("#tableList").html(template(dta));
			$("#page-template").html('<div id="page"></div>');	
			laypage.render({
				elem:'page',
				count:count,
				limit:allData.size,
				layout:['prev','page','next','count'],
				jump:function(obj,first){
					allData.page = obj.curr - 1;
					if(!first){
						cjhd.json('/api-admin/rolepermission/find/all',allData,function(res){
							 dta = res.data.data;
							 count = res.data.total;
						},{type:'post'});
						 $("#tableList").empty();
						 var template = Handlebars.compile($("#table-template").html());
						 $("#tableList").html(template(dta));			
					}
				}
			});
		}else{
			$("#tableList").html("<tr style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
		}
		//全查
		form.on('submit(searchByAll)',function(){

		});
        //通过角色名查看角色  
        form.on('submit(searchByroleName)',function(){     
			var roleName = $('input[name="roleName"]').val();              
            cjhd.json('/api-admin/rolepermission/find/role',{roleName:roleName},function(res) {
                dta = [res.data];
            }, { type: 'post' });
            if(dta.length>0){
                    var myTemplate= Handlebars.compile($("#table-template").html());
                    $("#tableList").html(myTemplate(dta));
                }else{
                    $("#tableList").html("<tr style='height:40px;'><td colspan='6'>暂无数据</td></tr>");
                }
            form.render();
        return false;
		});  

	//修改权限	
        form.on('submit(updateQuestionanser)',function(data){
			var id = $(data.elem).parents('tr').find('.id').text();
			cjhd.edit(id);
			layer.open({
				type:2,
				title:'',
				shadeClose:true,
				shade:'0.8',
				area:['700px; height:55%;'],
				content:'page/priviligemanagement/editPriviligemanagement.html'
			});
            return false;
        });
	//添加权限
	form.on('submit(add)',function(data){
		var id = $(data.elem).parents('tr').find('.id').text();
		cjhd.edit(id);
		layer.open({
			type:2,
			title:'',
			shadeClose:true,
			shade:'0.8',
			area:['700px; height:70%'],
			content:'page/priviligemanagement/addPriviligemanagement.html'	
		});
		
		return false;
	});	

	exports('priviligemanagement', {});
	
});