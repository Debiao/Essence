var form;
layui.config({
	base : "js/"
}).use(['form','layer','jquery','laypage','laydate'],function(){
	var form = layui.form(),
		layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,
        laydate = layui.laydate,
		$ = layui.jquery;

	//加载页面数据
	var newsData = '';
	// $.get("newagent/json/newsList.json", function(data){//mmTradeQuery
    $.get("mmTradeQuery", function(agentData){//
			newsData = agentData.data;
        	newsList(newsData);
	});
    //数据查询
    form.on("submit(findData)",function(data){
        // layer.alert(JSON.stringify(data.field), {
        //     title: '最终的提交信息'
        // });
        $.ajax({
            url:'mmTradeQuery',
			type:'post',
            dataType:'json',
            data:data.field,
            success:function (agentData) {
                newsData = agentData.data;
                newsList(newsData);
            }
        });
        return false; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
    });

    $(".fenrun_btn").click(function(){

        var $checkbox = $('.news_list tbody input[type="checkbox"][name="checked"]');
        var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
        var  ordernos="";
        if($checkbox.is(":checked")){
            for(var j=0;j<$checked.length;j++){
                for(var i=0;i<newsData.length;i++){

                    if(newsData[i].orderno == $checked.eq(j).attr("data-id")){
                        if(newsData[i].status=="成功"&&newsData[i].balance_status=="已结算"&&newsData[i].profit_status=="未分润"){
                            var my=newsData[i].orderno;
                            if(ordernos==""){
                                ordernos+=my;
                            }else{
                                ordernos+=","+my;
                            }
						}else{
                        	layer.msg("此交易记录不允许结算");
							return;
						}

                        //     // $checked.eq(j).parents("tr").find("td:eq(3)").text("审核通过").removeAttr("style");
                        //     // //将选中状态删除
                        //     // $checked.eq(j).parents("tr").find('input[type="checkbox"][name="checked"]').prop("checked",false);
                        form.render();
                    }
                }
            }
        }else{
            layer.msg("请至少选择一个");
        }
        $.ajax({
			url : "separateSettlement",
			type : "POST",
			data:{"ordernos":ordernos},
			dataType : "json",
			success : function(data){
				console.log(data);
				if(data.msg!=""&&data.msg!=null){
                    layer.open({
                        type: 1
                        ,title: "提示框" //不显示标题栏
                        ,closeBtn: false
                        ,area: '300px;'
                        ,shade: 0.8
                        ,id: 'LAY_layuipro' //设定一个id，防止重复弹出
                        ,btn: ['确认']
                        ,btnAlign: 'c'
                        ,moveType: 1 //拖拽模式，0或者1
                        ,content: '<div style="padding: 50px; line-height: 22px; background-color: #393D49; color: #fff; font-weight: 300;">'+data.msg+'</div>'

                    });
				}

            }
        });
    });

    // //查询
	// $(".search_btn").click(function(){
	// 	var newArray = [];
	// 	if($(".search_input").val() != ''){
     //        	$.ajax({
	// 				url : "../../json/newsList.json",
	// 				type : "get",
	// 				dataType : "json",
	// 				success : function(data){
	// 					newsData = data;
	// 	            	newsData = newArray;
	// 	            	newsList(newsData);
	// 				}
	// 			});
     //            layer.close(index);
	// 	}else{
	// 		layer.msg("请输入需要查询的内容");
	// 	}
	// });

	//添加文章
	$(".newsAdd_btn").click(function(){
		var index = layui.layer.open({
			title : "添加文章",
			type : 2,
			content : "newsAdd.html",
			success : function(layero, index){
				layui.layer.tips('点击此处返回文章列表', '.layui-layer-setwin .layui-layer-close', {
					tips: 3
				});
			}
		});
		//改变窗口大小时，重置弹窗的高度，防止超出可视区域（如F12调出debug的操作）
		$(window).resize(function(){
			layui.layer.full(index);
		})
		layui.layer.full(index);
	})

	//推荐文章
	$(".recommend").click(function(){
		var $checkbox = $(".news_list").find('tbody input[type="checkbox"]:not([name="show"])');
		if($checkbox.is(":checked")){
			var index = layer.msg('推荐中，请稍候',{icon: 16,time:false,shade:0.8});
            setTimeout(function(){
                layer.close(index);
				layer.msg("推荐成功");
            },2000);
		}else{
			layer.msg("请选择需要推荐的文章");
		}
	})

	//审核文章
	$(".audit_btn").click(function(){
		var $checkbox = $('.news_list tbody input[type="checkbox"][name="checked"]');
		var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
		if($checkbox.is(":checked")){
			var index = layer.msg('审核中，请稍候',{icon: 16,time:false,shade:0.8});
            setTimeout(function(){
            	for(var j=0;j<$checked.length;j++){
            		for(var i=0;i<newsData.length;i++){
						if(newsData[i].newsId == $checked.eq(j).parents("tr").find(".news_del").attr("data-id")){
							//修改列表中的文字
							$checked.eq(j).parents("tr").find("td:eq(3)").text("审核通过").removeAttr("style");
							//将选中状态删除
							$checked.eq(j).parents("tr").find('input[type="checkbox"][name="checked"]').prop("checked",false);
							form.render();
						}
					}
            	}
                layer.close(index);
				layer.msg("审核成功");
            },2000);
		}else{
			layer.msg("请选择需要审核的文章");
		}
	})

	//批量删除
	$(".batchDel").click(function(){
		var $checkbox = $('.news_list tbody input[type="checkbox"][name="checked"]');
		var $checked = $('.news_list tbody input[type="checkbox"][name="checked"]:checked');
		if($checkbox.is(":checked")){
			layer.confirm('确定删除选中的信息？',{icon:3, title:'提示信息'},function(index){
				var index = layer.msg('删除中，请稍候',{icon: 16,time:false,shade:0.8});
	            setTimeout(function(){
	            	//删除数据
	            	for(var j=0;j<$checked.length;j++){
	            		for(var i=0;i<newsData.length;i++){
							if(newsData[i].orderno == $checked.eq(j).parents("tr").find("#order").attr("data-id")){
								newsData.splice(i,1);
								newsList(newsData);
							}
						}
	            	}
	            	$('.news_list thead input[type="checkbox"]').prop("checked",false);
	            	form.render();
	                layer.close(index);
					layer.msg("删除成功");
	            },2000);
	        })
		}else{
			layer.msg("请选择需要删除的文章");
		}
	})

	//全选
	form.on('checkbox(allChoose)', function(data){
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"])');
		child.each(function(index, item){
			item.checked = data.elem.checked;
		});
		form.render('checkbox');
	});

	//通过判断文章是否全部选中来确定全选按钮是否选中
	form.on("checkbox(choose)",function(data){
		var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"])');
		var childChecked = $(data.elem).parents('table').find('tbody input[type="checkbox"]:not([name="show"]):checked')
		if(childChecked.length == child.length){
			$(data.elem).parents('table').find('thead input#allChoose').get(0).checked = true;
		}else{
			$(data.elem).parents('table').find('thead input#allChoose').get(0).checked = false;
		}
		form.render('checkbox');
	})

	//是否展示
	form.on('switch(isShow)', function(data){
		var index = layer.msg('修改中，请稍候',{icon: 16,time:false,shade:0.8});
        setTimeout(function(){
            layer.close(index);
			layer.msg("展示状态修改成功！");
        },2000);
	});

	//操作
	$("body").on("click",".news_edit",function(){  //编辑
		layer.alert('您点击了文章编辑按钮，由于是纯静态页面，所以暂时不存在编辑内容，后期会添加，敬请谅解。。。',{icon:6, title:'文章编辑'});
	})

	$("body").on("click",".news_collect",function(){  //收藏.
		if($(this).text().indexOf("已收藏") > 0){
			layer.msg("取消收藏成功！");
			$(this).html("<i class='layui-icon'>&#xe600;</i> 收藏");
		}else{
			layer.msg("收藏成功！");
			$(this).html("<i class='iconfont icon-star'></i> 已收藏");
		}
	})

	$("body").on("click",".news_del",function(){  //删除
		var _this = $(this);
		layer.confirm('确定删除此信息？',{icon:3, title:'提示信息'},function(index){
			//_this.parents("tr").remove();
			for(var i=0;i<newsData.length;i++){
				if(newsData[i].newsId == _this.attr("data-id")){
					newsData.splice(i,1);
					newsList(newsData);
				}
			}
			layer.close(index);
		});
	})

	function newsList(that){
		//渲染数据
		function renderDate(data,curr){
            $(".news_content").html("");
			var dataHtml = '';
			if(!that){
				currData = newsData.concat().splice(curr*nums-nums, nums);
			}else{
				currData = that.concat().splice(curr*nums-nums, nums);
			}
			if(currData.length != 0){
				for(var i=0;i<currData.length;i++){
					dataHtml += '<tr>'
			    	+'<td><input type="checkbox" id="data-id" name="checked" data-id='+currData[i].orderno+' lay-skin="primary" lay-filter="choose"></td>'
			    	+'<td align="left">'+currData[i].fullName+'</td>'
			    	+'<td>'+currData[i].merchantno+'</td>'
			    	+'<td>'+currData[i].phone+'</td>'
					+'<td>'+currData[i].account_number+'</td>'
					/*+'<td>'+currData[i].orderno+'</td>'*/
					+'<td>'+currData[i].merchantlvid+'</td>'
					+'<td>'+currData[i].withdrawAmount+'</td>'
					+'<td>'+currData[i].currency+'</td>'
					+'<td>'+currData[i].actualAmount+'</td>'
					+'<td>'+currData[i].feeRates+'</td>'
					+'<td>'+currData[i].poundage+'</td>'
					+'<td>'+currData[i].exchangeRate+'</td>'
					+'<td>'+currData[i].gmt_create+'</td>'
					+'<td>'+currData[i].status+'</td>'
					+'<td>'+currData[i].balance_status+'</td>'
					+'<td>'+currData[i].profit_status+'</td>'
			    	+'</tr>';
				}
			}else{
				dataHtml = '<tr><td colspan="15">暂无数据</td></tr>';
			}
		    return dataHtml;
		}

		//分页
		var nums = 6; //每页出现的数据量
		if(that){
			newsData = that;
		}
		laypage({
			cont : "page",
			pages : Math.ceil(newsData.length/nums),
			jump : function(obj){
				$(".news_content").html(renderDate(newsData,obj.curr));
				$('.news_list thead input[type="checkbox"]').prop("checked",false);
		    	form.render();
			}
		})
	}
});
