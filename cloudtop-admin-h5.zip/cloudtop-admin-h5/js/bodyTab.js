/*
	@Author: 请叫我马哥
	@Time: 2017-04
	@Tittle: tab
	@Description: 点击对应按钮添加新窗口
*/
var tabFilter, menu = [], liIndex, curNav, delMenu, navs = [
	{
		"id": 51,
		"title": "功能列表",
		"icon": "&#xe62c;",
		"dic_address": "",
		"spread": false,
		"dicId": 0,
		"children": [{
			"id": 53,
			"title": "客服模块",
			"icon": "&#xe629;",
			"dic_address": "page/customer/customerList.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554118923000,
			"updateTime": null
		},
		{
			"id": 54,
			"title": "应用模块",
			"icon": "&#xe629;",
			"dic_address": "page/application/applicationList.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 3,
			"deleted": false,
			"createTime": 1554119050000,
			"updateTime": null
		},
		{
			"id": 55,
			"title": "收款账号模块",
			"icon": "&#xe629;",
			"dic_address": "page/account/accountList.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119123000,
			"updateTime": null
		},
		{
			"id": 56,
			"title": "订单模块",
			"icon": "&#xe629;",
			"dic_address": "page/order/orderList.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119223000,
			"updateTime": null
		},
		{
			"id": 57,
			"title": "通道列表",
			"icon": "&#xe629;",
			"dic_address": "page/paychannel/channellist.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119223000,
			"updateTime": null
		},
		{
			"id": 58,
			"title": "数据统计模块",
			"icon": "&#xe629;",
			"dic_address": "page/datastatistics/datastatistics.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119223000,
			"updateTime": null
		},
		{
			"id": 59,
			"title": "配置应用通道",
			"icon": "&#xe629;",
			"dic_address": "page/configurechannel/configurechannel.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119223000,
			"updateTime": null
		},
		{
			"id": 60,
			"title": "各渠道数据",
			"icon": "&#xe629;",
			"dic_address": "page/channeldata/channeldata.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119223000,
			"updateTime": null
		},
		// {
		// 	"id": 61,
		// 	"title": "应用数据",
		// 	"icon": "&#xe629;",
		// 	"dic_address": "page/appdata/appdata.html",
		// 	"spread": false,
		// 	"dicId": 51,
		// 	"flag": true,
		// 	"remark": "2019-04-19",
		// 	"jumpAddress": null,
		// 	"opened": false,
		// 	"sort": 2,
		// 	"deleted": false,
		// 	"createTime": 1554119223000,
		// 	"updateTime": null
		// },
		{
			"id": 62,
			"title": "参数配置",
			"icon": "&#xe629;",
			"dic_address": "page/parameterize/parameterize.html",
			"spread": false,
			"dicId": 51,
			"flag": true,
			"remark": "2019-04-19",
			"jumpAddress": null,
			"opened": false,
			"sort": 2,
			"deleted": false,
			"createTime": 1554119223000,
			"updateTime": null
		}
		// {
		// 	"id": 58,
		// 	"title": "删除支付账号",
		// 	"icon": "&#xe629;",
		// 	"dic_address": "page/paychannel/removeaccount.html",
		// 	"spread": false,
		// 	"dicId": 51,
		// 	"flag": true,
		// 	"remark": "2019-04-19",
		// 	"jumpAddress": null,
		// 	"opened": false,
		// 	"sort": 2,
		// 	"deleted": false,
		// 	"createTime": 1554119223000,
		// 	"updateTime": null
		// },
		]

	}];
// navs=[{
// 	"title" : "后台首页",
// 	"icon" : "&#xe61c;",
// 	"href" : "page/main.html",
// 	"spread" : false,
// 	"children":[{
// 	"title" : "统统",
// 	"icon" : "&#xe61c;",
// 	"href" : "page/news/newsList.html",
// 	"spread" : false
// }]
// },{
// 	"title" : "交易查询",
// 	"icon" : "&#xe61c;",
// 	"href" : "page/news/newsList.html",
// 	"spread" : false,
// 	"children":[{
// 		"title" : "统计",
// 		"icon" : "&#xe61c;",
// 		"href" : "page/news/newsList.html",
// 		"spread" : false
// 	}]
// },{
// 	"title" : "系统推广",
// 	"icon" : "&#xe629;",
// 	"href" : "page/links/linksList.html",
// 	"spread" : false,
// 	"children":[{
// 		"title" : "统计1",
// 		"icon" : "&#xe61c;",
// 		"href" : "page/news/newsList.html",
// 		"spread" : false
// 	}]
// },{
// 	"title" : "安全设置",
// 	"icon" : "&#xe631;",
// 	"href" : "page/systemParameter/systemParameter.html",
// 	"spread" : false,
// 	"children":[{
// 		"title" : "统计2",
// 		"icon" : "&#xe61c;",
// 		"href" : "page/news/newsList.html",
// 		"spread" : false
// 	}]
// }];
layui.define(["element", "jquery", "cjhd"], function (exports) {
	var element = layui.element,
		$ = layui.jquery,
		layId,
		cjhd = layui.cjhd,
		Tab = function () {
			this.tabConfig = {
				closed: true,
				openTabNum: 70,
				tabFilter: "bodyTab"
			}
		};
	//获取左侧菜单数据
	// cjhd.json('/api-admin/datadicts/find/all',{},function(res){//
	// 	if(res.code==0){
	// 		navs = res.data;
	// 	}
	// },{type:'post'});
	// var roleNames = [];
	//  roleNames = layui.data('author').roleName;
	// //  var roleName = roleNames[0];
	// 	var roleName = 'ROLE_SUPERADMIN';
	// 	var rData = {};
	// 	rData.roleName = roleName;
	// console.log(JSON.stringify(rData));
	// $.ajax({
	// 	type:'post',
	// 	url:'http://www.idoubi.top/api-admin/datadicts/find/role',
	// 	dataType:'json',
	// 	data: rData,
	// 	async:false,
	// 	beforeSend:function(request){
	// 		console.log(request);
	// 		request.setRequestHeader('Authorization',layui.data('author').Authorization);
	// 	},
	// 	success:function(res){
	// 		console.log(JSON.stringify(res));
	// 		if(res.code==0){
	// 			navs = res.data;
	// 		}else{
	// 			layer.confirm('登录已过期或服务器出错了获取不到数据请重新登录', {
	// 				btn: ['重新登录'] 
	// 			  }, function(){
	// 				location.href="page/user/login.html";
	// 			  })
	// 		}
	// 	},
	// 	error:function(e){
	// 		if(e.status==500){
	// 			layer.confirm('服务器出现错误了...', {
	// 				btn: ['返回登录页面等待维护'] 
	// 			  }, function(){
	// 				location.href="page/user/login.html";
	// 			  })
	// 		}
	// 	}

	// });		
	//显示左侧菜单
	if ($(".navBar").html() == '') {
		var _this = this;
		$(".navBar").html(navBar(navs)).height($(window).height() - 230);
		element.init();  //初始化页面元素
		$(window).resize(function () {
			$(".navBar").height($(window).height() - 230);
		})
	}

	//参数设置
	Tab.prototype.set = function (option) {
		var _this = this;
		$.extend(true, _this.tabConfig, option);
		return _this;
	};

	//通过title获取lay-id
	Tab.prototype.getLayId = function (title) {
		$(".layui-tab-title.top_tab li").each(function () {
			if ($(this).find("cite").text() == title) {
				layId = $(this).attr("lay-id");
			}
		})
		return layId;
	}
	//通过title判断tab是否存在
	Tab.prototype.hasTab = function (title) {
		var tabIndex = -1;
		$(".layui-tab-title.top_tab li").each(function () {
			if ($(this).find("cite").text() == title) {
				tabIndex = 1;
			}
		})
		return tabIndex;
	}

	//右侧内容tab操作
	var tabIdIndex = 0;
	Tab.prototype.tabAdd = function (_this) {
		if (window.sessionStorage.getItem("menu")) {
			menu = JSON.parse(window.sessionStorage.getItem("menu"));
		}
		var that = this;
		var closed = that.tabConfig.closed,
			openTabNum = that.tabConfig.openTabNum;
		tabFilter = that.tabConfig.tabFilter;
		if (_this.find("i.iconfont,i.layui-icon").attr("data-icon") != undefined) {
			var title = '';
			if (that.hasTab(_this.find("cite").text()) == -1 && _this.siblings("dl.layui-nav-child").length == 0) {
				if ($(".layui-tab-title.top_tab li").length == openTabNum) {
					layer.msg('只能同时打开' + openTabNum + '个选项卡哦。不然系统会卡的！');
					return;
				}
				tabIdIndex++;
				if (_this.find("i.iconfont").attr("data-icon") != undefined) {
					title += '<i class="iconfont ' + _this.find("i.iconfont").attr("data-icon") + '"></i>';
				} else {
					title += '<i class="layui-icon">' + _this.find("i.layui-icon").attr("data-icon") + '</i>';
				}
				title += '<cite>' + _this.find("cite").text() + '</cite>';
				title += '<i class="layui-icon layui-unselect layui-tab-close" data-id="' + tabIdIndex + '">&#x1006;</i>';
				element.tabAdd(tabFilter, {
					title: title,
					content: "<iframe src='" + _this.attr("data-url") + "' data-id='" + tabIdIndex + "'></frame>",
					id: new Date().getTime()
				})

				//当前窗口内容
				var curmenu = {
					"icon": _this.find("i.iconfont").attr("data-icon") != undefined ? _this.find("i.iconfont").attr("data-icon") : _this.find("i.layui-icon").attr("data-icon"),
					"title": _this.find("cite").text(),
					"href": _this.attr("data-url"),
					"layId": new Date().getTime()
				}
				menu.push(curmenu);
				window.sessionStorage.setItem("menu", JSON.stringify(menu)); //打开的窗口
				window.sessionStorage.setItem("curmenu", JSON.stringify(curmenu));  //当前的窗口
				element.tabChange(tabFilter, that.getLayId(_this.find("cite").text()));
			} else {
				//当前窗口内容
				var curmenu = {
					"icon": _this.find("i.iconfont").attr("data-icon") != undefined ? _this.find("i.iconfont").attr("data-icon") : _this.find("i.layui-icon").attr("data-icon"),
					"title": _this.find("cite").text(),
					"href": _this.attr("data-url"),
					"layId": new Date().getTime()
				}
				window.sessionStorage.setItem("curmenu", JSON.stringify(curmenu));  //当前的窗口
				element.tabChange(tabFilter, that.getLayId(_this.find("cite").text()));
			}
		}
		// })
	}
	$("body").on("click", ".top_tab li", function () {
		//切换后获取当前窗口的内容
		var curmenu = '';
		var menu = JSON.parse(window.sessionStorage.getItem("menu"));
		curmenu = menu[$(this).index() - 1];
		if ($(this).index() == 0) {
			window.sessionStorage.setItem("curmenu", '');
		} else {
			window.sessionStorage.setItem("curmenu", JSON.stringify(curmenu));
			if (window.sessionStorage.getItem("curmenu") == "undefined") {
				//如果删除的不是当前选中的tab,则将curmenu设置成当前选中的tab
				if (curNav != JSON.stringify(delMenu)) {
					window.sessionStorage.setItem("curmenu", curNav);
				} else {
					window.sessionStorage.setItem("curmenu", JSON.stringify(menu[liIndex - 1]));
				}
			}
		}
		element.tabChange(tabFilter, $(this).attr("lay-id")).init();
	})

	//删除tab
	$("body").on("click", ".top_tab li i.layui-tab-close", function () {
		//删除tab后重置session中的menu和curmenu
		liIndex = $(this).parent("li").index();
		var menu = JSON.parse(window.sessionStorage.getItem("menu"));
		//获取被删除元素
		delMenu = menu[liIndex - 1];
		var curmenu = window.sessionStorage.getItem("curmenu") == "undefined" ? "undefined" : window.sessionStorage.getItem("curmenu") == "" ? '' : JSON.parse(window.sessionStorage.getItem("curmenu"));
		if (JSON.stringify(curmenu) != JSON.stringify(menu[liIndex - 1])) {  //如果删除的不是当前选中的tab
			// window.sessionStorage.setItem("curmenu",JSON.stringify(curmenu));
			curNav = JSON.stringify(curmenu);
		} else {
			if ($(this).parent("li").length > liIndex) {
				window.sessionStorage.setItem("curmenu", curmenu);
				curNav = curmenu;
			} else {
				window.sessionStorage.setItem("curmenu", JSON.stringify(menu[liIndex - 1]));
				curNav = JSON.stringify(menu[liIndex - 1]);
			}
		}
		menu.splice((liIndex - 1), 1);
		window.sessionStorage.setItem("menu", JSON.stringify(menu));
		element.tabDelete("bodyTab", $(this).parent("li").attr("lay-id")).init();
	})

	var bodyTab = new Tab();
	exports("bodyTab", function (option) {
		return bodyTab.set(option);
	});
})